@echo off
setlocal
set "EXE=%LOCALAPPDATA%\Programs\MMMN Video Studio\MMMN-Video-Studio.exe"
if not exist "%EXE%" (
  echo MMMN Video Studio Windows installer has not been installed yet.
  echo This source ZIP is NOT a setup.exe.
  pause
  exit /b 2
)
echo Testing INSTALLED Windows application without opening or modifying any projects...
"%EXE%" --self-test
if errorlevel 1 (
  echo ERROR: Packaged Windows app self-test FAILED. Keep your project data and backup safe.
  pause
  exit /b 1
)
echo PASS: offline UI resources, isolated storage and real H.264/AAC MP4 encoder.
pause
exit /b 0
