@echo off
setlocal
cd /d "%~dp0web"
where py.exe >nul 2>&1 || (echo [MMMN] Python 3 is required for local preview. & pause & exit /b 1)
echo [MMMN] Windows local preview will open in your browser.
echo [MMMN] Local-only address: http://127.0.0.1:8765
start "MMMN Local Preview Server" /min cmd /c "py -3 -m http.server 8765 --bind 127.0.0.1"
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765"
echo [MMMN] Preview launched. This is NOT the Windows NSIS installed application.
echo [MMMN] Keep original video files. Export Backup ZIP before replacing project data.
endlocal
