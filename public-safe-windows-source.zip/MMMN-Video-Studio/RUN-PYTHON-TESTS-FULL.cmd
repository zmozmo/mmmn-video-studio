@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 scripts\run-python-tests.py --timeout 180 --report python-full-report.json
) else (
  python scripts\run-python-tests.py --timeout 180 --report python-full-report.json
)
set "RESULT=%ERRORLEVEL%"
echo.
echo Python tests alone do NOT authorize Windows installer release.
exit /b %RESULT%
