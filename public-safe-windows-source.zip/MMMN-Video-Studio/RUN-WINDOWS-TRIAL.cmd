@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 portable\studio_server.py
) else (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 required. No installation was changed.
    pause
    exit /b 1
  )
  python portable\studio_server.py
)
if errorlevel 1 (
  echo Offline Studio could not start. Review any error above.
  echo A second copy cannot open the same project data folder at the same time.
  pause
)
endlocal
