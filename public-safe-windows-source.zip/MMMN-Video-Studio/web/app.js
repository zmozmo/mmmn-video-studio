import {makeOfflineDraft} from './auto-edit.mjs';
import {checkpoint,undoSceneEdit,redoSceneEdit} from './edit-history.mjs';
import {createNativeBridge,pickProject,makeSaveQueue} from './native-state.mjs';
import {imageCreationBrief} from './visual-brief.mjs';
import {makeNativeMedia} from './native-media.mjs';
import {makeNativeRecovery} from './native-recovery.mjs';
import {planNativeRender} from './native-render-preflight.mjs';
import {estimateSeconds,makeScenes,rebalanceScenes,projectStats,timecode,splitChapters,parseSRT,alignScenesToCues,retimeBoundary,splitSceneAt,mergeSceneWithNext,setSceneDurationKeepingTotal,missingSceneImages,sceneGapsCSV,suggestVisualMatches,setSceneVisualConfirmation,setBoundaryAtTime,visualProposalsCSV,splitAtVisualChanges,formatSRT,subtitleDiagnostics,sceneReviewIssues,sceneReviewCSV,buildNarrationCueMap,proposeNarrationBoundaries,cueEvidenceCSV,applyPauseTimingPlan,reconcileRecordingDuration} from './core.mjs';
import {makeZip,readZip} from './zip.mjs';
import {assertProjectShape,auditMediaMetadata,verifyBackupIndex,describeMissingMedia,MAX_BROWSER_BACKUP_BYTES,remapBackupForSafeRestore} from './backup-safety.mjs';
const $=id=>document.getElementById(id), E=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const nativeBridge=createNativeBridge(window.__TAURI__);
const nativeMedia=makeNativeMedia(window.__TAURI__);
const nativeRecovery=makeNativeRecovery(window.__TAURI__);
const saveQueue=makeSaveQueue(nativeBridge,e=>toast('Windows local save မအောင်မြင်ပါ: '+e.message,true));
let storageInfo=null;
let backupList=[];
let trialExports=[];
let backupBusy=false;
let renderJobId=null, renderJobStatus=null, renderPollTimer=null;
let lastMediaAudit=null;
let renderCacheInfo=null;
let project,tab='overview',selected=0,chosenScene=0,playing=false,clock=null,sceneTime=0,currentAudioUrl=null;
let dbp=new Promise((resolve,reject)=>{const req=indexedDB.open('mmmn-studio-v1',1);req.onupgradeneeded=()=>{req.result.createObjectStore('blobs');};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
async function browserStoreBlob(id,blob){const db=await dbp;return new Promise((resolve,reject)=>{const tx=db.transaction('blobs','readwrite');tx.objectStore('blobs').put(blob,id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
async function browserLoadBlob(id){const db=await dbp;return new Promise((resolve,reject)=>{const t=db.transaction('blobs','readonly').objectStore('blobs').get(id);t.onsuccess=()=>resolve(t.result||null);t.onerror=()=>reject(t.error);});}
const urlCache=new Map();
async function storeBlob(id,blob,name=blob.name||''){
 if(nativeBridge.available&&!nativeMedia.available)throw Error('Native asset protocol is unavailable. Refusing to use temporary browser storage.');
 if(nativeMedia.available){const info=await nativeMedia.store(id,blob,name);return info;}
 await browserStoreBlob(id,blob);return null;
}
async function nativeInfo(asset){if(!nativeMedia.available||!asset)return null;return nativeMedia.info(asset.id,asset.name,asset.type);}
async function migrateLegacyMedia(asset){
 if(!nativeMedia.available||!asset)return null;
 let info=await nativeInfo(asset);if(info)return info;
 const old=await browserLoadBlob(asset.id);
 if(!old)return null;
 // Do not delete legacy IndexedDB media: the old original remains as a recovery copy.
 info=await nativeMedia.store(asset.id,old,asset.name);
 asset.localStored=true;asset.nativeStored=true;asset.sha256=info.sha256;save();
 return info;
}
async function loadBlob(id){
 const asset=(project?.assets||[]).find(a=>a.id===id);
 if(nativeMedia.available && asset){
  const info=await migrateLegacyMedia(asset);
  if(info){if(info.size>MAX_BROWSER_BACKUP_BYTES)throw Error(`Media ${asset.name} is ${Math.round(info.size/1048576)} MiB. Browser ZIP limit is 512 MiB. Use Native Full Backup instead.`);
   const r=await fetch(nativeMedia.url(info.path));if(!r.ok)throw Error(`Cannot read native media: ${asset.name}`);return r.blob();}
 }
 return browserLoadBlob(id);
}
async function mediaURL(id){
 const a=(project.assets||[]).find(x=>x.id===id);if(!a)return '';
 if(urlCache.has(id))return urlCache.get(id);
 const native=await migrateLegacyMedia(a);
 if(native){const url=nativeMedia.url(native.path);urlCache.set(id,url);return url;}
 const b=await browserLoadBlob(id);if(b){const url=URL.createObjectURL(b);urlCache.set(id,url);return url;}
 return a.bundledUrl||'';
}
function clearCachedURL(id){const url=urlCache.get(id);if(url?.startsWith('blob:'))URL.revokeObjectURL(url);urlCache.delete(id);}

function save(){const json=JSON.stringify(project);try{localStorage.setItem('mmmn-studio-state',json);}catch(e){toast('Browser fallback save မအောင်မြင်ပါ။ Backup ZIP ထုတ်ထားပါ။',true);}void saveQueue.save(json);}
function toast(s,bad=false){const old=$('toast');if(old)old.remove();const x=document.createElement('div');x.className='toast'+(bad?' bad':'');x.id='toast';x.textContent=s;document.body.append(x);setTimeout(()=>x.remove(),5500);}
const fmt=s=>timecode(s);
function nav(){return [['overview','◈','Overview'],['manuscript','▤','Manuscript'],['assets','▧','Image Library'],['visuals','◩','Visual Plan'],['timeline','▥','Video Timeline'],['export','▶','Export MP4'],['drive','↗','Google Drive'],['updates','⟳','Windows Updates']].map(([id,ic,name])=>`<button class="nav ${tab===id?'active':''}" data-tab="${id}"><span>${ic}</span>${name}</button>`).join('');}
function heading(){const names={overview:'Project Dashboard',manuscript:'Manuscript & Chapters',assets:'Image Library',visuals:'Visual Plan — Story Scenes',timeline:'Narration Timeline',export:'Video Production',drive:'Google Drive Assets',updates:'Updates & Local Data'};return `<div class="top"><div><div class="eyebrow">MMMN / ${E(project.title)}</div><h1>${names[tab]}</h1><div class="sub">Offline-first • Windows offline build • Voice-led Production</div></div><span class="pill">Windows Offline Trial • Installer Lab</span></div>`;}
const statCard=(label,value,sub)=>`<div class="panel"><div class="muted small">${label}</div><div class="metric">${value}</div><div class="muted small">${sub}</div></div>`;
function overview(){let s=projectStats(project);return `<div class="grid four">${statCard('အခန်း',s.chapters,'Full First Draft')}${statCard('စာသားအရှည်',s.charCount.toLocaleString(),'Unicode characters')}${statCard('ဖတ်ကြာချိန်ခန့်မှန်း',fmt(s.estimatedSeconds),'အသံဖိုင်ထည့်လျှင် ပိုတိကျ')}${statCard('ရှိပြီးသားပုံ',s.images,'References + locally imported')}</div>
<div class="grid two section"><section class="panel"><h2>အမြန်လုပ်ဆောင်ရန်</h2><div class="actions"><button class="btn primary" data-tab="timeline">Timeline စတင်ရန်</button><button class="btn" data-tab="visuals">ဇာတ်ဝင်ခန်းပုံလိုအပ်ချက်များ</button><button class="btn" data-action="all-scenes">အခန်းအားလုံး Scene ခွဲရန်</button><button class="btn" data-action="import-backup">Backup ZIP Import</button></div><p class="sub">Scene ခွဲခြင်းက စာသားအရှည်ပေါ်မူတည်ပြီး အချိန်ခန့်မှန်းပေးတာပါ။ ကိုယ်တိုင်ဖတ်ထားသောအသံကို Import လုပ်လျှင် အသံကြာချိန်နဲ့ ပြန်ချိန်ပေးနိုင်ပါတယ်။</p><div class="help warning">Video-first Preview နှင့် SRT-assisted Alignment; Native Upgrade-safe Metadata Storage ထည့်ထားပါတယ်။ မြန်မာအသံမှ အလိုအလျောက် Transcript ထုတ်ခြင်း မပါသေးပါ။</div></section>
<section class="panel"><h2>Production Progress</h2><div class="small muted">Narration ပါပြီးသော အခန်း ${s.audioChapters} / ${s.chapters}</div><div style="height:10px;border-radius:20px;background:#0e1c29;margin:12px 0;overflow:hidden"><div style="width:${s.chapters?s.audioChapters/s.chapters*100:0}%;background:var(--accent);height:100%"></div></div><div class="small muted">Scene ခွဲပြီးသော Shot အရေအတွက် — ${s.shots}</div><hr style="border:0;border-top:1px solid var(--line);margin:19px 0"><div class="small muted">စာအုပ် - ${E(project.author||'မောင်ခရမ်း')}</div><p><a href="${E(project.drive.sourceDocument)}" target="_blank" rel="noopener noreferrer">Original Google Docs ↗</a></p></section></div>
<section class="panel section"><h2>Chapter Overview</h2><div class="chapters">${project.chapters.map((c,i)=>`<button class="chapter" data-select-chapter="${i}" data-tab="manuscript"><strong>${E(c.title)}</strong><div class="meta">${fmt(c.recordedSeconds||estimateSeconds(c.text,project.settings.charsPerMinute))} • ${(c.scenes||[]).length} Scenes • ${c.audioAssetId?'🎙 Recorded':'Audio မထည့်ရသေး'}</div></button>`).join('')}</div></section>`;}
function chapterSelect(){return `<label class="field">အခန်းရွေးရန်<select id="chapter-select">${project.chapters.map((c,i)=>`<option value="${i}" ${i===selected?'selected':''}>${E(c.title)}</option>`).join('')}</select></label>`;}
function manuscript(){let c=project.chapters[selected];return `<div class="chapter-editor"><section class="panel"><div class="actions"><button class="btn" data-action="import-book">TXT Import</button><button class="btn" data-action="restore-starter">Original Snapshot ပြန်တင်</button></div>${chapterSelect()}<label class="field">အခန်းစာသား (Local Video Copy; Google Docs မပြောင်း)<textarea id="chapter-text">${E(c.text)}</textarea></label><button class="btn primary" data-action="save-text">Save local copy</button></section><section class="panel"><h2>Novel Timing Planner</h2><label class="field">ခန့်မှန်းဖတ်နှုန်း (Myanmar characters / minute)<input type="number" id="cpm" min="100" max="1500" value="${project.settings.charsPerMinute}"/></label><label class="field">Scene တစ်ခုချင်း ပျမ်းမျှစက္ကန့်<input type="number" id="shot-sec" min="5" max="120" value="${project.settings.secondsPerShot}"/></label><div class="metric">${fmt(c.recordedSeconds||estimateSeconds(c.text,project.settings.charsPerMinute))}</div><div class="sub">အသံမတင်ရသေးလျှင် ခန့်မှန်းချိန်ဖြစ်ပါသည်။</div><div class="actions section"><button class="btn primary" data-action="save-settings">Save Timing Settings</button><button class="btn" data-action="generate-scenes">Scenes ပြန်တွက်ရန်</button></div></section></div>`;}
function assets(){const pics=project.assets.filter(a=>a.type?.startsWith('image/'));return `<div class="panel"><h2>Image Assets (${pics.length})</h2><div class="actions"><button class="btn primary" data-action="import-images">ပုံအသစ်များ Import</button><button class="btn" data-action="prepare-references">↧ Package Reference ပုံ ၈ ပုံ Local Import</button><button class="btn" data-action="import-image-folder">Import Local Drive Photo Folder</button><button class="btn" data-action="export-backup">Backup ZIP</button><button class="btn" data-action="import-backup">Import Backup ZIP</button><a class="btn" href="${E(project.drive.photosFolder)}" target="_blank" rel="noopener noreferrer">Drive Photos ↗</a></div><p class="sub">ရှိပြီးသား Reference ပုံ ၈ ပုံက ဝတ္ထုတစ်အုပ်လုံးအတွက် Scene Background မဟုတ်ပါ။ BI-001.png ကဲ့သို့ Visual Plan ID နှင့် ပုံဖိုင်နာမည်ပေးပြီး Import လုပ်လျှင် သက်ဆိုင်ရာ Shot များကို Auto-Assign လုပ်မည်။ ပုံများကို Google Drive မှ ဖတ်ယူနိုင်သော်လည်း App Output အားလုံးကို စက်ထဲမှာသာသိမ်းမည်။</p></div><div class="media-grid section">${pics.map(a=>`<div class="asset"><img loading="lazy" data-image-id="${E(a.id)}" alt="${E(a.label||a.name)}"><div class="desc"><strong>${E(a.label||a.name)}</strong><div class="muted">${E(a.name)}</div>${a.driveUrl?`<a href="${E(a.driveUrl)}" target="_blank" rel="noopener noreferrer">View on Drive ↗</a>`:''}</div></div>`).join('')}</div>`;}
function visuals(){
 const all=project.visualRequirements||[], chapter=project.chapters[selected];
 const arr=all.filter(v=>v.chapter===chapter.number);
 const done=all.filter(v=>v.status==='local-ready').length;
 return `<div class="panel"><h2>Story-Based Image Requirements (${all.length})</h2><div class="help">ဒီစာရင်းက 22 Chapters အတွက် ပုံလိုအပ်ချက်များ (draft) ဖြစ်ပါတယ်။ Shot 235 ခုနဲ့ ပုံအရေအတွက် တစ်ခုတည်းမဟုတ်ပါ။ ရှိပြီးသား Character Portrait ပုံ ၈ ပုံကို မဆိုင်တဲ့ Scene နောက်ခံအဖြစ် အလိုအလျောက် မထည့်ပါ။ <strong>Google Drive = Input Only; Outputs = Local Device Only.</strong></div><div class="actions section"><button class="btn primary" data-action="import-images">Drive မှ Download လုပ်ထားသောပုံများ Import</button><button class="btn" data-action="import-image-folder">Folder တစ်ခုလုံး Import</button><button class="btn" data-action="export-visual-csv">Image Request CSV (Local Download)</button><button class="btn primary" data-action="export-image-brief">⬇ Image Creation Brief (ဒီအခန်း)</button><button class="btn" data-action="export-all-image-brief">⬇ Image Creation Brief (အခန်းအားလုံး)</button><a class="btn" href="${E(project.drive.photosFolder)}" target="_blank" rel="noopener noreferrer">Source Photo Folder ↗</a></div><div class="sub section">Local ပုံဖြည့်ပြီး ${done}/${all.length} · မဖြည့်ရသေး ${all.length-done} · လက်ရှိကြာချိန်များသည် Narration မရှိသေး၍ ခန့်မှန်းချက်များ ဖြစ်ပါသည်။</div></div>
 <section class="panel section">${chapterSelect()}<h2>လိုအပ်သော ပုံများ — ${E(chapter.title)} (${arr.length})</h2><div class="section">${arr.map(v=>`<div class="scene"><strong>${E(v.id)}</strong><div><strong>${E(v.description)}</strong><div class="small muted">${E(v.kind)} · ${v.status==='local-ready'?'✓ စက်ထဲတွင် ပုံရှိ':'ပုံမဖြည့်ရသေး — '+E(v.id)+'.png အဖြစ် Import လုပ်ပါ'}</div></div><span class="pill">${v.status==='local-ready'?'Ready':'Needed'}</span></div>`).join('')}</div></section>`;
}

function suggestImage(text,index=0) {
  const rules=[['ပျိုမေခင်','drive-4'],['မောင်ခိန်','drive-3'],['ဘိုးသိုက်မောင်း','drive-6'],['ဦးသက်ထွန်း','drive-5'],['ထွဋ်ခေါင်','drive-1'],['ကျွန်း','drive-8'],['ဂူ','drive-8'],['ပင်လယ်','drive-8'],['လှိုင်း','drive-8'],['ရေငန်','drive-8'],['ရန်ကုန်','drive-7']];
  for(const [keyword,id] of rules)if(text?.includes(keyword))return id;
  return index%3===0?'drive-8':'drive-7';
}
function subtitleNavigator(ch){
 const cues=ch.subtitleCues||[];
 if(!cues.length)return '<div class="sub section">ဖတ်ပြသံ SRT ထည့်ပြီးမှ Timestamp အလိုက် ချက်ချင်း Jump လုပ်နိုင်ပါမယ်။</div>';
 const hit=cues.findIndex(x=>x.end>=sceneTime);
 const active=hit<0?cues.length-1:hit;
 const begin=Math.max(0,active-3),visible=cues.slice(begin,begin+12);
 return `<details class="section" open><summary>🎧 SRT နဲ့အတူ နားထောင်ရန် — ${cues.length} cues</summary>
 <div class="cue-list">${visible.map((cue,i)=>`<div class="cue-item"><button class="btn small" data-seek-cue="${cue.start}" title="Jump to this narration time">▶ ${Number(cue.start).toFixed(2)}s</button><span>${E(cue.text)}</span></div>`).join('')}</div>
 <div class="sub">ရှေ့/နောက်စာတန်းတွေကြည့်ဖို့ Video Playhead ကို ရွှေ့ပြီး Timeline ပြန်ဖွင့်နိုင်ပါတယ်။ SRT Timing တွေကို အတည်မပြုသေးပါ။</div></details>`;
}
function sceneOptions(ch){const pics=project.assets.filter(a=>a.type?.startsWith('image/'));return `<option value="">No image</option>`+pics.map(a=>`<option value="${E(a.id)}">${E(a.label||a.name)}</option>`).join('');}
function timeline(){
 const c=project.chapters[selected],list=c.scenes||[],total=c.recordedSeconds||estimateSeconds(c.text,project.settings.charsPerMinute);
 const videoAsset=(project.assets||[]).find(a=>a.id===c.videoAssetId);
 const audioAsset=(project.assets||[]).find(a=>a.id===c.audioAssetId);
 const missing=missingSceneImages(project,selected),reqs=(project.visualRequirements||[]).filter(v=>v.chapter===c.number);
 const renderSeconds=list.reduce((n,s)=>n+Number(s.duration||0),0);
 const mismatch=c.recordedSeconds>0&&Math.abs(renderSeconds-c.recordedSeconds)>.5;
 return `${chapterSelect()}<div class="grid two"><section class="panel"><h2>Narration Audio / Video + Scene Preview</h2>
 <div class="preview" id="preview"><span class="muted">ပုံမဖြည့်ရသေးပါ</span></div>
 <div class="source-video" id="source-video-wrap"><video id="video-player" playsinline preload="metadata"></video><div class="small muted">Original narrator video (source monitor) — background removal မလုပ်ရသေးပါ။</div></div>
 <div class="player section"><button class="btn" data-action="toggle-play">${playing?'⏸ Pause':'▶ Play Recording'}</button><span class="small" id="time-label">${fmt(sceneTime)} / ${fmt(total)}</span><input id="time-slider" type="range" min="0" max="${total}" step="0.05" value="${Math.min(sceneTime,total)}"/></div>
 <audio id="audio-player" controls style="width:100%;margin-top:12px"></audio>
 <div class="help section">${window.__MMMN_TRIAL__?"Offline Pause Auto Timing ကို နှိပ်ပြီး ဖတ်ပြသံရပ်နားချက်အလိုက် Scene ပြောင်းချိန် အကြံပြုနိုင်ပါတယ်။ အသံကို ကိုယ်တိုင်နားထောင်ပြီး ပြန်စစ်ပါ။":"Pause Timing JSON ကို Import လုပ်ပြီး Scene ကြာချိန်ကို ပြန်ညှိနိုင်သည်။"}</div><div class="help section">Preview မှာ နောက်ခံပုံပြောင်းတာကို ကြည့်ရင်း မူရင်းဖတ်ပြ Video အသံကို နားထောင်နိုင်ပါတယ်။ Presenter compositing ကို Renderer မှာ PIP အဖြစ် ရွေးနိုင်ပြီး Background removal မပါသေးပါ။</div>
 </section><section class="panel"><h2>1 — Narration Import (Video or Audio)</h2>
 <div class="actions"><button class="btn" data-action="auto-edit-draft">✨ Auto Draft (SRT / Pause + ပုံ)</button><button class="btn" data-action="undo-timeline">↶ Undo ({(c.undoHistory||[]).length})</button><button class="btn" data-action="redo-timeline">↷ Redo ({(c.redoHistory||[]).length})</button><button class="btn primary" data-action="import-video">🎥 ကိုယ်တိုင်ဖတ်ထားတဲ့ Video Import</button><button class="btn" data-action="import-audio">အသံသာ Import</button></div>
 <div class="sub section">${videoAsset?`🎥 ${E(videoAsset.name)} · ${fmt(c.recordedSeconds)}`:audioAsset?`🎙 ${E(audioAsset.name)} · ${fmt(c.recordedSeconds)}`:'Video/Audio မထည့်ရသေးပါ'}</div>
 <p class="sub">Native Windows App မှာ Video အကြီးတွေကို App Local Data ထဲ အပိုင်းလိုက်သိမ်းပြီး ပြန်ဖွင့်နိုင်ဖို့ Code ထည့်ထားပါတယ်။ Browser Preview Mode ကတော့ Storage Limit ရှိနိုင်ပါတယ်။ Native Windows စက်ပေါ် စမ်းသပ်အတည်ပြုရဦးမယ်။</p>
 <h2 class="section">2 — Narration Timestamp</h2><div class="actions">${window.__MMMN_TRIAL__?'<button class="btn primary" data-action="analyze-narration-pauses">🎙 Offline Pause Auto Timing (Review)</button><button class="btn primary" data-action="transcribe-offline">📝 Recording → Myanmar SRT (offline AI)</button><button class="btn" data-action="offline-speech-status">Speech Model Setup စစ်ရန်</button>':''}<button class="btn" data-action="import-pause-timing">⬆ Pause Timing JSON (CPU)</button> <button class="btn" data-action="import-srt">SRT Transcript Import</button><button class="btn" data-action="align-srt">SRT နဲ့ Scene ကို ညှိရန်</button><button class="btn" data-action="rebalance">ကြာချိန်အလိုက် ခန့်မှန်းညှိရန်</button><button class="btn primary" data-action="align-cue-evidence">✓ Narration Evidence နဲ့ Scene Auto-Align (Review Required)</button><button class="btn" data-action="export-cue-evidence">⬇ Cue Evidence CSV</button></div>
 <div class="sub section">${(c.subtitleCues||[]).length} Subtitle cues · ${c.alignmentSummary?E(c.alignmentSummary):'SRT မရှိသေးလျှင် စာအရှည်အလိုက် ခန့်မှန်းသာ ဖြစ်သည်။'}</div><div class="help section">Evidence Alignment က SRT မှာ ဖတ်ထားတဲ့စာသားကို စာမူအတိုင်း အစဉ်လိုက် ရှာပြီး Scene ပြောင်းချိန် အကြံပြုတာပါ။ အသံကို တိုက်ရိုက် မနားထောင်သေးပါ။ အရင် Manual Lock ထားတဲ့ ပုံပြောင်းချိန် မပြောင်းပါ။ Result အားလုံးကို Video ဖွင့်ပြီး ပြန်စစ်ရပါမယ်။</div>
 <div class="sub section">Windows Trial မှာ whisper.cpp multilingual model ကို Local Data Folder ထဲ ထည့်ထားပြီး Recording → Myanmar SRT ကို နှိပ်နိုင်ပါတယ်။ Network မသုံးပါ။ Model မပါသေးလျှင် Speech Model Setup စစ်ရန် ကိုနှိပ်ပါ။ မြန်မာစာ Recognition ကို လူကိုယ်တိုင်ပြင်ဆင်စစ်ဆေးရန် လိုပါသည်။</div>
 ${subtitleNavigator(c)}
 <details class="srt-edit-panel section"><summary>✎ SRT Subtitle ကို ဒီမှာပြင်မယ် (စက်ထဲမှာသာ)</summary>
 <p class="sub">မမှန်တဲ့ မြန်မာစာ၊ Start/End Time တွေကို ပြင်နိုင်ပါတယ်။ Save SRT နှိပ်ပြီးမှ Align ကို ပြန်နှိပ်ပါ။ မူရင်း Video နဲ့ Google Docs ကို မပြင်ပါ။</p>
 <textarea id="srt-editor" class="srt-editor" spellcheck="false" placeholder="1&#10;00:00:01,000 --> 00:00:03,000&#10;ဖတ်ထားသောစာသား">${E(formatSRT(c.subtitleCues||[]))}</textarea>
 <div class="actions"><button class="btn primary" data-action="save-srt-editor">Save Edited SRT</button><button class="btn" data-action="export-srt">⬇ SRT Download</button></div>
 </details>
 <h2 class="section">3 — Storyboard</h2><div class="actions"><button class="btn" data-action="generate-scenes">Auto Scenes (Resets edits)</button><button class="btn" data-tab="visuals">ပုံလိုအပ်ချက်များ</button><button class="btn" data-action="export-missing">⬇ Missing Image CSV</button><button class="btn primary" data-action="suggest-story-visuals">Auto Suggest Scene Pictures</button><button class="btn" data-action="split-at-visuals">Split at Visual Changes (Preview)</button><button class="btn" data-action="export-proposals">⬇ Visual Match Review CSV</button></div>
 <div class="help section">နောက်ခံပုံမရှိသေးသော Shot: <strong>${missing.length} / ${list.length}</strong> · ${fmt(renderSeconds)} Timeline / ${fmt(total)} Narration. ${mismatch?'<strong>⚠️ Video ကြာချိန်နှင့် Scene Timeline မကိုက်ပါ။ Rebalance/Boundary fine-tune လိုပါတယ်။</strong>':'ပုံမပြည့်မချင်း Final Export ကို Renderer က တားထားမယ်။'}<br>Auto Suggest က မြန်မာစာလုံးတူညီမှုအလိုက် ပုံ ID ကို အကြံပြုတာသာ ဖြစ်ပြီး AI က ဇာတ်လမ်းအဓိပ္ပာယ်အပြည့်အစုံ နားလည်တာမဟုတ်ပါ။ အကြံပြုထားတဲ့ Scene တိုင်းကို စစ်ရပါမယ်။<br>Scene ကို Playhead မှာ ခွဲဖို့ စာရင်းအောက်က <b>Split at playhead</b> ကို သုံးပါ။ SRT မရှိလျှင် အချိန်တွေက ခန့်မှန်းချက်ပါ။</div>
 <label class="field">Presenter Inset for Export<select id="presenter-mode"><option value="none" ${c.presenterMode!=='pip'?'selected':''}>Background pictures only (narration audio continues)</option><option value="pip" ${c.presenterMode==='pip'?'selected':''}>Original narrator video as small PIP (not background removal)</option></select></label>
 <label class="field">Transition<select id="transition-mode"><option value="dissolve" ${c.transitionMode!=='cut'?'selected':''}>Cross Dissolve (0.45s)</option><option value="cut" ${c.transitionMode==='cut'?'selected':''}>Hard Cut</option></select></label>
 </section></div>
 <section class="panel section"><div class="row" style="justify-content:space-between"><h2>Manual Fine-Tune — ${list.length} Shots</h2><span class="small muted">⟵ / ⟶ နှင့် Split/Merge ပြင်နိုင် • Audio ကြာချိန် မပြောင်း</span></div>
 <div class="actions section"><button class="btn primary" data-action="next-review">⚠ Next Review Scene</button><button class="btn" data-action="export-review">⬇ Full Review CSV</button><span class="small muted">${sceneReviewIssues(c,project).length} shots need at least one review · This is not automatic approval.</span></div>
 ${list.length?list.map((sc,i)=>`<div class="scene" data-scene-row="${i}"><div><button class="btn small" data-seek-scene="${i}">${fmt(sc.start)}</button></div><div><strong>${E(sc.title)}</strong><div class="excerpt" title="${E(sc.text)}">${E(sc.text.slice(0,112))}</div><div class="small muted">${E(sc.imageRequirementId||'No scene image ID')} · ${E((sc.imageRequirementText||'ပုံမရွေးရသေး').slice(0,75))} ${sc.alignment==='manual-locked'?'· ✓ manual timing':(sc.alignment==='srt-matched'||sc.alignment==='srt-proposed')?'· ⚠ SRT timing suggestion':'· ~ estimated'} · ${sc.imageMatchStatus==='manual-confirmed'?'✓ image confirmed':sc.imageMatchStatus==='suggested-review'?'⚠ suggested ' + Math.round((sc.imageMatchScore||0)*100)+'% — check':'⚠ image review'}</div><div class="row"><button class="btn small" data-boundary="${i}" data-shift="-0.5" ${i===0?'disabled':''}>← 0.5s</button><button class="btn small" data-boundary="${i}" data-shift="0.5" ${i===0?'disabled':''}>0.5s →</button><button class="btn small" data-mark-boundary="${i}" ${i===0?'disabled':'title="Playhead ရှိနေတဲ့အချိန်ကို Scene Start အဖြစ် သတ်မှတ်မယ်"'}>Mark Start Here</button><button class="btn small" data-split-scene="${i}" title="Split this scene at current playback time; otherwise midpoint">Split at playhead</button><button class="btn small" data-merge-scene="${i}" ${i===list.length-1?'disabled':''}>Merge next</button></div></div><label class="field caption">Image Request ID<select data-req-scene="${i}"><option value="">No request</option>${reqs.map(v=>`<option value="${E(v.id)}" ${sc.imageRequirementId===v.id?'selected':''}>${E(v.id)} — ${E(v.description.slice(0,55))}</option>`).join('')}</select><span class="muted small">နောက်ခံပုံကို Scene နှင့် တိကျစွာချိတ်ရန်</span><span class="small">Scene Image</span><button type="button" class="btn small" data-confirm-scene="${i}">${sc.imageMatchStatus==='manual-confirmed'?'✓ Confirmed (click to unlock)':'✓ Confirm image match'}</button><select data-assign-scene="${i}">${sceneOptions(c)}</select></label><label class="field">Motion<select data-motion-scene="${i}"><option value="zoom" ${sc.motion==='zoom'?'selected':''}>Zoom</option><option value="pan" ${sc.motion==='pan'?'selected':''}>Pan</option><option value="still" ${sc.motion==='still'?'selected':''}>Still</option></select></label><label class="field">Seconds<input type="number" data-duration-scene="${i}" ${i===list.length-1?'disabled title="Last shot duration is fixed by chapter total"':''} value="${(+sc.duration).toFixed(2)}" min="0.25" step="0.1"/></label></div>`).join(''):'<p class="sub">Generate Scenes နှိပ်ပြီး စတင်ပါ။</p>'}</section>`;
}
function bookMergePanel(){
 const chapters=trialExports.filter(f=>/^chapter-[0-9]{1,4}-[a-zA-Z0-9_-]{8,40}\.mp4$/.test(f.name));
 const ordered=[...chapters].sort((a,b)=>Number(a.name.match(/^chapter-(\d+)/)[1])-Number(b.name.match(/^chapter-(\d+)/)[1]));
 return `<section class="panel section"><h2>📚 Full Novel — Combine Chapter MP4s</h2>
 <p class="help">အခန်း MP4 တွေထဲက အနည်းဆုံး ၂ ခုကို အစဉ်လိုက်ရွေးပါ။ Resolution၊ FPS၊ Video/Audio Codec တူမှ ပေါင်းမယ်။ မူရင်း MP4 မဖျက်ပါ။</p>
 ${ordered.length?ordered.map(f=>`<label class="folder" style="display:block;margin:7px 0;"><input type="checkbox" data-book-part="${E(f.name)}" /> &nbsp;${E(f.name)} <span class="muted small">${(f.size/1048576).toFixed(1)} MiB</span></label>`).join(''):'အခန်း MP4 အနည်းဆုံး ၂ ခု Render လုပ်ပြီး Show saved MP4 files နှိပ်ပါ။'}
 <div class="actions section"><button class="btn primary" data-action="combine-book-export" ${ordered.length<2?'disabled':''}>🎬 Combine Selected Chapters to One MP4</button><button class="btn" data-action="refresh-local-exports">Refresh MP4 List</button></div>
 <p class="sub">ပေါင်းထားတဲ့ Video ကို Export စာရင်းထဲမှာ book-…mp4 နာမည်နဲ့ တွေ့ရပါမယ်။ Preview/Full Quality မရောပါနဲ့။</p></section>`;
}
function exporter(){const s=projectStats(project);return `<div class="grid two"><section class="panel"><h2>${window.__MMMN_TRIAL__?"Windows Offline MP4 Export":"Render Package (Offline)"}</h2>${chapterSelect()}<div class="help">${window.__MMMN_TRIAL__?"ကိုယ်တိုင်ဖတ်ထားသော MP3/WAV/M4A/OGG/AAC အသံဖိုင် (သို့မဟုတ် အသံပါ Video) နဲ့ Scene ပုံတွေကို Import လုပ်ပြီး Render Current Chapter ကို နှိပ်ပါ။ ZIP ဖြည်စရာ၊ Command Run စရာ မလိုပါ။ Export MP4 ကို စက်ထဲ သိမ်းပေးမယ်။":"Scene ပုံများ၊ အသံနှင့် Timing ကို ZIP ထုတ်နိုင်သလို Native Renderer ဖြင့် MP4 တိုက်ရိုက်ထုတ်နိုင်သည်။"}</div><div class="actions section" style="${window.__MMMN_TRIAL__?'display:none':''}"><button class="btn primary" data-action="export-package">⬇ Export Complete Render ZIP</button><button class="btn" data-action="export-backup">Project Backup ZIP</button><button class="btn" data-action="import-backup">Import Project ZIP</button></div><div class="help section">Windows Portable Trial: Cross Dissolve / Pan / Zoom / Still ကို Video Timeline မှာ ရွေးပြီး Local MP4 ထုတ်နိုင်ပါတယ်။ Tauri Installer အတွက် Native Renderer က Hard Cut အဆင့်သာရှိသေးပြီး Windows စက်မှာ Compile စမ်းရဦးမယ်။</div><div class="actions section"><label class="field">Video Format <select id="native-render-preset"><option value="youtube">YouTube 16:9</option><option value="tiktok">TikTok 9:16</option><option value="facebook">Facebook 4:5</option><option value="square">Square 1:1</option></select></label><button class="btn primary" data-action="render-native-current">▶ Render Current Chapter</button>${window.__MMMN_TRIAL__?'<label class=\"field\">Quality <select id=\"native-render-quality\"><option value=\"full\">Full Quality (platform export size)</option><option value=\"preview\">Quick Preview (half resolution)</option></select></label><button class=\"btn\" data-action=\"cancel-native-render\">■ Cancel Export</button>':''}${window.__MMMN_TRIAL__?'<button class=\"btn\" data-action=\"refresh-local-exports\">Show saved MP4 files</button>':''}</div>${window.__MMMN_TRIAL__?`<div class=\"section\" id=\"native-render-status\" role=\"status\">${renderJobStatus?E(renderJobStatus.phase)+' — '+renderJobStatus.percent+'%':'No export running'}</div>`:''}${window.__MMMN_TRIAL__?`<div class=\"section\">${trialExports.length?trialExports.map(f=>`<div class=\"folder\"><a href=\"${E(f.url)}\" download=\"${E(f.name)}\">⬇ ${E(f.name)}</a> — ${Math.round(f.size/1048576*10)/10} MiB</div>`).join(''):'MP4 ကို Render လုပ်ပြီး Show saved MP4 files နှိပ်ပါ။'}</div>`:''}${window.__MMMN_TRIAL__?bookMergePanel():''}<div class=\"sub section\">အခန်း ${s.chapters} ခန်း၊ ${s.shots} Shot၊ Story-specific planned Visual ${(project.visualRequirements||[]).length} ခု၊ Import ပြီး ပုံ ${s.images} ပုံ၊ Audio ဖိုင်ပါသောအခန်း ${s.audioChapters} ခန်း။</div><div class="help warning">${window.__MMMN_TRIAL__?"အသံဖိုင် (သို့) အသံပါ Video၊ Scene ပုံများနဲ့ Timeline ကြာချိန်ကို ပြည့်စုံအောင်ထည့်ပါ။ မပြည့်စုံရင် Export ကို အလိုအလျောက် တားထားမယ်။":"ပုံ/Video မပြည့်လျှင် Final MP4 Export မလုပ်ပါ။ Draft Render သာ Placeholder သုံးနိုင်သည်။"}</div></section><section class="panel"><h2>Platform Presets</h2><div class="grid two"><div class="folder">▶ YouTube 16:9<br><span class="muted small">1920×1080</span></div><div class="folder">▯ TikTok / Reels<br><span class="muted small">1080×1920</span></div><div class="folder">▣ Square 1:1<br><span class="muted small">1080×1080</span></div><div class="folder">▥ Facebook 4:5<br><span class="muted small">1080×1350</span></div></div></section></div><section class="panel section" style="${window.__MMMN_TRIAL__?'display:none':''}"><h2>Windows Render Commands (Extracted ZIP ထဲမှာ)</h2><pre style="overflow:auto;background:#0e1b29;padding:16px;border-radius:10px;line-height:1.9">py render.py --preset youtube --chapter 1 --draft
py render.py --preset youtube --chapter 1
py render.py --preset tiktok --chapter 1
py render.py --preset facebook --chapter 1
py render.py --preset youtube --chapter all
py render.py --preset youtube --chapter 1 --source-video "C:/Videos/Chapter01.mp4" --presenter pip</pre><div class="help warning">Android APK အတွက် Codebase ပါပြီးဖြစ်ပေမဲ့ Mobile Native Video Encoder ကို မထည့်ရသေးပါ။ လက်ရှိ Windows FFmpeg MP4 Rendering ကို ဦးစားပေးထားပါတယ်။</div></section>`;}
function drive(){let folders=[['မူရင်းဝတ္ထုစာမူ (Read Only)',project.drive.sourceDocument],['Photo Library (Read Only)',project.drive.photosFolder]];return `<div class="panel"><h2>Drive → Local Studio (ONE WAY)</h2><div class="help">Google Drive ကို မူရင်းဝတ္ထုစာမူ၊ Character References၊ Scene Backgrounds များ ဖတ်ယူသည့် SOURCE အဖြစ်သာ သုံးမည်။ Narration, Timeline, Project Backup, MP4 Export တစ်ခုမှ Google Drive ကို မတင်ပါ။ ဒီ Native App သို့ ChatGPT Google Drive Connector Permission ကို အလိုအလျောက် မလွှဲနိုင်သေးပါ။ တိုက်ရိုက် Read Only Drive Sync အတွက် သီးခြား Google OAuth ခွင့်ပြုချက် လိုအပ်ပါသည်။</div></div><div class="grid two section">${folders.map(([label,url])=>`<a class="folder" href="${E(url)}" target="_blank" rel="noopener noreferrer"><span>${E(label)}</span><span>↗</span></a>`).join('')}</div><div class="panel section"><h2>Current Import Method (Free)</h2><p class="sub">Drive ထဲက BI-xxx.png ပုံတွေကို စက်ထဲ Download ပြီး Import Images နှိပ်ပါ။ စက်ထဲမှာပဲ အသံဖမ်း၊ ပုံစီ၊ MP4 ထုတ်၊ ZIP Backup သိမ်းမည်။ Project Backup ကို Windows နှင့် Android ကြား USB / Local File Transfer ဖြင့်လည်း ရွှေ့နိုင်မည်။</p><button class="btn primary" data-action="import-images">Local Images Import</button><button class="btn" data-action="import-image-folder">Folder မှ ပုံများ Import</button></div>`;}

function nativeBackupPanel(){return nativeBridge.available ? `<section class="panel section"><h2>Full-media Native Backup / Recovery</h2><p class="help">Video ကြီးများအပါအဝင် Local AppData/snapshots ထဲသို့ RAM မဖြုန်းဘဲ ကူးသိမ်းမည်။ SHA-256 နဲ့ ပြန်စစ်မည်။ ဒီ Backup သည် စက်ထဲမှာပဲရှိပြီး Google Drive သို့ မပို့ပါ။ Windows Reset/Drive Failure မဖြစ်ခင် Folder ကို External Drive ထဲ သီးခြား Copy ကူးထားပါ။</p><div class="actions"><button class="btn primary" data-action="backup-native-full">Create + Verify Full Backup</button><button class="btn" data-action="refresh-native-backups">List Saved Backups</button></div><label class="field">Local Recovery Snapshot <select id="native-backup-select">${backupList.length?backupList.map(b=>`<option value="${E(b.id)}">${E(b.id)}</option>`).join(''):'<option value="">No snapshots listed</option>'}</select></label><div class="actions"><button class="btn" data-action="verify-native-backup">Verify SHA-256</button><button class="btn" data-action="restore-native-backup">Restore Verified Backup</button></div><p class="small muted">For an independent USB/external-drive copy, close the app backup dialog and double-click COPY-VERIFIED-BACKUP-TO-USB.cmd in the extracted ZIP. It checks every SHA-256 again.</p><p class="small muted">Backup path: ${E(storageInfo?.path||'AppData')}/snapshots. Snapshot ထုတ်မီ disk free space လုံလောက်ရပါမယ်။ Restore လုပ်လျှင် Current Project ကို အရင် Snapshot ထပ်ယူပြီးမှ Media ID အသစ်တွေနဲ့ Restore လုပ်ပါတယ်။</p></section>` : '<section class="panel section"><h2>Full-media Backup</h2><p class="help warning">Windows Native App မှာပဲ Native Full Backup အသုံးပြုနိုင်မယ်။ Browser ZIP က 512 MiB ကန့်သတ်ချက်ရှိတယ်။</p></section>';}
async function refreshNativeBackups(){if(!nativeBridge.available)return;backupList=await nativeRecovery.list();}
function updates(){const cachePanel=window.__MMMN_TRIAL__?`<section class="panel section"><h2>Offline Render Cache — faster repeated exports</h2><p class="help">အခန်းထဲက ပုံ၊ Scene ကြာချိန်၊ Zoom/Pan မပြောင်းသေးရင် အရင် Encode ပြီးသား Video Scene ကို ပြန်သုံးမယ်။ Cancel ပြီး ပြန် Render လုပ်ရာမှာလည်း အချိန်သက်သာနိုင်ပါတယ်။ App ထဲမှာသာ သိမ်းပြီး Google Drive ကို မတင်ပါ။</p><p class="small muted">Temporary cache: ${renderCacheInfo?Math.round(renderCacheInfo.bytes/1048576)+" MiB / "+renderCacheInfo.files+" files":"Not checked"}. Maximum 2 GiB; older entries are cleared automatically.</p><div class="actions"><button class="btn" data-action="refresh-render-cache">Check cache size</button><button class="btn" data-action="clear-render-cache">Clear temporary cache only</button></div><p class="small muted">Cache ဖျက်ခြင်းက မူရင်း Video၊ ပုံ၊ Timeline၊ Backup နဲ့ Export MP4 ကို မဖျက်ပါ။ Export လုပ်နေစဉ် Clear မလုပ်နိုင်ပါ။</p></section>`:'';return `${nativeBackupPanel()}${cachePanel}<div class="grid two"><section class="panel"><h2>Windows Upgrade — No uninstall required</h2><div class="help">MMMN Setup.exe အသစ်ကို Version အဟောင်းရှိတဲ့ Windows User Account မှာပဲ ထပ် Run ပါ။ <b>App ကို အရင်ပိတ်ထားပြီး Setup အသစ်ထပ်တင်ပါ။</b> <b>Uninstall / Delete app data မရွေးပါနဲ့။</b> တစ်ကြိမ် Install ပြီးရင် Version အသစ်တိုင်း In-place Upgrade အတွက် NSIS current-user Mode ကို ရည်ရွယ်ထားပါတယ်။ Windows Installer ကို လက်တွေ့ Upgrade စမ်းမပြီးသေးပါ။</div><div class="actions section"><button class="btn primary" data-action="export-backup">Small-media ZIP Backup (512 MiB limit)</button><button class="btn" data-action="import-backup">Backup ZIP ပြန်သွင်း</button></div><div class="help warning">ဝတ္ထု Project Metadata ကို Native App မှာ သီးခြား User Data Folder ထဲ Auto Save လုပ်မယ်။ Browser Preview မှာ ပုံ/အသံ Blob တွေက IndexedDB မှာ ရှိနေသေးလို့ Version အဟောင်းနဲ့အသစ် သီးခြား App ID/အကောင့်သုံးမိခြင်း၊ Windows Reset သို့မဟုတ် Storage Clear လုပ်ခြင်းမှ ကာကွယ်ဖို့ ZIP Backup ထုတ်ထားပါ။ Native App မှာ Import ပြီးသော Media ကို Local AppData ထဲမှာ သိမ်းမယ်။ Browser Preview ကတော့ IndexedDB အပေါ် မူတည်နေဆဲ။</div></section><section class="panel"><h2>Local Data Directory</h2><p class="small muted">Mode: ${window.__MMMN_TRIAL__?'Local Windows Trial':nativeBridge.available?'Native Tauri app':'Browser preview only'}</p><p class="small muted">Auto Save: ${window.__MMMN_TRIAL__?'Local JSON + user media directory':nativeBridge.available?'Native JSON + local media directory':'Browser localStorage + IndexedDB'}</p><pre style="white-space:pre-wrap;word-break:break-all;background:#0e1b29;border-radius:10px;padding:12px">${E(storageInfo?.path||'Windows installer ကို စတင်ပြီးမှ Local Data Directory ကို ပြပါမယ်။')}</pre><div class="actions"><button class="btn" data-action="refresh-storage">Refresh storage details</button><button class="btn" data-action="check-media">Check all imported media</button></div><p class="sub">${lastMediaAudit ? `Media check: ${lastMediaAudit.available}/${lastMediaAudit.total} available; ${lastMediaAudit.missing.length} missing. ${E(lastMediaAudit.missing.slice(0,4).map(x=>x.name).join(", "))}` : "Media not checked in this session. Use Check all imported media before upgrades."}</p><p class="sub">Google Drive = Read Only Input. Export = Local device. Automatic online updates မဖွင့်ထားပါ — Setup.exe အသစ်ကို Download လုပ်ပြီး Install ထပ်လုပ်ရမယ်။</p></section></div>`;}
async function updateRenderJob() {
 if(!renderJobId || !window.__MMMN_TRIAL__) return;
 try {
   const status=await window.__TAURI__.core.invoke('get_render_job_status',{id:renderJobId});
   renderJobStatus=status;
   const place=$('native-render-status');
   if(place)place.textContent=`${status.phase} — ${status.percent}% (${status.completed}/${status.total})${status.error?' — '+status.error:''}`;
   if(['complete','failed','cancelled'].includes(status.status)){
     if(renderPollTimer){clearInterval(renderPollTimer);renderPollTimer=null;}
     if(status.status==='complete'){
       trialExports=await window.__TAURI__.core.invoke('list_local_exports');
       toast('Verified MP4 saved locally: '+status.output);
       if(tab==='export')await render();
     }else if(status.status==='failed')toast('MP4 Export failed: '+status.error,true);
     else toast('MP4 Export cancelled. Original media and existing MP4s preserved.');
   }
 }catch(e){
   if(renderPollTimer){clearInterval(renderPollTimer);renderPollTimer=null;}
   toast('Local render status unavailable: '+e.message,true);
 }
}

async function render(){if(!project)return;const view={overview,manuscript,assets,visuals,timeline,export:exporter,drive,updates}[tab]||overview;const app=$('app');app.innerHTML=`<div class="shell"><aside class="side"><div class="brand"><b>◈ MMMN Studio</b><small>Novel to Video • Free Offline</small></div>${nav()}<div class="side-foot">Google Drive = READ ONLY INPUT. MP4, audio, edits and backup are LOCAL ONLY.<br>Windows Offline Trial • Installer upgrade verification in preparation</div></aside><main class="main">${heading()}${view()}</main></div>`;
 if(tab==='assets'){for(const img of app.querySelectorAll('[data-image-id]')){img.src=await mediaURL(img.dataset.imageId);}}
 if(tab==='timeline'){
  const c=project.chapters[selected];app.querySelectorAll('[data-assign-scene]').forEach(el=>{el.value=c.scenes[+el.dataset.assignScene]?.assetId||'';});
  const video=$('video-player'),vurl=await mediaURL(c.videoAssetId);
  if(vurl){video.src=vurl;video.currentTime=sceneTime;video.ontimeupdate=()=>{sceneTime=video.currentTime;updatePreview();};video.onended=()=>{playing=false;};}else $('source-video-wrap').hidden=true;
  const audio=$('audio-player');const url=await mediaURL(c.audioAssetId);if(!vurl&&url){audio.src=url;audio.currentTime=sceneTime;audio.ontimeupdate=()=>{sceneTime=audio.currentTime;updatePreview();};audio.onended=()=>{playing=false;};}else audio.hidden=true;
  await updatePreview();
 }
}
async function updatePreview(){
 if(tab!=='timeline')return;
 const ch=project.chapters[selected],sc=ch.scenes.findLast(s=>sceneTime>=s.start)||ch.scenes[0];if(!sc)return;
 const index=ch.scenes.indexOf(sc);chosenScene=index;const el=$('preview');if(!el)return;
 const img=sc.assetId?await mediaURL(sc.assetId):'';
 if(el.dataset.activeScene!==String(index)||el.dataset.activeImage!==(sc.assetId||'')||el.dataset.activeMotion!==sc.motion){
   const prior=el.querySelector('img.scene-bg')?.getAttribute('src');
   const changed=el.dataset.activeScene!==undefined && el.dataset.activeScene!==String(index);
   const dissolve=changed&&img&&prior&&ch.transitionMode!=='cut'&&prior!==img;
   el.dataset.activeScene=String(index);el.dataset.activeImage=sc.assetId||'';el.dataset.activeMotion=sc.motion;
   el.innerHTML=img?`${dissolve?`<img class="scene-bg outgoing" src="${E(prior)}" alt=""/>`:''}<img class="scene-bg ${E(sc.motion)} ${dissolve?'incoming':''}" alt="Scene background" src="${E(img)}"/><div class="overlay">${E(ch.title)} · ${E(sc.title)}</div>`:`<span class="muted">Scene ${index+1}: နောက်ခံပုံရွေးပါ</span>`;
   if(dissolve)setTimeout(()=>el.querySelector('img.outgoing')?.remove(),530);
 }
 const cue=(ch.subtitleCues||[]).find(x=>sceneTime>=x.start&&sceneTime<x.end);
 let sub=$('subtitle-preview');if(!sub){sub=document.createElement('div');sub.id='subtitle-preview';sub.className='subtitle-preview';el.appendChild(sub);}
 sub.textContent=cue?.text||'';sub.hidden=!cue;
 const slider=$('time-slider');if(slider)slider.value=sceneTime;
 const label=$('time-label');if(label)label.textContent=`${fmt(sceneTime)} / ${fmt(ch.recordedSeconds||estimateSeconds(ch.text,project.settings.charsPerMinute))}`;
}
function recalcStarts(c){let t=0;for(const s of c.scenes){s.start=+t.toFixed(3);s.duration=Math.max(.2,Number(s.duration)||1);t+=s.duration;}return t;}
function persistAndRender(){save();render();}
function download(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.append(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},8000);}
async function inspectMedia(){
 const missing=[],available=[];
 for(const asset of project.assets){
  try{
   const native=await nativeInfo(asset);
   if(native){
     if(native.size!==asset.size)throw Error('Imported file size changed');
     if(asset.sha256)await nativeMedia.verify(asset.id,asset.name,asset.type,asset.sha256);
     available.push(asset.id);continue;
   }
   let blob=await browserLoadBlob(asset.id);
   if(!blob && asset.bundledUrl){const r=await fetch(asset.bundledUrl);if(r.ok)blob=await r.blob();}
   if(blob)available.push(asset.id);else missing.push({id:asset.id,name:asset.name||asset.id});
  }catch(e){missing.push({id:asset.id,name:asset.name||asset.id});}
 }
 const refs=auditMediaMetadata(project);
 for(const id of refs.brokenReferences)missing.push({id,name:`Unknown reference: ${id}`});
 return {total:project.assets.length,available:available.length,missing};
}
async function bundle(){
 const p=structuredClone(assertProjectShape(project)),files=[],missing=[];
 let bytes=0;
 for(const asset of p.assets){
  let blob=await loadBlob(asset.id);
  if(!blob && asset.bundledUrl){const response=await fetch(asset.bundledUrl);if(response.ok)blob=await response.blob();}
  if(!blob){missing.push({id:asset.id,name:asset.name||asset.id});continue;}
  bytes+=blob.size;
  if(bytes>MAX_BROWSER_BACKUP_BYTES)throw Error('Complete ZIP exceeds the safe browser memory budget (512 MiB). Do NOT use a partial backup: keep the original large video files and use a future native export.');
  const ext=(asset.name.split('.').at(-1)|| (asset.type?.startsWith('audio/')?'mp3':'png')).toLowerCase().replace(/[^a-z0-9]/g,'');
  asset.exportPath=`assets/${asset.id}.${ext}`;
  files.push({name:asset.exportPath,data:blob});
 }
 const refs=auditMediaMetadata(p);
 for(const id of refs.brokenReferences)missing.push({id,name:`Unknown reference: ${id}`});
 if(missing.length)throw Error(describeMissingMedia(missing));
 files.unshift({name:'project.json',data:JSON.stringify(p,null,2)});
 for(const f of ['render.py','transcribe_offline.py','align_pauses.py','align-pauses-windows.cmd','run-render.bat','README-RENDER.txt','visual-requirements.csv','visual-requirements.json']){
  const r=await fetch('resources/'+f);if(!r.ok)throw Error(`Cannot bundle required render resource ${f}`);
  files.push({name:f,data:new Uint8Array(await r.arrayBuffer())});
 }
 const zip=await makeZip(files);
 // A complete archive must parse and contain ALL declared media BEFORE it is offered as a backup.
 verifyBackupIndex(await readZip(zip));
 return zip;
}

async function act(action){if(backupBusy&&!['refresh-native-backups'].includes(action))return toast('Backup/Restore လုပ်နေစဉ် Project မပြင်ပါနဲ့။',true);const c=project.chapters[selected];switch(action){
 case 'undo-timeline':{const result=undoSceneEdit(c);if(!result)return toast('Undo လုပ်စရာ မရှိပါ။');save();toast('Previous timeline restored: '+result.reason);return render();}
 case 'redo-timeline':{const result=redoSceneEdit(c);if(!result)return toast('Redo လုပ်စရာ မရှိပါ။');save();toast('Timeline edit reapplied: '+result.reason);return render();}
 case 'backup-native-full':{
  if(!nativeBridge.available)return toast('Native Windows App မှာသာ Full Backup ရနိုင်ပါတယ်။',true);
  if(backupBusy)return toast('Backup/Restore တစ်ခုလုပ်ဆောင်နေပါတယ်။',true);
  backupBusy=true;
  try{
   toast('Full Backup လုပ်နေပါတယ်။ App ကို မပိတ်ပါနဲ့။');
   for(const a of project.assets||[]){
     if(!a.localStored&&!a.nativeStored)continue;
     const found=await migrateLegacyMedia(a);
     if(!found)throw Error(`Media missing: ${a.name}`);
     a.nativeStored=true;
   }
   save();await saveQueue.flush();
   const result=await nativeRecovery.create();
   await refreshNativeBackups();await render();
   alert(`Verified Full Backup created.\n${result.files} media, ${Math.round(result.bytes/1048576)} MiB.\n\n${result.path}\n\nPlease copy this folder to another local drive for disaster recovery.`);
  }catch(error){alert('Full Backup failed; existing data unchanged:\n'+error.message);}
  finally{backupBusy=false;}
  return;
 }
 case 'refresh-native-backups':{
  try{await refreshNativeBackups();await render();toast(`${backupList.length} Local Snapshot(s) တွေ့ပါပြီ။`);}catch(e){toast(e.message,true);}return;
 }
 case 'verify-native-backup':{
  const id=$('native-backup-select')?.value;if(!id)return toast('Backup ရွေးပါ။',true);
  try{toast('Media checksum များစစ်နေပါတယ်…');const info=await nativeRecovery.verify(id);alert(`Backup VERIFIED: ${info.id}\nMedia: ${info.files} files\nSize: ${Math.round(info.bytes/1048576)} MiB`);}catch(e){alert('Backup verification FAILED: '+e.message);}return;
 }
 case 'restore-native-backup':{
  const id=$('native-backup-select')?.value;if(!id)return toast('Backup ရွေးပါ။',true);
  if(backupBusy)return toast('Backup/Restore တစ်ခုလုပ်ဆောင်နေပါတယ်။',true);
  if(!confirm(`Restore backup ${id}? Current project will be snapshotted first; large files require extra free disk space. Continue?`))return;
  backupBusy=true;
  try{
   await saveQueue.flush();
   const result=await nativeRecovery.restore(id);
   project=JSON.parse(result.project); selected=0;chosenScene=0;sceneTime=0;
   for(const key of urlCache.keys())clearCachedURL(key);
   try{localStorage.setItem('mmmn-studio-state',result.project);}catch{}
   await refreshNativeBackups();await render();
   alert(`Restore finished. ${result.media} media files copied. Before-restore backup: ${result.beforeSnapshot}`);
  }catch(e){alert('Restore stopped: '+e.message);}
  finally{backupBusy=false;}
  return;
 }
 case 'check-media':{lastMediaAudit=await inspectMedia();toast(lastMediaAudit.missing.length ? `⚠ ${lastMediaAudit.missing.length} media file(s) missing. Do not upgrade without checking originals.` : `Media ${lastMediaAudit.available}/${lastMediaAudit.total} available. Create a separate ZIP backup before upgrading.`,!!lastMediaAudit.missing.length);return render();}
 case 'refresh-render-cache':{
  if(!window.__MMMN_TRIAL__)return;
  try{renderCacheInfo=await window.__TAURI__.core.invoke('render_cache_info');toast('Temporary video scene cache size checked.');await render();}
  catch(e){toast('Cache status error: '+e.message,true);}return;
 }
 case 'clear-render-cache':{
  if(!window.__MMMN_TRIAL__)return;
  if(!confirm('Clear only temporary encoded scene cache? Original video, pictures, project, saved MP4 and backups will not be removed.'))return;
  try{const result=await window.__TAURI__.core.invoke('clear_render_cache');renderCacheInfo=await window.__TAURI__.core.invoke('render_cache_info');toast(`Cleared ${result.removedCacheFiles} temporary cache files. Original media was kept.`);await render();}
  catch(e){toast('Cache not cleared: '+e.message,true);}return;
 }
 case 'refresh-storage':{storageInfo=await nativeBridge.info();toast(storageInfo?'Local data folder ကို တွေ့ပါပြီ။':'Browser Preview Mode ပါ။');return render();}
 case 'all-scenes': if(!confirm('အခန်းအားလုံး Scene ပြန်တွက်မယ်။ Manual Split/Merge နဲ့ Timing ပြင်ထားတာတွေ ပြန်ပျက်နိုင်ပါတယ်။ Continue?'))return;project.chapters.forEach(ch=>{checkpoint(ch,'Regenerate all scenes');ch.scenes=makeScenes(ch,project.settings);});save();toast('22 အခန်းလုံးကို Scene ခွဲပြီးပါပြီ။');return render();
 case 'generate-scenes': if(c.scenes?.length&&!confirm('ဒီအခန်းရဲ့ Scene Split/Merge, Manual Timing တွေ ပြန်ပျက်နိုင်ပါတယ်။ Continue?'))return;checkpoint(c,'Regenerate scene timeline');c.scenes=makeScenes(c,project.settings);save();toast('Scene Timeline အသစ်တွက်ပြီးပါပြီ။');return render();
 case 'match-scenes':tab='visuals';return render();
 case 'rebalance': checkpoint(c,'Rebalance scene durations');c.scenes=rebalanceScenes(c,c.recordedSeconds||estimateSeconds(c.text,project.settings.charsPerMinute));return persistAndRender();
 case 'export-missing':{const gaps=missingSceneImages(project,selected);download(new Blob([sceneGapsCSV(gaps)],{type:'text/csv;charset=utf-8'}),`MMMN-ch${String(c.number).padStart(2,'0')}-missing-images.csv`);toast(`${gaps.length} ပုံမဖြည့်ရသေးတဲ့ Shot စာရင်းကို စက်ထဲ Download လုပ်လိုက်ပါပြီ။`);return;}
 case 'export-proposals':{download(new Blob([visualProposalsCSV(c,c.scenes)],{type:'text/csv;charset=utf-8'}),`MMMN-ch${String(c.number).padStart(2,'0')}-picture-review.csv`);toast('ဒီအခန်းရဲ့ ပုံအကြံပြုစာရင်းကို စက်ထဲ CSV ထုတ်ပြီးပါပြီ။');return;}
 case 'export-cue-evidence':{const evidence=buildNarrationCueMap(c.scenes||[],c.subtitleCues||[]);download(new Blob([cueEvidenceCSV(c,evidence)],{type:'text/csv;charset=utf-8'}),`MMMN-ch${String(c.number).padStart(2,'0')}-cue-evidence.csv`);toast(`${evidence.matched}/${evidence.totalCues} Subtitle Cue တွေ စာမူနဲ့ ကိုက်နေပါတယ်။ CSV ကို စက်ထဲသာ သိမ်းလိုက်ပါတယ်။`);return;}
 case 'align-cue-evidence':{if(!(c.subtitleCues||[]).length){toast('ဖတ်ပြထားတဲ့ Video အတွက် မြန်မာ SRT ကို အရင် Import လုပ်ပါ။',true);return;}if(!(c.scenes||[]).length){toast('Scene များကို အရင်ခွဲပါ။',true);return;}const result=proposeNarrationBoundaries(c.scenes,c.subtitleCues,c.recordedSeconds||c.scenes.reduce((n,s)=>n+s.duration,0));if(result.error){toast('Auto Alignment blocked: '+result.error,true);return;}if(!result.matched){toast('SRT စာသားနဲ့ ဝတ္ထုစာသား ကိုက်ညီမှုမတွေ့ပါ။ Subtitle ကို အရင်စစ်ပါ။',true);return;}if(!confirm(`SRT evidence ${result.matched}/${result.totalCues} cues; ${result.proposed} scene boundaries proposed. မသေချာတဲ့အချိန်တွေကို Video နဲ့ ပြန်စစ်ရပါမယ်။ အတည်မပြုထားတဲ့ Scene Time တွေ ပြင်မယ်၊ Manual Lock မထိပါ။ ဆက်မလား?`))return;c.scenes=result.scenes;c.alignmentSummary=`Cue evidence ${result.matched}/${result.totalCues}; ${result.proposed} tentative scene boundaries; manually review all.`;save();toast('Scene ပြောင်းချိန်တွေကို SRT Evidence နဲ့ အကြံပြုညှိထားပါတယ်။ Video နဲ့ ပြန်စစ်ပြီး Mark Start Here သုံးပါ။');return render();}
 case 'export-review':{download(new Blob([sceneReviewCSV(c,project)],{type:'text/csv;charset=utf-8'}),`MMMN-ch${String(c.number).padStart(2,'0')}-review-queue.csv`);toast('Review Queue ကို စက်ထဲ CSV Download လုပ်ပြီးပါပြီ။');return;}
 case 'next-review':{const issues=sceneReviewIssues(c,project);if(!issues.length){toast('ဒီအခန်းအတွက် Review လိုတဲ့ Shot မရှိတော့ပါ။');return;}const next=issues.find(x=>x.index>chosenScene)||issues[0];chosenScene=next.index;sceneTime=c.scenes[chosenScene].start;await render();for(const id of ['video-player','audio-player']){const media=$(id);if(media?.src)media.currentTime=sceneTime;}await updatePreview();document.querySelector(`[data-scene-row="${chosenScene}"]`)?.scrollIntoView({block:'center',behavior:'smooth'});toast(`Scene ${chosenScene+1}: ${next.kinds.join(', ')}`);return;}
 case 'save-srt-editor':{const raw=$('srt-editor')?.value||'';let cues;try{cues=parseSRT(raw);if(!cues.length)throw new Error('SRT Cue မရှိပါ။');const check=subtitleDiagnostics(cues,c.recordedSeconds);if(check.warnings.length){toast('SRT timing ပြန်စစ်ပါ: '+check.warnings.slice(0,2).join(' / '),true);return;} }catch(e){toast('SRT မှားနေပါတယ်: '+e.message,true);return;}c.subtitleCues=cues;c.alignmentSummary='Edited SRT saved locally; run Align Scenes to update shot timings';save();toast(`${cues.length} Subtitle Cue များကို စက်ထဲ သိမ်းထားပြီ။`);return render();}
 case 'offline-speech-status':{
  if(!window.__MMMN_TRIAL__)return toast('Windows Trial ပေါ်မှာသာ Speech Engine Setup စစ်နိုင်ပါတယ်။',true);
  try{const status=await window.__TAURI__.core.invoke('offline_speech_status');
    alert(status.ready?`Offline Speech Engine READY\nModel: ${status.modelName}\n(မြန်မာစာ တိကျမှုကို Manual စစ်ပါ)`:
      `Offline Speech Engine မပြည့်စုံသေးပါ။\n\n${status.problems.join('\n')}\n\nModel folder: ${status.modelsFolder}\nTool folder: ${status.toolsFolder}\n\nInternet မလိုပါ။ ကိုယ်တိုင်ထည့်ထားတဲ့ Free multilingual model ကိုသာ သုံးပါ။`);
  }catch(e){toast('Speech status failed: '+e.message,true);}return;
 }
 case 'transcribe-offline':{
  if(!window.__MMMN_TRIAL__)return toast('Windows Portable Trial မှာသာ ဒီ Button ရနိုင်ပါတယ်။',true);
  const video=(project.assets||[]).find(a=>a.id===c.videoAssetId);
  const audio=(project.assets||[]).find(a=>a.id===c.audioAssetId);
  const recording=video||audio;
  if(!recording)return toast('အရင် Narration Video သို့မဟုတ် အသံဖိုင် Import လုပ်ပါ။',true);
  try{
    const status=await window.__TAURI__.core.invoke('offline_speech_status');
    if(!status.ready){alert('Offline Speech Model မပြည့်စုံသေးပါ။\n\n'+status.problems.join('\n'));return;}
    if(!confirm(`Local whisper.cpp (${status.modelName}) ဖြင့် မြန်မာအသံကို SRT ထုတ်မယ်။ CPU စွမ်းအားပေါ်မူတည်ပြီး ကြာနိုင်ပါတယ်။ အဟောင်း SRT ကို မဖျက်ခင် နောက်ထပ်အတည်ပြုပါမယ်။ ဆက်လုပ်မလား?`))return;
    toast('Offline Speech Recognition လုပ်နေပါတယ် — အလုပ်ပြီးသည်အထိ ဒီ Tab ကို မပိတ်ပါနှင့်။');
    const generated=await window.__TAURI__.core.invoke('transcribe_narration',{
      chapterNumber:c.number,sourceVideoId:recording.id,
      sourceVideoExt:recording.name.split('.').at(-1).toLowerCase()
    });
    const cues=parseSRT(generated.srt);
    if(!cues.length)throw Error('SRT Transcript တွေ့မရပါ။');
    if(c.subtitleCues?.length&&!confirm(`လက်ရှိပြင်ပြီးသား SRT ${c.subtitleCues.length} ကြောင်းရှိပါတယ်။ Auto-generated ${cues.length} ကြောင်းနဲ့ အစားထိုးမလား? (မူလ transcript ကို Local transcripts folder မှာ သီးခြားဖိုင်အဖြစ် မသိမ်းထားပါက Backup ယူပါ။)`)){
      toast('SRT အသစ်ကို Local transcripts folder ထဲ သိမ်းထားတယ်။ လက်ရှိ Editor ကို မပြောင်းပါ။');return;
    }
    checkpoint(c,'Replace offline SRT');c.subtitleCues=cues;
    c.alignmentSummary=`Local whisper.cpp ${generated.modelName}: ${cues.length} cues. Burmese proofreading REQUIRED; Scene alignment NOT automatically approved.`;
    save();await render();
    alert(`${cues.length} Subtitle cues Offline ထုတ်ပြီးပါပြီ။\nအရင် SRT Editor မှာ စာသားပြန်စစ်ပြီးမှ Narration Evidence Auto-Align ကို နှိပ်ပါ။`);
  }catch(e){toast('Offline Speech Recognition failed: '+e.message,true);alert('Offline transcription မအောင်မြင်ပါ: '+e.message);}return;
 }
 case 'analyze-narration-pauses':{
  if(!window.__MMMN_TRIAL__)return toast('Offline pause timing is available in Windows Trial.',true);
  const video=(project.assets||[]).find(a=>a.id===c.videoAssetId);
  const audio=(project.assets||[]).find(a=>a.id===c.audioAssetId);
  const recording=video||audio;
  if(!recording||!c.scenes?.length)return toast('Narration အသံဖိုင်နဲ့ Scene Timeline ကို အရင်ထည့်ပါ။',true);
  try{
    toast('FFmpeg က ဖတ်ပြသံရပ်နားချက်တွေ Offline စစ်နေပါတယ်…');
    const data=await window.__TAURI__.core.invoke('analyze_narration_pauses',{
      chapterNumber:c.number,chapterId:c.id,sourceVideoId:recording.id,
      sourceVideoExt:recording.name.split('.').at(-1).toLowerCase(),recordedSeconds:c.recordedSeconds,
      scenes:c.scenes.map(sc=>({id:sc.id,text:sc.text,start:sc.start,duration:sc.duration,alignment:sc.alignment}))
    });
    const result=applyPauseTimingPlan(c,data);
    if(!confirm(`${result.pauseCount} audio pauses found. ${result.proposed} tentative boundaries. ဒီအချိန်တွေကို Video နဲ့ ပြန်စစ်ရပါမယ်။ Apply?`))return;
    checkpoint(c,'Offline pause timing');c.scenes=result.scenes;
    c.alignmentSummary=`Offline pause analysis: ${result.proposed} suggestions, ${result.pauseCount} pauses. NOT speech recognition.`;
    save();toast('Pause Timing အကြံပြုချက်တွေ ထည့်လိုက်ပါပြီ။ ပြန်စစ်ပါ။');return render();
  }catch(e){toast('Offline pause analysis failed: '+e.message,true);alert('Offline pause analysis မအောင်မြင်ပါ: '+e.message);}
  return;
 }
 case 'import-pause-timing':return $('pause-timing-input').click();
 case 'export-srt':{if(!c.subtitleCues?.length){toast('SRT မရှိသေးပါ။',true);return;}download(new Blob([formatSRT(c.subtitleCues)],{type:'application/x-subrip;charset=utf-8'}),`MMMN-ch${String(c.number).padStart(2,'0')}-edited.srt`);toast('SRT ကို စက်ထဲ Download လုပ်ပြီးပါပြီ။');return;}

 case 'split-at-visuals':{if(!confirm('ဇာတ်ကြောင်းတစ်ခုထဲမှာ ပုံအကြောင်းအရာ ၂ မျိုး တွေ့ရင် စာကြောင်းအဆုံးမှာ Shot ခွဲမယ်။ အချိန်တွေ ခန့်မှန်းပြန်တွက်မယ်၊ Manual စစ်ဆေးရမယ်။ Confirmed Scene/Photo တွေကို မပြင်ပါ။ ဆက်မလား?'))return;const reqs=(project.visualRequirements||[]).filter(r=>r.chapter===c.number);const r=splitAtVisualChanges(c.scenes,reqs);checkpoint(c,'Split at visual changes');c.scenes=r.scenes;save();toast(`${r.added} ပုံပြောင်းမည့်နေရာအသစ် ခွဲထားပါတယ်။ Timeline နဲ့ အမှန်တကယ်ဖတ်သံကို နောက်တစ်ကြိမ်စစ်ပါ။`);return render();}
 case 'auto-edit-draft':{
   if(!c.scenes?.length){toast('Scene Timeline ကို အရင်ဖန်တီးပါ။',true);return;}
   let inputChapter=c;
   if(!c.subtitleCues?.length && window.__MMMN_TRIAL__ && (c.videoAssetId||c.audioAssetId)){
     const recording=(project.assets||[]).find(a=>a.id===(c.videoAssetId||c.audioAssetId));
     if(recording && Number(c.recordedSeconds)>0){
       try{
         toast('SRT မရှိသေးလို့ Local Audio Pause တွေ စစ်နေပါတယ်…');
         const plan=await window.__TAURI__.core.invoke('analyze_narration_pauses',{
           chapterNumber:c.number,chapterId:c.id,sourceVideoId:recording.id,
           sourceVideoExt:recording.name.split('.').at(-1).toLowerCase(),recordedSeconds:c.recordedSeconds,
           scenes:c.scenes.map(sc=>({id:sc.id,text:sc.text,start:sc.start,duration:sc.duration,alignment:sc.alignment}))
         });
         const applied=applyPauseTimingPlan(c,plan);
         inputChapter={...c,scenes:applied.scenes};
       }catch(error){toast('Pause Analyzer မရပါ; Visual-only Draft ပြုလုပ်မယ်။ '+error.message,true);}
     }
   }
   try{
     const draft=makeOfflineDraft(inputChapter,project.visualRequirements||[],project.assets||[]);
     const r=draft.report;
     if(!confirm(`Offline Auto Draft (Review only)\nScenes: ${r.scenes}\nSRT matched: ${r.matchedCues}/${r.subtitleCues}\nTiming: ${r.timingMode}\nVisual matches: ${r.visualProposals}\nLocal photos linked: ${r.imageAssignments}\nMissing pictures: ${r.missingImageCount}\nManual image decisions preserved: ${r.confirmedPreserved}\n\nမူရင်း Video/Google Drive မပြောင်းပါ။ Draft အဖြစ် Save လုပ်မလား?`))return;
     checkpoint(c,'Offline Auto Draft');c.scenes=draft.scenes;
     c.alignmentSummary=`Offline Auto Draft — ${r.timingMode}; ${r.matchedCues}/${r.subtitleCues} cues, ${r.visualProposals} scene visuals suggested; EVERY scene requires review.`;
     save();await render();toast('Auto Draft ကို Local ထဲ သိမ်းထားပြီ။ Review Queue မှာ တစ်ခုချင်းစစ်ပါ။');
   }catch(error){toast('Auto Draft stopped without modifying project: '+error.message,true);}
   return;
 }
 case 'suggest-story-visuals':{const reqs=(project.visualRequirements||[]).filter(x=>x.chapter===c.number);if(!reqs.length){toast('ဒီအခန်းအတွက် Visual Requirements မရှိပါ။',true);return;}if(!confirm('ဒီအခန်းရဲ့ အတည်မပြုရသေးတဲ့ Visual ID တွေကို စာသားအလိုက် အကြံပြုပြောင်းမယ်။ Confirmed/manual image တွေ မထိပါ။ ဆက်မလား?'))return;const r=suggestVisualMatches(c.scenes||[],reqs);checkpoint(c,'Suggest story visuals');c.scenes=r.scenes;for(const shot of c.scenes){if(shot.imageMatchStatus==='suggested-review'){const pic=(project.assets||[]).find(a=>new RegExp('^'+shot.imageRequirementId+'(?:[._-]|$)','i').test(a.name||'')&&a.type?.startsWith('image/'));shot.assetId=pic?.id||null;}}save();toast(`ပုံ ${r.proposed} ခု အကြံပြုထားပါတယ်၊ ${r.locked} ခု မပြင်ပါ၊ ${r.unmatched} ခု ပြန်စစ်ရန်လိုပါတယ်။`);return render();}
 case 'export-image-brief':case 'export-all-image-brief':{
   const chapter=action==='export-image-brief'?c.number:null;
   const brief=imageCreationBrief(project,chapter);
   download(new Blob([brief.text],{type:'text/markdown;charset=utf-8'}),
     chapter===null?'MMMN-image-brief-ALL.md':`MMMN-image-brief-ch${String(chapter).padStart(2,'0')}.md`);
   toast(`${brief.missing}/${brief.total} ပုံအတွက် Creation Brief ကို စက်ထဲထုတ်ပြီးပါပြီ။`);return;
 }
 case 'export-visual-csv':{let r=await fetch('resources/visual-requirements.csv');download(await r.blob(),'MMMN-story-image-requirements.csv');return;}
 case 'prepare-references':{
   if(!nativeMedia.available)return toast('Windows Local Trial မှာသာ Package Reference ပုံတွေ သိမ်းနိုင်ပါတယ်။',true);
   const pictures=project.assets.filter(a=>a.bundledUrl?.startsWith('resources/images/')&&a.type?.startsWith('image/'));
   let imported=0;
   try{
     for(const a of pictures){
       const url=String(a.bundledUrl);
       if(!/^resources\/images\/[a-zA-Z0-9_.-]+\.(png|jpg|jpeg|webp)$/.test(url))throw Error('Unexpected bundled photo URL');
       if(await nativeInfo(a))continue;
       const r=await fetch(url);if(!r.ok)throw Error('Missing package photo: '+a.name);
       const bytes=await r.blob();
       const receipt=await nativeMedia.store(a.id,bytes,a.name);
       a.localStored=true;a.nativeStored=true;a.size=receipt.size;a.sha256=receipt.sha256;
       imported++;
     }
     save();await saveQueue.flush();await render();
     toast(`${imported} reference photo(s) copied to this device. Source photos unchanged.`);
   }catch(error){save();toast('Local photo import failed: '+error.message,true);}
   return;
 }
 case 'import-images':return $('images-input').click();case 'import-image-folder':return $('folder-images-input').click();case 'import-video':return $('video-input').click();case 'import-srt':return $('srt-input').click();case 'align-srt':{if(!c.subtitleCues?.length){toast('အရင် SRT Transcript Import လုပ်ပါ။',true);return;}const a=alignScenesToCues(c.scenes||[],c.subtitleCues,c.recordedSeconds);c.scenes=a.scenes;c.alignmentSummary=`SRT suggestions ${a.aligned}/${a.scenes.length}; manual locks ${a.manual}; ${a.unmatched} estimated. Review required.`;save();return render();}case 'import-audio':return $('audio-input').click();case 'import-book':return $('book-input').click();case 'import-backup':return $('backup-input').click();
 case 'restore-starter':if(!confirm('Current local manuscript ကို Starter Snapshot နဲ့ အစားထိုးမှာပါ။ Backup ZIP ထုတ်ထားပြီးပြီလား?'))return;{let r=await fetch('resources/starter-project.json');project=await r.json();selected=0;chosenScene=0;save();return render();}
 case 'save-text':c.text=$('chapter-text').value;c.scenes=[];save();toast('စာသား Local Copy ကို သိမ်းလိုက်ပါပြီ။ Scene များ ပြန်တွက်ရန် လိုပါမယ်။');return render();
 case 'save-settings':project.settings.charsPerMinute=Math.min(1500,Math.max(100,Number($('cpm').value)||500));project.settings.secondsPerShot=Math.min(120,Math.max(5,Number($('shot-sec').value)||30));return persistAndRender();
 case 'toggle-play':{const a=($('video-player')?.src?$('video-player'):$('audio-player'));if(a&&!a.hidden&&a.src){if(a.paused){await a.play();playing=true}else{a.pause();playing=false}}else{playing=!playing;if(playing){clearInterval(clock);clock=setInterval(()=>{sceneTime+=.25;if(sceneTime>(c.recordedSeconds||estimateSeconds(c.text,project.settings.charsPerMinute))){playing=false;clearInterval(clock);}updatePreview();},250);}else clearInterval(clock);}const b=document.querySelector('[data-action="toggle-play"]');if(b)b.textContent=playing?'⏸ Pause':'▶ Preview';return;}
 case 'combine-book-export':{
   if(!window.__MMMN_TRIAL__)return toast('Local Windows Trial only.',true);
   if(renderJobStatus&&['queued','running','cancelling'].includes(renderJobStatus.status)){
     toast('An export is already active. Finish or Cancel it first.',true);return;
   }
   const files=[...document.querySelectorAll('input[data-book-part]:checked')].map(el=>el.dataset.bookPart);
   files.sort((a,b)=>Number(a.match(/^chapter-(\d+)/)?.[1])-Number(b.match(/^chapter-(\d+)/)?.[1]));
   if(files.length<2)return toast('အခန်း MP4 အနည်းဆုံး ၂ ခုရွေးပါ။',true);
   if(!confirm(`အခန်း MP4 ${files.length} ဖိုင်ကို အစဉ်လိုက်ပေါင်းမယ်။ မူရင်းဖိုင်တွေ မဖျက်ပါ။ ဆက်လုပ်မလား?`))return;
   try{
     renderJobStatus=await window.__TAURI__.core.invoke('start_book_merge_job',{filenames:files});
     renderJobId=renderJobStatus.id;
     if(renderPollTimer)clearInterval(renderPollTimer);
     renderPollTimer=setInterval(updateRenderJob,900);
     await updateRenderJob();
     toast('Full-novel MP4 merge started. Progress and Cancel available.');
   }catch(e){toast('Cannot combine chapters: '+e.message,true);}
   return;
 }
 case 'refresh-local-exports':{
   if(!window.__MMMN_TRIAL__)return toast('Windows Trial Mode only.',true);
   try{trialExports=await window.__TAURI__.core.invoke('list_local_exports');await render();}
   catch(e){toast('Cannot list MP4 exports: '+e.message,true);}
   return;
 }
 case 'render-native-current':{
  if(!nativeMedia.available){toast('Windows Local Trial / Native App required.',true);return;}
  try{
   if(window.__MMMN_TRIAL__ && renderJobStatus && ['queued','running','cancelling'].includes(renderJobStatus.status)){
     toast('An export is already running. Cancel or finish it first.',true);return;
   }
   await saveQueue.flush();
   const ch=project.chapters[selected];
   const request=await planNativeRender(ch,project.assets,nativeInfo,$('native-render-preset').value);
   if(window.__MMMN_TRIAL__){
     request.transitionMode=ch.transitionMode==='cut'?'cut':'dissolve';
     request.quality=$('native-render-quality')?.value||'full';
     renderJobStatus=await window.__TAURI__.core.invoke('start_render_job',request);
     renderJobId=renderJobStatus.id;
     if(renderPollTimer)clearInterval(renderPollTimer);
     renderPollTimer=setInterval(updateRenderJob,900);
     await updateRenderJob();
     toast('Local export started. Check progress below; Cancel is available.');
   }else{
     toast('Rendering current chapter locally…');
     const path=await window.__TAURI__.core.invoke('render_chapter_command',request);
     toast('Native MP4 saved: '+path);
   }
  }catch(error){toast('MP4 Export Failed: '+error.message,true);alert('Export failed without changing your project:\n'+error.message);}
  return;
 }
 case 'cancel-native-render':{
   if(!window.__MMMN_TRIAL__ || !renderJobId){toast('No export to cancel.');return;}
   try{
     renderJobStatus=await window.__TAURI__.core.invoke('cancel_render_job',{id:renderJobId});
     toast('Cancellation requested; FFmpeg will stop safely.');
     await updateRenderJob();
   }catch(e){toast('Could not cancel render: '+e.message,true);}
   return;
 }
 case 'export-package':case 'export-backup':{toast('ZIP ဖိုင်အတွက် Media များ စုစည်းနေပါသည်…');try{await saveQueue.flush();const file=await bundle();download(file,`MMMN-${project.title}-${action==='export-package'?'render':'backup'}.zip`);toast('ZIP Download ပြီးပါပြီ။ Large Video မပါလျှင် Renderer မှာ --source-video သုံးရန်လိုပါတယ်။');}catch(e){toast('ZIP Export Error: '+e.message,true)}return;}
 }}
function listen(){document.addEventListener('click',async ev=>{
 const t=ev.target.closest('[data-action],[data-tab],[data-select-chapter],[data-seek-scene],[data-boundary],[data-split-scene],[data-merge-scene],[data-mark-boundary],[data-confirm-scene],[data-seek-cue]');if(!t)return;
 if(backupBusy){toast('Backup/Restore ပြီးမှ Project ပြင်ပါ။',true);return;}
 if(t.dataset.selectChapter!==undefined){selected=+t.dataset.selectChapter;chosenScene=0;sceneTime=0;playing=false;clearInterval(clock);}
 if(t.dataset.seekCue!==undefined){sceneTime=Number(t.dataset.seekCue)||0;for(const id of ['video-player','audio-player']){const a=$(id);if(a?.src)a.currentTime=sceneTime;}return updatePreview();}
 if(t.dataset.seekScene!==undefined){chosenScene=+t.dataset.seekScene;sceneTime=project.chapters[selected].scenes[chosenScene]?.start||0;for(const id of ['video-player','audio-player']){let a=$(id);if(a?.src)a.currentTime=sceneTime;}return updatePreview();}
 if(t.dataset.boundary!==undefined){const c=project.chapters[selected];c.scenes=retimeBoundary(c.scenes,Number(t.dataset.boundary),Number(t.dataset.shift));const b=Number(t.dataset.boundary);if(c.scenes[b])c.scenes[b].alignment='manual-locked';save();return render();}
 if(t.dataset.markBoundary!==undefined){const c=project.chapters[selected],i=Number(t.dataset.markBoundary),before=c.scenes.map(s=>s.duration);c.scenes=setBoundaryAtTime(c.scenes,i,sceneTime);if(c.scenes.every((s,j)=>s.duration===before[j])){toast('Playhead ကို ရွှေ့ပြီးမှ Mark Start Here နှိပ်ပါ။ Adjacent Scene တွေ အလွန်တိုလျှင် မပြောင်းပါ။',true);return;}save();toast('ပုံပြောင်းချိန်ကို လက်ရှိ Video Playhead နဲ့ ချိန်လိုက်ပါပြီ။');return render();}
 if(t.dataset.confirmScene!==undefined){const c=project.chapters[selected],i=Number(t.dataset.confirmScene),s=c.scenes[i];if(!s.imageRequirementId||!s.assetId){toast('Visual ID နဲ့ Scene ပုံ နှစ်ခုလုံး ရွေးပြီးမှ Confirm လုပ်ပါ။',true);return;}c.scenes=setSceneVisualConfirmation(c.scenes,i,s.imageMatchStatus!=='manual-confirmed');save();return render();}
 if(t.dataset.splitScene!==undefined){const c=project.chapters[selected],i=Number(t.dataset.splitScene),sc=c.scenes[i];let offset=sceneTime-sc.start;if(offset<.5||offset>sc.duration-.5)offset=sc.duration/2;const before=c.scenes.length;checkpoint(c,'Split scene at playhead');c.scenes=splitSceneAt(c.scenes,i,offset);if(c.scenes.length===before){toast('Scene အလွန်တိုနေပါတယ်။ Split မလုပ်နိုင်ပါ။',true);return;}chosenScene=i;save();toast('Scene ကို နှစ်ပိုင်းခွဲပြီးပါပြီ။ ဒုတိယ Scene အတွက် Background Image စစ်ပါ။');return render();}
 if(t.dataset.mergeScene!==undefined){const c=project.chapters[selected],i=Number(t.dataset.mergeScene),a=c.scenes[i],b=c.scenes[i+1];if(!b)return;if(a.assetId&&b.assetId&&a.assetId!==b.assetId&&!confirm('Scene နှစ်ခုမှာ မတူတဲ့ ပုံတွေရှိပါတယ်။ ပထမ Scene ပုံကိုသာ ထားမယ်။ Continue?'))return;checkpoint(c,'Merge adjacent scenes');c.scenes=mergeSceneWithNext(c.scenes,i);chosenScene=i;save();toast('Scene နှစ်ခု ပေါင်းပြီးပါပြီ။ Visual Match စစ်ပါ။');return render();}
 if(t.dataset.tab){tab=t.dataset.tab;playing=false;clearInterval(clock);await render();return;}
 if(t.dataset.action)await act(t.dataset.action);
 });
 document.addEventListener('input',ev=>{if(ev.target.id==='time-slider'){sceneTime=+ev.target.value;for(const id of ['video-player','audio-player']){const a=$(id);if(a?.src)a.currentTime=sceneTime;}updatePreview();}});
 document.addEventListener('change',async ev=>{
 if(backupBusy){toast('Backup/Restore ပြီးမှ ပြင်ပါ။',true);return;}
 const t=ev.target,c=project.chapters[selected];
 if(t.id==='chapter-select'){selected=+t.value;chosenScene=0;sceneTime=0;playing=false;clearInterval(clock);return render();}
 if(t.id==='time-slider'){sceneTime=+t.value;for(const id of ['video-player','audio-player']){let a=$(id);if(a?.src)a.currentTime=sceneTime;}return updatePreview();}
 if(t.id==='presenter-mode'){c.presenterMode=t.value;save();return;}
 if(t.id==='transition-mode'){c.transitionMode=t.value;save();return;}
 if(t.dataset.reqScene!==undefined){const sc=c.scenes[+t.dataset.reqScene],req=(project.visualRequirements||[]).find(r=>r.id===t.value);sc.imageRequirementId=req?.id||null;sc.imageRequirementText=req?.description||'';sc.imageMatchStatus='manual-review';sc.visualLocked=false;const linked=(project.assets||[]).find(a=>req && new RegExp('^'+req.id+'(?:[._-]|$)','i').test(a.name||''));if(linked)sc.assetId=linked.id;save();return render();}
 if(t.dataset.assignScene!==undefined){const scene=c.scenes[+t.dataset.assignScene];scene.assetId=t.value||null;scene.imageMatchStatus='manual-review';scene.visualLocked=false;save();return render();}
 if(t.dataset.motionScene!==undefined){c.scenes[+t.dataset.motionScene].motion=t.value;save();return updatePreview();}
 if(t.dataset.durationScene!==undefined){const i=+t.dataset.durationScene;c.scenes=setSceneDurationKeepingTotal(c.scenes,i,Number(t.value));if(c.scenes[i+1])c.scenes[i+1].alignment='manual-locked';save();return render();}
 });
 async function importImageFiles(input){
   if(backupBusy){toast('Backup/Restore ပြီးမှ Media Import လုပ်ပါ။',true);return;}
   let count=0,skipped=0;const files=[...input.files];
   for(const file of files){
     if(!file.type.startsWith('image/'))continue;
     // Exact filename replaces the local entry, so corrected ChatGPT art can be imported again.
     const existing=(project.assets||[]).find(a=>a.origin==='local'&&a.name.toLowerCase()===file.name.toLowerCase());
     const id=(nativeMedia.available||!existing)?'asset-'+crypto.randomUUID():existing.id;
     let receipt;
     try{receipt=await storeBlob(id,file);}catch(err){skipped++;toast('Media Import: '+err.message,true);continue;}
     if(existing){const oldId=existing.id;Object.assign(existing,{id,label:file.name,type:file.type,size:file.size,nativeStored:nativeMedia.available,sha256:receipt?.sha256||null});clearCachedURL(oldId);for(const chapter of project.chapters)for(const sc of chapter.scenes||[])if(sc.assetId===oldId)sc.assetId=id;}
     else project.assets.push({id,name:file.name,label:file.name,origin:'local',type:file.type,size:file.size,nativeStored:nativeMedia.available,sha256:receipt?.sha256||null});
     const match=/^(BI-\d{3})(?:[._-]|$)/i.exec(file.name);
     if(match){const req=(project.visualRequirements||[]).find(x=>x.id.toLowerCase()===match[1].toLowerCase());
       if(req){req.status='local-ready';req.localFile=file.name;
         for(const ch of project.chapters)for(const shot of ch.scenes||[])if(shot.imageRequirementId===req.id&&shot.imageMatchStatus!=='manual-confirmed')shot.assetId=id;
       }
     }
     count++;
   }
   save();toast(`${count} ပုံ Import/Update ပြီးပါပြီ။ ${skipped?skipped+' ပုံ Storage မလုံလောက်၍ မရ။':''}`);input.value='';await render();
 }
 $('images-input').onchange=ev=>importImageFiles(ev.target);
 $('folder-images-input').onchange=ev=>importImageFiles(ev.target);
 $('video-input').onchange=async ev=>{const file=ev.target.files?.[0];if(!file)return;
 const id='video-'+crypto.randomUUID(),c=project.chapters[selected];
 // Native Windows imports use bounded chunks; no arbitrary 200 MB cutoff.
 let receipt;
 try{receipt=await storeBlob(id,file);}catch(error){toast('Video Import မအောင်မြင်ပါ: '+error.message,true);ev.target.value='';return;}
 project.assets.push({id,name:file.name,label:file.name,type:file.type||'video/mp4',size:file.size,localStored:true,nativeStored:nativeMedia.available,sha256:receipt?.sha256||null});
 c.videoAssetId=id;c.audioAssetId=null;
 const video=document.createElement('video');video.preload='metadata';const temp=URL.createObjectURL(file);video.src=temp;
 video.onloadedmetadata=()=>{if(Number.isFinite(video.duration)&&video.duration>0){const timing=reconcileRecordingDuration(c,video.duration);c.recordedSeconds=video.duration;c.scenes=timing.scenes;c.timingNeedsReview=timing.needsReview;toast(timing.reason,timing.needsReview);}else toast('Video duration မဖတ်နိုင်ပါ။',true);save();URL.revokeObjectURL(temp);render();};
 video.onerror=()=>{URL.revokeObjectURL(temp);save();toast('Video ဖိုင် Metadata မဖတ်နိုင်သေးပါ။',true);render();};ev.target.value='';};
 $('pause-timing-input').onchange=async ev=>{const f=ev.target.files?.[0];if(!f)return;
   try{const data=JSON.parse(await f.text()),c=project.chapters[selected];
     const result=applyPauseTimingPlan(c,data);if(!confirm(`Audio pauses based timing: ${result.proposed} suggested changes, ${result.pauseCount} pauses. မူရင်းအသံနားထောင်ပြီး အချိန်တိုင်းပြန်စစ်ရပါမယ်။ Apply?`))return;
     checkpoint(c,'Import pause timing JSON');c.scenes=result.scenes;c.alignmentSummary=`Offline silence-aware timing: ${result.proposed} proposed, ${result.pauseCount} pauses. Not transcript alignment; review required.`;
     save();toast('Pause-based scene times imported. Video ဖြင့် ပြန်စစ်ပါ။');return render();
   }catch(e){toast('Timing JSON import failed: '+e.message,true);}
   finally{ev.target.value='';}
 };
 $('srt-input').onchange=async ev=>{const f=ev.target.files?.[0];if(!f)return;try{const cues=parseSRT(await f.text());if(!cues.length)throw Error('Valid subtitles not found');const c=project.chapters[selected];checkpoint(c,'Import SRT transcript');c.subtitleCues=cues;save();toast(`${cues.length} Subtitle Cue Import ပြီးပါပြီ။ Align ကို ထပ်နှိပ်ပါ။`);render();}catch(e){toast('SRT Import Error: '+e.message,true);}ev.target.value='';};
 $('audio-input').onchange=async ev=>{let file=ev.target.files?.[0];if(!file)return;const id='audio-'+crypto.randomUUID();let receipt;try{receipt=await storeBlob(id,file);}catch(error){toast('Audio Import failed without replacing earlier recording: '+error.message,true);ev.target.value='';return;}project.assets.push({id,name:file.name,label:file.name,type:file.type||'audio/mpeg',size:file.size,localStored:true,nativeStored:nativeMedia.available,sha256:receipt?.sha256||null});const c=project.chapters[selected];c.audioAssetId=id;c.videoAssetId=null;
 const temp=URL.createObjectURL(file),audio=new Audio();audio.preload='metadata';audio.src=temp;audio.onloadedmetadata=()=>{if(Number.isFinite(audio.duration)&&audio.duration>0){const timing=reconcileRecordingDuration(c,audio.duration);c.recordedSeconds=audio.duration;c.scenes=timing.scenes;c.timingNeedsReview=timing.needsReview;toast(timing.reason,timing.needsReview);}else toast('Audio duration မဖတ်နိုင်ပါ။',true);save();URL.revokeObjectURL(temp);render();};audio.onerror=()=>{save();URL.revokeObjectURL(temp);toast('အသံထည့်ပြီးပါပြီ။ Duration မဖတ်နိုင်သေးပါ။',true);render();};ev.target.value='';};
 $('book-input').onchange=async ev=>{let file=ev.target.files?.[0];if(!file)return;const s=await file.text();if(!confirm('Local chapters အားလုံးကို ဒီစာမူနဲ့ အစားထိုးမှာပါ။ ဆက်လုပ်မလား?'))return;project.chapters=splitChapters(s);selected=0;chosenScene=0;sceneTime=0;save();toast('စာမူကို အခန်းများ ခွဲပြီး Import လုပ်ပြီးပါပြီ။');ev.target.value='';render();};
 $('backup-input').onchange=async ev=>{const f=ev.target.files?.[0];if(!f)return;try{const files=await readZip(f);let raw=files.get('project.json');if(!raw)throw Error('project.json not found');const {project:verifiedBackup}=verifyBackupIndex(files);if(!confirm('ဒီ Backup က Current Local Project ကို အစားထိုးပါမယ်။ ဆက်လုပ်မလား?'))return;const p=remapBackupForSafeRestore(verifiedBackup,()=>crypto.randomUUID());for(const a of p.assets){await storeBlob(a.id,new Blob([files.get(a.exportPath)],{type:a.type||'application/octet-stream'}),a.name);}project=p;selected=0;chosenScene=0;sceneTime=0;save();toast('Backup + Media Import ပြီးပါပြီ။');render();}catch(e){toast('Backup Import failed: '+e.message,true);}ev.target.value='';};
}
// Ctrl+S confirms the latest native snapshot rather than invoking Save Web Page.
document.addEventListener('keydown',async event=>{
 if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){
  event.preventDefault();
  try{await saveQueue.flush();toast('Latest MMMN timeline and project saved locally.');}
  catch(error){toast('Project save failed: '+error.message,true);}
 }
});
// A long disk write must not be silently interrupted by closing the window.
window.addEventListener('beforeunload',event=>{
 if(saveQueue.pending>0||backupBusy){event.preventDefault();event.returnValue='';}
});
async function init(){try{const existing=localStorage.getItem('mmmn-studio-state');const nativeText=await nativeBridge.load();const starter=await (await fetch('resources/starter-project.json')).json();const choice=pickProject(nativeText,existing,starter);project=choice.project;storageInfo=await nativeBridge.info();if(choice.source!=='native')save();listen();await render();if(window.__MMMN_TRIAL__){const running=await window.__TAURI__.core.invoke('current_render_job');if(running){renderJobId=running.id;renderJobStatus=running;renderPollTimer=setInterval(updateRenderJob,900);await updateRenderJob();}}}catch(e){$('app').innerHTML=`<div class="loading">Error: ${E(e.message)}<p>Data မပျက်အောင် App က Auto Reset မလုပ်ထားပါ။ ZIP Backup ရှိပါက ပြန်သွင်းနိုင်ပါသည်။</p></div>`;}}
init();
