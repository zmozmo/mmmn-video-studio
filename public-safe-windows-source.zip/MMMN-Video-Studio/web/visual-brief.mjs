/** Deterministic, offline-only visual creation checklist from the user's existing Story Bible.
 * Never invent an image or assert that a requested illustration already exists. */
export function imageCreationBrief(project, chapterNumber=null) {
  if (!project || !Array.isArray(project.visualRequirements)) throw Error('Visual plan missing');
  const all=project.visualRequirements;
  const included=all.filter(r=>chapterNumber===null||r.chapter===chapterNumber);
  const available=new Set((project.assets||[]).filter(a=>a?.type?.startsWith('image/'))
    .flatMap(a=> {const m=/^(BI-\d{3})(?:[._-]|$)/i.exec(a.name||'');return m?[m[1].toUpperCase()]:[];}));
  const missing=included.filter(r=>r.status!=='local-ready'&&!available.has(r.id?.toUpperCase()));
  const lines=[`# ${project.title||'MMMN'} — Offline Image Creation Brief`,
    '',`Chapter: ${chapterNumber===null?'All':chapterNumber}`,
    `Planned distinct pictures: ${included.length}`,
    `Missing pictures: ${missing.length}`,'',
    '## Rules','',
    '- Use the exact Visual ID as the image filename (example: BI-001.png).',
    '- Keep era, setting, costume and recurring characters consistent with the actual novel.',
    '- Produce landscape 16:9 master artwork, place subjects near center to support vertical crops.',
    '- No captions, logos, watermark or written text in the images.',
    '- These are drafts from a planning list, NOT automatically generated images.',
    '- ChatGPT can create images separately; save originals to your chosen Google Drive novel photo folder, then DOWNLOAD/IMPORT into this offline studio.',
    '- This app does not upload, export or write any files to Google Drive.','',
    '## Missing scene-specific pictures',''];
  if(!missing.length)lines.push('No outstanding images under current plan.');
  for (const r of missing) {
    lines.push(`### ${r.id}.png — Chapter ${r.chapter}`, '',
      `Scene requirement: ${r.description||'No description in visual plan'}`, '',
      `Illustration guidance: ${r.promptGuide||'Cinematic historical Myanmar scene, accurate to manuscript'}`, '',
      `Filename: ${r.id}.png`, '');
  }
  return {text:lines.join('\n'),missing:missing.length,total:included.length};
}
