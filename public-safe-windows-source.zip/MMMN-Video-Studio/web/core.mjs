export function estimateSeconds(text, charsPerMinute=500) {
  const n=Array.from((text||'').replace(/\s+/gu,'').trim()).length;
  return Math.max(1,Math.round(n/Math.max(100,Number(charsPerMinute)||500)*60));
}
export function makeScenes(chapter, settings={}) {
  const charsPerMinute=Number(settings.charsPerMinute)||500;
  const secondsPerShot=Number(settings.secondsPerShot)||30;
  const target=Math.max(80,Math.round(charsPerMinute*secondsPerShot/60));
  const paras=(chapter.text||'').split(/\n+/).map(s=>s.trim()).filter(Boolean);
  const parts=[]; let current='';
  for(const p of paras) {
    if(current.length && current.length+p.length>target*1.45) {parts.push(current); current='';}
    if(p.length > target*1.6) {
      if(current) {parts.push(current); current='';}
      // Preserve exact text; split long paragraphs at sentence boundaries when possible.
      const phrases=p.match(/[^။!?]+[။!?]?/gu)||[p]; let buff='';
      for (const phrase of phrases) {
        if (buff && buff.length+phrase.length>target*1.25) {parts.push(buff.trim());buff='';}
        buff+=phrase;
      }
      if(buff) current=buff.trim();
    } else current += (current?' ':'')+p;
  }
  if(current) parts.push(current);
  if(!parts.length) parts.push('(စာမူ မထည့်ရသေးပါ)');
  const d=chapter.recordedSeconds>0?chapter.recordedSeconds:estimateSeconds(chapter.text,charsPerMinute);
  const weights=parts.map(x=>Math.max(10,Array.from(x).length));
  const total=weights.reduce((a,b)=>a+b,0);let t=0;
  const scenes=parts.map((part,i)=> {
    const sec=(i===parts.length-1)?Math.max(.2,d-t):d*weights[i]/total;
    const s={id:`${chapter.id}-s${i+1}`,title:`Scene ${i+1}`,text:part,start:+t.toFixed(3),duration:+sec.toFixed(3),assetId:chapter.scenes?.[i]?.assetId||null,motion:chapter.scenes?.[i]?.motion||'zoom', imageRequirementId:chapter.scenes?.[i]?.imageRequirementId||null,imageRequirementText:chapter.scenes?.[i]?.imageRequirementText||'',imageMatchStatus:chapter.scenes?.[i]?.imageMatchStatus||'unplanned'};
    t+=sec;return s;
  });
  return scenes;
}
export function rebalanceScenes(chapter, seconds) {
  const scenes=chapter.scenes||[];
  if(!scenes.length)return [];
  const d=Math.max(1,Number(seconds)||1);let t=0;
  const weights=scenes.map(s=>Math.max(1,Array.from(s.text||'').length));
  const total=weights.reduce((a,b)=>a+b,0);
  return scenes.map((scene,i)=> {const duration=i===scenes.length-1?Math.max(.2,d-t):d*weights[i]/total;const result={...scene,start:+t.toFixed(3),duration:+duration.toFixed(3)};t+=duration;return result;});
}
export function projectStats(project) {
 const chapters=project.chapters||[];
 const estimatedSeconds=chapters.reduce((sum,c)=>sum+(c.recordedSeconds>0?c.recordedSeconds:estimateSeconds(c.text,project.settings?.charsPerMinute)),0);
 const shots=chapters.reduce((sum,c)=>sum+(c.scenes||[]).length,0);
 const charCount=chapters.reduce((sum,c)=>sum+Array.from(c.text||'').length,0);
 return {chapters:chapters.length,estimatedSeconds,shots,charCount,images:(project.assets||[]).filter(a=>a.type?.startsWith('image/')).length,audioChapters:chapters.filter(c=>c.audioAssetId||c.videoAssetId).length};
}
export function timecode(s) {let t=Math.floor(Math.max(0,s||0));return `${String(Math.floor(t/3600)).padStart(2,'0')}:${String(Math.floor(t%3600/60)).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`;}
export function splitChapters(text) {
 const ls=String(text||'').replace(/\r/g,'').split('\n');let sections=[];let current=null;
 for (const l of ls) {
   if (/^\s*အခန်း\s*\([၀-၉0-9]+\)/u.test(l)||/^\s*Chapter\s+\d+/i.test(l)) {
     if(current)sections.push(current);
     current={id:`ch${sections.length+1}`,number:sections.length+1,title:l.trim(),text:'',audioAssetId:null,recordedSeconds:null,scenes:[]};
   } else if(current) current.text+=(current.text?'\n':'')+l;
 }
 if(current)sections.push(current);
 if(!sections.length)sections=[{id:'ch1',number:1,title:'အခန်း (၁)',text:String(text||''),audioAssetId:null,recordedSeconds:null,scenes:[]}];
 return sections.map(x=>({...x,text:x.text.trim()}));
}


// Subtitle timestamps are real narration anchors, not an estimate derived from book length.
export function parseSRT(data) {
  const txt=String(data||'').replace(/\r/g,'').replace(/^\uFEFF/,'');
  const time=t=>{const m=t.trim().replace('.',',').match(/^(\d{1,2}):(\d{2}):(\d{2}),(\d{1,3})$/);if(!m)throw Error('Invalid subtitle timestamp: '+t);return Number(m[1])*3600+Number(m[2])*60+Number(m[3])+Number(m[4].padEnd(3,'0'))/1000;};
  const cues=[];
  for (const part of txt.split(/\n\s*\n/g)) {
    const lines=part.split('\n').map(x=>x.trim()).filter(Boolean);
    const ix=lines.findIndex(x=>x.includes('-->'));
    if(ix<0)continue;
    const ends=lines[ix].split(/\s+-->\s+/);if(ends.length!==2)continue;
    const a=time(ends[0]),b=time(ends[1].split(' ')[0]);
    if(b>a)cues.push({start:a,end:b,text:lines.slice(ix+1).join(' ')});
  }
  cues.sort((a,b)=>a.start-b.start);
  return cues;
}

function srtTimestamp(seconds) {
  let m=Math.round(Math.max(0,Number(seconds)||0)*1000);
  const h=Math.floor(m/3600000);m%=3600000;
  const min=Math.floor(m/60000);m%=60000;
  const sec=Math.floor(m/1000),ms=m%1000;
  return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}:${String(sec).padStart(2,'0')},${String(ms).padStart(3,'0')}`;
}
export function formatSRT(cues=[]) {
  return (cues||[]).filter(c=>Number.isFinite(c.start)&&Number.isFinite(c.end)&&c.end>c.start)
    .map((c,i)=>`${i+1}\n${srtTimestamp(c.start)} --> ${srtTimestamp(c.end)}\n${String(c.text||'').trim()}`)
    .join('\n\n')+'\n';
}
export function subtitleDiagnostics(cues=[],videoSeconds=0) {
  const warnings=[];
  const sorted=[...cues].sort((a,b)=>a.start-b.start);
  const end=Number(videoSeconds)||0;
  for(let i=0;i<sorted.length;i++) {
    const c=sorted[i];
    if(!Number.isFinite(c.start)||!Number.isFinite(c.end)||c.start<0||c.end<=c.start)
      warnings.push(`Cue ${i+1}: invalid timing`);
    if(i&&c.start<sorted[i-1].end-.025)
      warnings.push(`Cue ${i+1}: overlaps the preceding cue`);
    if(end>0&&c.end>end+.25)
      warnings.push(`Cue ${i+1}: extends beyond the recorded video`);
  }
  return {count:sorted.length,warnings,first:sorted[0]?.start??null,last:sorted.at(-1)?.end??null};
}

function grams(text){const plain=String(text||'').normalize('NFC').replace(/[\s\p{P}\p{S}\p{Cf}]/gu,''); const result=new Set();for(let i=0;i+3<=plain.length;i++)result.add(plain.slice(i,i+3));return result;}
function similarity(a,b){const x=grams(a),y=grams(b);if(!x.size||!y.size)return 0;let n=0;for(const a of x)if(y.has(a))n++;return n/Math.min(x.size,y.size);}
/** Match subtitle cues to scenes in chronological order; report unmatched instead of inventing precision.
 * Matching may fail for paraphrased/corrected narration. Review every timestamp.
 */
/** Conservative chronological subtitle-to-story alignment.
 * SRT is an externally supplied *hypothesis*: timestamps never become approved
 * until the human reviews the scene. Manually locked boundaries are immutable.
 */
export function alignScenesToCues(scenes,cues,totalSeconds,threshold=.34) {
  const ss=(scenes||[]).map(s=>({...s}));
  if(!ss.length)return {scenes:ss,aligned:0,unmatched:0,manual:0,rejected:0};
  const valid=(cues||[]).filter(c=>Number.isFinite(c.start)&&Number.isFinite(c.end)&&c.start>=0&&c.end>c.start)
    .sort((a,b)=>a.start-b.start);
  const originalTotal=ss.reduce((sum,s)=>sum+(Number(s.duration)||0),0);
  const duration=Math.max(.5,Number(totalSeconds)||originalTotal||valid.at(-1)?.end||1);
  const minStep=.25;
  const fixed=[{scene:0,time:0,kind:'boundary'}];
  for(let i=1;i<ss.length;i++)if(ss[i].alignment==='manual-locked'&&Number.isFinite(ss[i].start)){
    const t=Number(ss[i].start);
    if(t>fixed.at(-1).time+(i-fixed.at(-1).scene)*minStep && t<duration-(ss.length-i)*minStep)
      fixed.push({scene:i,time:t,kind:'manual'});
  }
  fixed.push({scene:ss.length,time:duration,kind:'boundary'});
  const anchors=[...fixed],used=new Set();let rejected=0;
  for(let k=0;k<fixed.length-1;k++){
    const from=fixed[k],to=fixed[k+1];let priorTime=from.time,priorScene=from.scene;
    let cursor=0;
    for(let i=from.scene;i<to.scene;i++){
      if(fixed.some(x=>x.scene===i&&x.kind==='manual'))continue;
      let best=-1,bestScore=0;
      for(let j=cursor;j<valid.length;j++){
        const c=valid[j];
        if(c.start>=to.time)break;
        // Leave >=250 ms for every scene until the next human anchor.
        if(c.start<priorTime+(i-priorScene)*minStep-0.001 ||
           c.start>to.time-(to.scene-i)*minStep)continue;
        if(used.has(j))continue;
        const score=similarity(ss[i].text,c.text);
        if(score>bestScore){best=j;bestScore=score;}
      }
      if(best>=0&&bestScore>=threshold){
        const time=valid[best].start;
        if(i>from.scene || time>from.time+.001){
          anchors.push({scene:i,time,kind:'subtitle'});
          priorTime=time;priorScene=i;
        }
        used.add(best);cursor=best+1;
        ss[i].alignment='srt-matched';ss[i].alignmentScore=+bestScore.toFixed(3);
      } else if(ss[i].alignment!=='manual-locked'){
        ss[i].alignment='estimated';ss[i].alignmentScore=0;
      }
    }
  }
  // A manual anchor has precedence if any cue proposed the exact same boundary.
  const unique=new Map();
  for(const a of anchors.sort((a,b)=>a.scene-b.scene||({manual:0,boundary:1,subtitle:2}[a.kind]-{manual:0,boundary:1,subtitle:2}[b.kind]))){
    if(!unique.has(a.scene))unique.set(a.scene,a);
  }
  const times=[...unique.values()].sort((a,b)=>a.scene-b.scene);
  let usedAnchors=0;
  for(let i=0;i<times.length-1;i++){
    const a=times[i],b=times[i+1],items=ss.slice(a.scene,b.scene);
    if(!items.length)continue;
    if(b.time<=a.time+minStep*items.length-.0001){rejected++;continue;}
    const weights=items.map(x=>Math.max(1,Array.from(x.text||'').length));
    const totalWeight=weights.reduce((x,y)=>x+y,0);
    const available=b.time-a.time-minStep*items.length;
    let running=a.time,acc=0;
    for(let j=0;j<items.length;j++){
      const index=a.scene+j;
      ss[index].start=+running.toFixed(3);
      acc+=weights[j];
      const end=j===items.length-1?b.time:a.time+minStep*(j+1)+available*acc/totalWeight;
      ss[index].duration=+(end-running).toFixed(3);
      running=end;
    }
    if(b.kind==='subtitle')usedAnchors++;
  }
  const manual=ss.filter(s=>s.alignment==='manual-locked').length;
  const aligned=ss.filter(s=>s.alignment==='srt-matched').length;
  return {scenes:ss,aligned,unmatched:ss.length-aligned-manual,manual,rejected};
}
export function retimeBoundary(scenes,boundary,delta,min=.25) {
  // Move only the boundary between neighboring shots; keep chapter total unchanged.
  if(boundary<=0||boundary>=scenes.length)return scenes.map(x=>({...x}));
  const r=scenes.map(x=>({...x})),left=r[boundary-1],right=r[boundary];
  const adj=Math.min(Math.max(Number(delta)||0,-left.duration+min),right.duration-min);
  left.duration=+(left.duration+adj).toFixed(3);right.duration=+(right.duration-adj).toFixed(3);
  let t=0;for(const s of r){s.start=+t.toFixed(3);t+=s.duration;}return r;
}


// Manual story-scene tools. These operate on a local project copy only.
function recomputeTimeline(scenes) {
  let t=0;
  return scenes.map(scene=>{
    const duration=+Math.max(.25,Number(scene.duration)||.25).toFixed(3);
    const item={...scene,start:+t.toFixed(3),duration};
    t+=duration;return item;
  });
}
function closestReadableSplit(text,ratio){
  const chars=Array.from(String(text||''));
  if(chars.length<2)return ['',String(text||'')];
  const target=Math.max(1,Math.min(chars.length-1,Math.round(chars.length*ratio)));
  let best=target, score=Infinity;
  for(let i=1;i<chars.length;i++){
    if(!/[။!?\s]/u.test(chars[i-1]))continue;
    const delta=Math.abs(i-target);
    // Prefer a sentence boundary close to the time ratio, otherwise whitespace.
    const weight=/[။!?]/u.test(chars[i-1])?.45:1;
    const v=delta*weight;
    if(v<score){score=v;best=i;}
  }
  return [chars.slice(0,best).join('').trim(),chars.slice(best).join('').trim()];
}
export function splitSceneAt(scenes,index,secondsIntoScene){
  if(!Array.isArray(scenes)||index<0||index>=scenes.length)return scenes.map(x=>({...x}));
  const scene=scenes[index],duration=Number(scene.duration)||0;
  const left=Number(secondsIntoScene);
  if(!Number.isFinite(left)||left<.5||left>duration-.5)return scenes.map(x=>({...x}));
  const [a,b]=closestReadableSplit(scene.text||'',left/duration);
  const knownIds=new Set(scenes.map(x=>x.id));
  const base=String(scene.id||'scene')+'-split';let id=base,seq=2;
  while(knownIds.has(id)){id=base+seq;seq++;}
  const first={...scene,text:a,duration:+left.toFixed(3),alignment:'manual-review'};
  const second={...scene,id,text:b,duration:+(duration-left).toFixed(3),alignment:'manual-review',imageMatchStatus:'manual-review'};
  return recomputeTimeline([...scenes.slice(0,index),first,second,...scenes.slice(index+1)]);
}
export function mergeSceneWithNext(scenes,index){
  if(!Array.isArray(scenes)||index<0||index+1>=scenes.length)return scenes.map(x=>({...x}));
  const a=scenes[index],b=scenes[index+1];
  const text=[a.text,b.text].filter(Boolean).join('\n');
  const merged={...a,text,duration:+((Number(a.duration)||0)+(Number(b.duration)||0)).toFixed(3),alignment:'manual-review',imageMatchStatus:'manual-review'};
  return recomputeTimeline([...scenes.slice(0,index),merged,...scenes.slice(index+2)]);
}
export function setSceneDurationKeepingTotal(scenes,index,wanted,min=.25){
  if(!Array.isArray(scenes)||index<0||index>=scenes.length-1)return scenes.map(x=>({...x}));
  const d=Number(wanted);
  if(!Number.isFinite(d))return scenes.map(x=>({...x}));
  return retimeBoundary(scenes,index+1,d-(Number(scenes[index].duration)||0),min);
}
export function missingSceneImages(project,chapterIndex=null){
  const chapters=chapterIndex===null?(project.chapters||[]):[project.chapters?.[chapterIndex]].filter(Boolean);
  const assets=new Set((project.assets||[]).filter(x=>x.type?.startsWith('image/')).map(x=>x.id));
  const gaps=[];
  for(const ch of chapters)for(const scene of ch.scenes||[]){
    if(!scene.assetId || !assets.has(scene.assetId))gaps.push({chapter:ch.number,sceneId:scene.id,start:scene.start||0,requirement:scene.imageRequirementId||'',description:scene.imageRequirementText||scene.text?.slice(0,100)||''});
  }
  return gaps;
}
export function csvEscape(v){const x=String(v??'');return /[,\r\n"]/.test(x)?'"'+x.replaceAll('"','""')+'"':x;}
export function sceneGapsCSV(gaps){return '\uFEFF'+[['Chapter','Scene ID','Start seconds','Image ID','Visual description'],...gaps.map(x=>[x.chapter,x.sceneId,x.start,x.requirement,x.description])].map(row=>row.map(csvEscape).join(',')).join('\r\n');}


// Offline, explainable story-to-picture suggestions (not a generative language model).
// A proposal never silently changes a scene already confirmed by its editor.
const VISUAL_STOP_WORDS=new Set(['အတွက်','ဖြင့်','တွင်','အတွင်း','နောက်','နေသည်','ထဲမှာ','အပေါ်','တစ်ခု','သည်','များ','တစ်','ပုံ','ထဲက','အနီး','အပြင်','ကြသည်','အခန်း','ဦးသက်ထွန်း','ထွဋ်ခေါင်','အောင်ကြိုင်','ပျိုမေခင်','မောင်ခိန်','ဘိုးသိုက်မောင်း','ခုနှစ်များ','ခုနှစ်']);
function normalizedVisualText(value){
  return String(value||'').normalize('NFC').toLowerCase().replace(/[\u200b-\u200d\ufeff]/gu,'').replace(/[၊။၊!?.,:;()\[\]«»“”'"\-—]/gu,' ').replace(/\s+/gu,' ').trim();
}
function termList(value) {
  return [...new Set(normalizedVisualText(value).split(/\s+/u).filter(x=>Array.from(x).length>=4&&!VISUAL_STOP_WORDS.has(x)&&!/^\d+$/u.test(x)))];
}
export function visualTextScore(storyText,requirementDescription){
  const story=normalizedVisualText(storyText),terms=termList(requirementDescription);
  if(!story||!terms.length)return 0;
  const weight=t=>Math.min(3,Math.max(1,Array.from(t).length/5));
  function termMatch(t){
    if(story.includes(t))return 1;
    const stem=t.replace(/(များ|နှင့်|တို့|တွင်|ထဲက|အနီး|အတွက်|ကို|မှ)$/u,'');
    if(stem!==t&&Array.from(stem).length>=6&&story.includes(stem))return .9;
    // Myanmar compounds combine words without spaces; recognize a distinctive
    // long shared fragment, but assign LOWER confidence than an exact match.
    const chars=Array.from(t),min=Math.max(7,Math.ceil(chars.length*.45));
    if(min>chars.length)return 0;
    for(let i=0;i<=chars.length-min;i++)if(story.includes(chars.slice(i,i+min).join('')))return .65;
    return 0;
  }
  return +Math.min(1,terms.reduce((n,t)=>n+weight(t)*termMatch(t),0)/Math.max(1,terms.reduce((n,t)=>n+weight(t),0))).toFixed(4);
}

export function suggestVisualMatches(scenes,requirements,options={}){
  const threshold=Number(options.threshold??.22);
  const reqs=(requirements||[]).filter(r=>r.id&&r.description).sort((a,b)=>(a.order||0)-(b.order||0));
  const sortedScenes=scenes||[];
  let lastOrder=0,proposed=0,locked=0,unmatched=0;
  const updated=sortedScenes.map(scene=>{
    const existing=scene.imageRequirementId;
    const manual=scene.imageMatchStatus==='manual-confirmed'||scene.imageMatchStatus==='manual-review'&&scene.assetId;
    // Manually selected images, or explicitly confirmed links, must be preserved.
    if(manual||(existing&&scene.visualLocked)){locked++;return {...scene};}
    let best=null,score=0;
    for(const r of reqs){
      const order=r.order||0;
      // Story order is a nudge, never a prerequisite: flashbacks are allowed.
      const sim=visualTextScore(scene.text,r.description);
      const adjusted=sim*(order+2<lastOrder ? 0.88 : 1);
      if(adjusted>score){score=adjusted;best=r;}
    }
    if(best && score>=threshold){
      lastOrder=best.order||lastOrder; proposed++;
      return {...scene,imageRequirementId:best.id,imageRequirementText:best.description,imageMatchStatus:'suggested-review',imageMatchScore:+score.toFixed(3),visualLocked:false};
    }
    unmatched++;return {...scene,imageRequirementId:existing||null,imageMatchStatus:existing?'previous-estimate':'unmatched-review',imageMatchScore:0};
  });
  return {scenes:updated,proposed,locked,unmatched};
}
export function setSceneVisualConfirmation(scenes,index,confirmed=true){
  return (scenes||[]).map((s,i)=>i!==index?{...s}:{...s,visualLocked:confirmed,imageMatchStatus:confirmed?'manual-confirmed':'suggested-review'});
}
export function setBoundaryAtTime(scenes,boundary,absoluteSeconds,min=.25){
  const current=(scenes||[])[boundary]?.start;
  if(!Number.isFinite(Number(absoluteSeconds))||!Number.isFinite(Number(current)))return (scenes||[]).map(s=>({...s}));
  const adjusted=retimeBoundary(scenes,boundary,Number(absoluteSeconds)-Number(current),min);
  if(Math.abs(adjusted[boundary].start-Number(current))>0.0005){
    adjusted[boundary].alignment='manual-locked';
    adjusted[boundary].alignmentScore=null;
  }
  return adjusted;
}
export function visualProposalsCSV(chapter,scenes){
  const rows=[['Chapter','Start seconds','End seconds','Scene ID','Image Request','Match score','Review status','Scene text preview']];
  for(const s of scenes||[])rows.push([chapter?.number||'',s.start,+(Number(s.start)+Number(s.duration)).toFixed(3),s.id,s.imageRequirementId||'',s.imageMatchScore??'',s.imageMatchStatus||'',String(s.text||'').slice(0,160)]);
  return '\uFEFF'+rows.map(x=>x.map(csvEscape).join(',')).join('\r\n');
}


// Optional pre-edit split to expose a second picture inside the same long scene.
// Cuts only at the source text's own sentence punctuation. No content is invented.
export function splitAtVisualChanges(scenes,requirements,options={}) {
 const maxNewPerScene=Math.max(1,Math.min(4,Number(options.maxNewPerScene)||2));
 const threshold=Number(options.threshold??.21);
 let added=0;
 const result=[];
 for(const scene of scenes||[]) {
  if(scene.visualLocked||scene.imageMatchStatus==='manual-confirmed'||scene.assetId){result.push({...scene});continue;}
  const phrases=(String(scene.text||'').match(/[^။!?]+[။!?]?/gu)||[]).map(x=>x.trim()).filter(Boolean);
  if(phrases.length<2||Number(scene.duration)<4){result.push({...scene});continue;}
  const probes=phrases.map(phrase=>suggestVisualMatches([{text:phrase}],requirements,{threshold}).scenes[0]);
  // Attach unmatched sentences to their preceding visual; preserve the phrase order.
  let current=probes[0]?.imageMatchStatus==='suggested-review'?probes[0].imageRequirementId:null;
  const parts=[];let buffer=[];
  for(let k=0;k<phrases.length;k++){
   const next=probes[k]?.imageMatchStatus==='suggested-review'?probes[k].imageRequirementId:null;
   if(buffer.length && next && current && next!==current && parts.length<maxNewPerScene){parts.push({text:buffer.join(' '),id:current});buffer=[];current=next;}
   else if(!current&&next)current=next;
   buffer.push(phrases[k]);
  }
  if(buffer.length)parts.push({text:buffer.join(' '),id:current});
  if(parts.length===1){result.push({...scene});continue;}
  const sum=parts.reduce((n,x)=>n+Array.from(x.text).length,0);
  let remaining=Number(scene.duration);let used=0;
  for(let k=0;k<parts.length;k++){
   const d=k===parts.length-1?remaining:Math.max(.25,Number(scene.duration)*Array.from(parts[k].text).length/sum);
   const dur=+d.toFixed(3);remaining=+(remaining-dur).toFixed(3);
   const match=(requirements||[]).find(r=>r.id===parts[k].id);
   result.push({...scene,id:k?`${scene.id}-v${k+1}`:scene.id,
     text:parts[k].text,duration:dur,imageRequirementId:match?.id||scene.imageRequirementId||null,
     imageRequirementText:match?.description||scene.imageRequirementText||'',imageMatchStatus:'suggested-review',
     imageMatchScore:null,assetId:null,alignment:'estimated-after-visual-split'});
  }
  used+=parts.length-1;added+=parts.length-1;
 }
 // Exact start recomputation prevents gaps at the original narration position.
 return {scenes:recomputeTimeline(result),added};
}

// Local-only quality gate. Review is advisory; final renderer separately enforces media existence.
export function sceneReviewIssues(chapter,project={}) {
  const ready=new Set((project.assets||[]).filter(a=>a.type?.startsWith('image/')).map(a=>a.id));
  const issues=[];
  for(let index=0;index<(chapter.scenes||[]).length;index++){
    const s=chapter.scenes[index];
    const kinds=[];
    if(!s.assetId||!ready.has(s.assetId))kinds.push('missing-picture');
    else if(s.imageMatchStatus!=='manual-confirmed')kinds.push('picture-unconfirmed');
    if(s.alignment!=='srt-matched'&&s.alignment!=='manual-locked')kinds.push('timing-estimated');
    if(kinds.length)issues.push({index,id:s.id,start:s.start,requirement:s.imageRequirementId||'',kinds});
  }
  return issues;
}
export function sceneReviewCSV(chapter,project) {
  const rows=[['Chapter','Scene','Start seconds','Image ID','Review issues']];
  for(const issue of sceneReviewIssues(chapter,project))
    rows.push([chapter.number,issue.id,issue.start,issue.requirement,issue.kinds.join('; ')]);
  return '\uFEFF'+rows.map(row=>row.map(csvEscape).join(',')).join('\r\n');
}


// Evidence-first SRT alignment. Does NOT claim to understand the actual video.
// A cue is accepted only when its words follow the source manuscript in order.
// Manual-locked boundaries remain authoritative, and all proposed boundaries
// require a human review while playing the narrator video.
function plainNarrationText(value) {
  return String(value||'').normalize('NFC').replace(/[\s\p{P}\p{S}\p{Cf}]/gu,'');
}
function sharedTrigramScore(a,b){
  if(a.length<4||b.length<4)return 0;
  const needle=new Set();
  for(let i=0;i<=a.length-3;i++)needle.add(a.slice(i,i+3));
  let common=0;
  for(const g of needle)if(b.includes(g))common++;
  return common/needle.size;
}
export function buildNarrationCueMap(scenes,cues) {
  const segments=(scenes||[]).map(s=>plainNarrationText(s.text));
  const valid=(cues||[]).filter(c=>Number.isFinite(c.start)&&Number.isFinite(c.end)&&c.start>=0&&c.end>c.start)
    .sort((a,b)=>a.start-b.start);
  const evidence=segments.map((_,i)=>({sceneIndex:i,first:null,last:null,cueCount:0,confidence:0,exactCount:0,examples:[]}));
  let lastScene=0,offset=0,matched=0,unmatched=0,exact=0;
  for(const cue of valid){
    const needle=plainNarrationText(cue.text);
    if(needle.length<5){unmatched++;continue;}
    let chosen=-1,score=0,at=-1,isExact=false;
    // Exact quotations from the narration script are the strongest possible evidence.
    for(let i=lastScene;i<segments.length;i++){
      const pos=segments[i].indexOf(needle,i===lastScene?offset:0);
      if(pos>=0){chosen=i;at=pos;score=1;isExact=true;break;}
    }
    if(chosen<0){
      // A conservative fallback for small ASR spelling differences. Keep order.
      // The score measures coverage of the *cue*, not the entire long scene.
      let best=0;
      for(let i=lastScene;i<Math.min(segments.length,lastScene+5);i++){
        const candidate=segments[i].slice(i===lastScene?offset:0);
        const value=sharedTrigramScore(needle,candidate);
        if(value>best){best=value;chosen=i;score=value;}
      }
      if(best<.66){unmatched++;continue;}
    }
    if(chosen<0){unmatched++;continue;}
    lastScene=chosen;
    offset=isExact?at+needle.length:offset;
    const e=evidence[chosen];
    if(e.first===null)e.first=cue.start;
    e.last=cue.end;e.confidence+=score;e.cueCount++;
    if(isExact){e.exactCount++;exact++;}
    if(e.examples.length<2)e.examples.push(String(cue.text).slice(0,100));
    matched++;
  }
  for(const e of evidence)if(e.cueCount)e.confidence=+(e.confidence/e.cueCount).toFixed(3);
  return {evidence,totalCues:valid.length,matched,unmatched,exact};
}
export function proposeNarrationBoundaries(scenes,cues,totalSeconds) {
  const src=(scenes||[]).map(s=>({...s}));
  const map=buildNarrationCueMap(src,cues);
  const n=src.length;
  if(!n)return {...map,scenes:src,proposed:0,held:0};
  const duration=Math.max(.5,Number(totalSeconds)||src.reduce((s,x)=>s+(Number(x.duration)||0),0));
  const min=.35;
  if(duration<n*min)return {...map,scenes:src,proposed:0,held:0,error:'Narration too short for this number of scenes'};
  const anchors=[{index:0,time:0,kind:'edge'}];
  for(let i=1;i<n;i++)if(src[i].alignment==='manual-locked'&&Number.isFinite(Number(src[i].start)))
    anchors.push({index:i,time:Number(src[i].start),kind:'manual'});
  anchors.push({index:n,time:duration,kind:'edge'});
  const fixed=anchors.sort((a,b)=>a.index-b.index);
  let held=0,proposed=0;
  for(let i=1;i<n;i++){
    if(src[i].alignment==='manual-locked')continue;
    const e=map.evidence[i];
    if(e.first===null||e.confidence<.66){held++;continue;}
    const before=fixed.filter(x=>x.index<i).at(-1);
    const after=fixed.find(x=>x.index>i);
    const t=e.first;
    if(!before||!after||t<=before.time+(i-before.index)*min||t>=after.time-(after.index-i)*min){held++;continue;}
    anchors.push({index:i,time:t,kind:'cue'});proposed++;
  }
  // Later evidence can be noisy: only retain anchors with strictly increasing
  // times, and never allow cue evidence to override a human-manual anchor.
  const kept=[];let skipped=0;
  for(const item of anchors.sort((a,b)=>a.index-b.index)){
    const ahead=anchors.filter(x=>x.index>item.index&&x.kind!=='cue').sort((a,b)=>a.index-b.index)[0];
    const prior=kept.at(-1);
    if(item.kind==='cue'&&(prior&&item.time<=prior.time+(item.index-prior.index)*min ||
      ahead&&item.time>=ahead.time-(ahead.index-item.index)*min)){skipped++;continue;}
    if(item.kind!=='cue'&&prior&&item.time<=prior.time+(item.index-prior.index)*min){
      // Corrupt input: bail instead of moving an approved manual boundary.
      return {...map,scenes:src,proposed:0,held,error:'Manual locks are inconsistent with video duration'};
    }
    kept.push(item);
  }
  if(proposed-skipped===0)return {...map,scenes:src,proposed:0,held:held+skipped};
  for(let k=0;k<kept.length-1;k++){
    const a=kept[k],b=kept[k+1],section=src.slice(a.index,b.index);
    const weights=section.map(x=>Math.max(1,Array.from(x.text||'').length));
    const sum=weights.reduce((x,y)=>x+y,0);
    const available=b.time-a.time-min*section.length;
    if(available<-.0001)continue;
    let totalWeight=0,t=a.time;
    for(let j=0;j<section.length;j++){
      const s=src[a.index+j];totalWeight+=weights[j];
      const end=j===section.length-1?b.time:a.time+(j+1)*min+available*totalWeight/sum;
      s.start=+t.toFixed(3);s.duration=+(end-t).toFixed(3);
      if(s.alignment!=='manual-locked'){
        s.alignment=j===0&&a.kind==='cue'?'srt-proposed':'estimated';
        s.alignmentScore=j===0&&a.kind==='cue'?map.evidence[a.index+j].confidence:0;
      }
      t=end;
    }
  }
  return {...map,scenes:src,proposed:proposed-skipped,held:held+skipped};
}
export function cueEvidenceCSV(chapter,cueMap){
  const rows=[['Chapter','Scene ID','First subtitle seconds','Last subtitle seconds','Matched cues','Exact matches','Confidence','Review required','Subtitle sample']];
  for(const e of cueMap.evidence||[]){const sc=chapter.scenes?.[e.sceneIndex]||{};
    rows.push([chapter.number||'',sc.id||'',e.first??'',e.last??'',e.cueCount,e.exactCount,e.confidence,'YES',e.examples.join(' | ')]);
  }
  return '\uFEFF'+rows.map(row=>row.map(csvEscape).join(',')).join('\r\n');
}

/** Import an OFFLINE CPU pause analysis JSON, never claim this is speech recognition.
 * Reject mismatched chapter/shot/duration data atomically. Preserve manually
 * approved boundaries and existing SRT evidence; never silently shift them.
 */
export function applyPauseTimingPlan(chapter, plan, durationTolerance=1.0) {
  if(!chapter || !plan || plan.schema!=='mmmn.pause-timing.v1')throw Error('Unknown pause timing format');
  if(plan.humanReviewRequired!==true)throw Error('Timing source must be marked for human review');
  const old=chapter.scenes||[], incoming=plan.scenes||[];
  if(!old.length||incoming.length!==old.length)throw Error('Shot count differs: export a fresh Render ZIP first');
  if(Number(plan.chapterNumber)!==Number(chapter.number)||plan.chapterId!==chapter.id)
    throw Error('Wrong chapter: timing file belongs to another chapter');
  const total=Number(plan.duration), expected=Number(chapter.recordedSeconds);
  if(!Number.isFinite(total)||total<=0)throw Error('Invalid recording duration');
  if(Number.isFinite(expected)&&expected>0&&Math.abs(total-expected)>durationTolerance)
    throw Error('Recording duration differs from the loaded video; import matching recording');
  const limits=[];
  for(let i=0;i<old.length;i++){
    const entry=incoming[i],original=old[i];
    if(!entry||entry.index!==i||entry.sceneId!==original.id)throw Error(`Scene ID mismatch at ${i+1}`);
    const a=Number(entry.start),b=Number(entry.end);
    if(!Number.isFinite(a)||!Number.isFinite(b)||a<0||b-a<.25-1e-6)
      throw Error(`Invalid timing at Scene ${i+1}`);
    if(i===0&&Math.abs(a)>.005)throw Error('First scene must start at 0');
    if(i>0&&Math.abs(a-limits[i-1])>.006)throw Error('Timeline has a gap or overlap');
    if(original.alignment==='manual-locked'&&Math.abs(Number(original.start)-a)>.006)
      throw Error(`Scene ${i+1} has manual lock and cannot move`);
    if(['srt-matched','srt-proposed'].includes(original.alignment)&&Math.abs(Number(original.start)-a)>.006)
      throw Error(`Scene ${i+1} has stronger SRT evidence: review it before using pause timing`);
    limits.push(b);
  }
  if(Math.abs(limits.at(-1)-total)>.006)throw Error('Final scene does not end with recording');
  const result=old.map((scene,i)=>{
    const current=incoming[i];
    const keep=['manual-locked','srt-matched','srt-proposed'].includes(scene.alignment);
    return {...scene,start:current.start,duration:+(current.end-current.start).toFixed(3),
      alignment:keep?scene.alignment:current.status==='pause-proposed'?'pause-proposed':'length-estimated',
      timingEvidence:keep?scene.timingEvidence||'Manually checked/SRT':current.note,
      timingNeedsReview:!keep};
  });
  return {scenes:result,pauseCount:Number(plan.pauseCount)||0,
          proposed:result.filter(x=>x.alignment==='pause-proposed').length};
}

/** Never wipe manual/SRT timing when replacing a narration recording. */
export function reconcileRecordingDuration(chapter, seconds, tolerance=.5) {
  const duration=Number(seconds);
  if(!Number.isFinite(duration)||duration<=0)throw Error('Recording duration is invalid');
  const scenes=chapter?.scenes||[];
  const previously=Number(chapter.recordedSeconds)||scenes.reduce((sum,s)=>sum+(Number(s.duration)||0),0);
  const protectedTiming=scenes.some(s=>['manual-locked','srt-matched','srt-proposed'].includes(s.alignment));
  if(protectedTiming && Math.abs(duration-previously)>tolerance)
    return {scenes, rebalanced:false, needsReview:true, reason:'Manual/SRT timings preserved: recording duration changed'};
  if(Math.abs(duration-previously)<=tolerance)
    return {scenes, rebalanced:false, needsReview:false,reason:'Recording duration unchanged'};
  return {scenes:rebalanceScenes(chapter,duration),rebalanced:true,needsReview:true,
          reason:'Estimated timings rebalanced; review before export'};
}
