/** Local-only safety checks: never claim an incomplete media archive is a complete backup. */
export const MAX_BROWSER_BACKUP_BYTES = 512 * 1024 * 1024;

export function assertProjectShape(project) {
  if (!project || typeof project !== 'object' || !Array.isArray(project.chapters) || !Array.isArray(project.assets)) {
    throw Error('Invalid project metadata: expected chapters and assets arrays.');
  }
  const ids = new Set();
  for (const asset of project.assets) {
    if (!asset || typeof asset.id !== 'string' || !/^[A-Za-z0-9_-]{1,120}$/.test(asset.id)) {
      throw Error('Invalid asset identifier in project metadata.');
    }
    if (ids.has(asset.id)) throw Error(`Duplicate asset identifier: ${asset.id}`);
    ids.add(asset.id);
  }
  return project;
}

export function auditMediaMetadata(project) {
  assertProjectShape(project);
  const referenced = new Set();
  for (const chapter of project.chapters) {
    for (const field of ['audioAssetId', 'videoAssetId']) if (chapter[field]) referenced.add(chapter[field]);
    for (const scene of chapter.scenes || []) if (scene.assetId) referenced.add(scene.assetId);
  }
  const known = new Set(project.assets.map(a => a.id));
  const brokenReferences = [...referenced].filter(id => !known.has(id));
  return {assetCount: project.assets.length, referencedCount: referenced.size, brokenReferences};
}

export function verifyBackupIndex(files) {
  const raw = files.get('project.json');
  if (!raw) throw Error('Backup has no project.json. Nothing was restored.');
  const project = assertProjectShape(JSON.parse(new TextDecoder().decode(raw)));
  const missing = [], unused = [];
  for (const asset of project.assets) {
    if (!asset.exportPath || !files.has(asset.exportPath)) missing.push(asset.name || asset.id);
  }
  if (missing.length) throw Error(`Incomplete ZIP backup: ${missing.length} media file(s) missing (${missing.slice(0,5).join(', ')}). Nothing was restored.`);
  const refs = auditMediaMetadata(project);
  if (refs.brokenReferences.length) throw Error(`ZIP backup references ${refs.brokenReferences.length} unknown media ID(s). Nothing was restored.`);
  for (const name of files.keys()) if (name.startsWith('assets/') && !project.assets.some(a => a.exportPath === name)) unused.push(name);
  return {project, mediaCount: project.assets.length, extraMedia: unused};
}

export function describeMissingMedia(missing) {
  const preview = missing.slice(0,6).map(x=>x.name || x.id).join(', ');
  return `Complete ZIP backup NOT created: ${missing.length} source media item(s) are unavailable. ${preview}. Keep original videos, re-import missing pictures/audio, and retry. The app has not changed your saved project.`;
}

/** Copy-on-write restore: never overwrite IDs/blobs used by the CURRENT project. */
export function remapBackupForSafeRestore(input, makeId){
  const p=structuredClone(assertProjectShape(input));
  const idMap=new Map();
  for(const a of p.assets){
    const newId=`restored-${makeId()}`;
    if(!/^[A-Za-z0-9_-]{1,120}$/.test(newId))throw Error('Invalid generated restore asset ID');
    idMap.set(a.id,newId);a.id=newId;
  }
  const replace=id=>idMap.get(id)||id;
  for(const ch of p.chapters){
    if(ch.audioAssetId)ch.audioAssetId=replace(ch.audioAssetId);
    if(ch.videoAssetId)ch.videoAssetId=replace(ch.videoAssetId);
    for(const s of ch.scenes||[])if(s.assetId)s.assetId=replace(s.assetId);
  }
  return p;
}
