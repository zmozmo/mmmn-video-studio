/** Safe offline one-click *draft*: text evidence, not fictional semantic AI.
 * Never modifies narrator video, the original manuscript, or any Drive folder.
 * All generated decisions remain explicitly unapproved and reviewable.
 */
import {proposeNarrationBoundaries,subtitleDiagnostics,suggestVisualMatches} from './core.mjs';

export function makeOfflineDraft(chapter, requirements=[], assets=[]) {
  if (!chapter || !Array.isArray(chapter.scenes) || !chapter.scenes.length)
    throw Error('Generate chapter scenes before Auto Draft.');
  const original=chapter.scenes;
  const duration=Number(chapter.recordedSeconds)||original.reduce((a,s)=>a+Number(s.duration||0),0);
  if (!Number.isFinite(duration) || duration<=0) throw Error('Narration runtime missing.');
  const cues=Array.isArray(chapter.subtitleCues)?chapter.subtitleCues:[];
  let scenes=original.map(s=>({...s}));
  let matchedCues=0,proposedBoundaries=0;
  let timingMode='estimated; needs narrator pause/SRT review';
  if(cues.length){
    const diagnostics=subtitleDiagnostics(cues,duration);
    if(diagnostics.warnings.length)
      throw Error('SRT timestamps require review: '+diagnostics.warnings.slice(0,2).join('; '));
    const aligned=proposeNarrationBoundaries(scenes,cues,duration);
    if(aligned.error) throw Error('SRT scene alignment unsafe: '+aligned.error);
    matchedCues=aligned.matched;
    if(aligned.matched>0){
      scenes=aligned.scenes;
      proposedBoundaries=aligned.proposed;
      timingMode='SRT manuscript evidence; unapproved suggestions';
    } else timingMode='SRT does not match manuscript; original times kept';
  }
  const req=(requirements||[]).filter(r=>Number(r.chapter)===Number(chapter.number));
  const suggested=suggestVisualMatches(scenes,req);
  const pictures=(assets||[]).filter(a=>a?.type?.startsWith('image/') && typeof a.name==='string');
  const index=new Map();
  for(const p of pictures){
    const match=p.name.match(/^([A-Za-z]{1,8}-\d{1,6})(?:[._-]|$)/);
    if(match&&!index.has(match[1].toUpperCase()))index.set(match[1].toUpperCase(),p.id);
  }
  let imageAssignments=0,missingImageCount=0,confirmed=0;
  const newScenes=suggested.scenes.map((scene,i)=>{
    const existing=original[i];
    if(existing.visualLocked || existing.imageMatchStatus==='manual-confirmed' ||
       (existing.imageMatchStatus==='manual-review' && existing.assetId)){
      confirmed++;
      return {...scene,assetId:existing.assetId};
    }
    const proposal=scene.imageRequirementId ? index.get(String(scene.imageRequirementId).toUpperCase()):null;
    if(proposal){
      if(scene.assetId!==proposal)imageAssignments++;
      return {...scene,assetId:proposal,imageMatchStatus:'suggested-review',visualLocked:false};
    }
    if(!scene.assetId)missingImageCount++;
    // Do not replace another image merely because the text matcher is uncertain.
    return scene;
  });
  const total=newScenes.reduce((sum,s)=>sum+Number(s.duration||0),0);
  if(Math.abs(total-duration)>.51)throw Error('Auto Draft would change total narration duration; no changes saved.');
  for(let i=1;i<newScenes.length;i++){
    if(original[i].alignment==='manual-locked' &&
       Math.abs(Number(original[i].start)-Number(newScenes[i].start))>.001)
       throw Error('Auto Draft tried to move a manually locked scene. No changes saved.');
  }
  return {scenes:newScenes,report:{scenes:newScenes.length,subtitleCues:cues.length,
    matchedCues,proposedBoundaries,timingMode,visualProposals:suggested.proposed,
    imageAssignments,missingImageCount,confirmedPreserved:confirmed,
    reviewRequired:true,automaticApproval:false}};
}
