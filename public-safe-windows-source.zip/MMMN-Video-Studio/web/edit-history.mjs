/** Persistent, offline scene-edit checkpoints; images/video are never copied or deleted. */
const MAX_HISTORY = 6;
function capture(chapter, reason='Timeline edit', at=Date.now()) {
  if (!chapter || !Array.isArray(chapter.scenes)) throw Error('Chapter scenes missing');
  return {reason:String(reason).slice(0,96),at,
    scenes:structuredClone(chapter.scenes),
    subtitleCues:structuredClone(chapter.subtitleCues||[]),
    alignmentSummary:chapter.alignmentSummary||'',
    timingNeedsReview:!!chapter.timingNeedsReview};
}
function put(chapter, key, item) {
  const previous=Array.isArray(chapter[key])?chapter[key]:[];
  chapter[key]=[...previous,item].slice(-MAX_HISTORY);
}
export function checkpoint(chapter, reason) {
  put(chapter,'undoHistory',capture(chapter,reason));
  chapter.redoHistory=[];
  return chapter.undoHistory.length;
}
function swap(chapter, from, to) {
  if(!Array.isArray(chapter[from])||!chapter[from].length)return null;
  const entry=chapter[from].at(-1);
  if(!entry || !Array.isArray(entry.scenes))throw Error('Recovery checkpoint damaged; current scenes unchanged');
  const current=capture(chapter,entry.reason);
  // Clone BEFORE changing any property: corrupt payloads must never partially restore.
  const restored=structuredClone(entry);
  put(chapter,to,current);
  chapter[from]=chapter[from].slice(0,-1);
  chapter.scenes=restored.scenes;
  chapter.subtitleCues=restored.subtitleCues;
  chapter.alignmentSummary=restored.alignmentSummary;
  chapter.timingNeedsReview=restored.timingNeedsReview;
  return {reason:entry.reason,remaining:chapter[from].length};
}
export const undoSceneEdit = chapter => swap(chapter,'undoHistory','redoHistory');
export const redoSceneEdit = chapter => swap(chapter,'redoHistory','undoHistory');
