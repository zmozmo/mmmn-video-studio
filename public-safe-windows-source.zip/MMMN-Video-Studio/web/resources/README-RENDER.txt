MMMN v0.6 — Local-only CPU Render Package
Requires free Python 3, ffmpeg and ffprobe (in PATH). No paid API/GPU/cloud.
Examples, from extracted Render ZIP folder:
 py render.py --preset youtube --chapter 1 --source-video "C:\Recordings\Chapter01.mp4" --presenter pip
 py render.py --preset youtube --chapter 1 --source-video "C:\Recordings\Chapter01.mp4" --presenter none
 py render.py --preset tiktok --chapter 1 --source-video "C:\Recordings\Chapter01.mp4"
 py render.py --preset reels --chapter 1 --source-video "C:\Recordings\Chapter01.mp4"
 py render.py --preset facebook --chapter 1 --source-video "C:\Recordings\Chapter01.mp4"
 py render.py --preset youtube --chapter 1 --draft
 py render.py --preset youtube --chapter all
Presets: youtube=1920x1080; tiktok/reels/shorts=1080x1920; facebook=1080x1350; square=1080x1080.
PIP=original video as inset (NOT transparent presenter). Background images change at scene boundaries with small blended transitions when selected. No subtitle burn-in at this version: imported SRT is for timing/preview; video editing work continues locally.
For final rendering, all scene images AND narration source must be provided. Missing media blocks final output; --draft uses placeholders/silent audio for inspection only.
--source-video accepts ONLY a local file path; never a Drive upload or URL. For full-length recordings, split by chapter first to maintain sensible chapter timing.
Google Drive only input, outputs local. No auto upload.

Optional OFFLINE transcription: see transcribe_offline.py and project README; separate multilingual whisper.cpp model required. No automatic model download.


v0.7 IMPORTANT: before a full CPU render, run:
  py render.py --preset youtube --chapter 1 --check-only --source-video "C:\Videos\Chapter01.mp4"
This verifies narration audio track, ~1s timeline-duration tolerance and every required scene image.
No video is produced by --check-only. Narration clips are never uploaded to Drive.
