@echo off
cd /d "%~dp0"
where ffmpeg >nul 2>nul
if errorlevel 1 (echo FFmpeg is missing from PATH. Install free FFmpeg first. & pause & exit /b 1)
py -3 render.py --preset youtube --chapter 1 --draft
if errorlevel 1 (echo Render failed. & pause & exit /b 1)
echo MP4 exported. Open this folder.
pause
