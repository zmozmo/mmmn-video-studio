// Native desktop save bridge. No API, account or network calls.
export function isProject(value){return !!value && typeof value==='object' && Array.isArray(value.chapters) && Array.isArray(value.assets);}
export function parseProject(text,label){
  if(text==null || text==='')return null;
  let result;try{result=typeof text==='string'?JSON.parse(text):text;}catch(e){throw Error(`Cannot parse ${label}: ${e.message}`);}
  if(!isProject(result))throw Error(`${label} is not a valid MMMN project; it was not overwritten.`);
  return result;
}
export function pickProject(nativeText,browserText,starterProject){
  // Always prefer persistent native state, then migrate browser state once.
  const native=parseProject(nativeText,'native saved project');if(native)return {project:native,source:'native'};
  const browser=parseProject(browserText,'legacy local browser project');if(browser)return {project:browser,source:'legacy'};
  const starter=parseProject(starterProject,'starter project');return {project:starter,source:'starter'};
}
export function createNativeBridge(tauri){
  const invoke=tauri?.core?.invoke;
  return invoke?{
    available:true,
    load:()=>invoke('load_project_state'),
    save:(json)=>invoke('save_project_state',{json}),
    info:()=>invoke('project_storage_info')
  }:{available:false,load:async()=>null,save:async()=>{},info:async()=>null};
}
export function makeSaveQueue(bridge,onError=()=>{}){
  // An intensive editing session may update the timeline repeatedly while a
  // slow disk write is still pending. Preserve the currently-writing snapshot,
  // but collapse all subsequent edits to the MOST RECENT state: no stale queue.
  let writing=null;
  let latest=null;
  let lastError=null;
  let revision=0;
  const drain=async()=>{
    while(latest!==null){
      const next=latest;
      latest=null;
      try{
        await bridge.save(next);
        lastError=null;
      }catch(error){
        lastError=error;
        onError(error);
      }
    }
  };
  const ensureDrain=()=>{
    if(!writing){
      writing=Promise.resolve().then(drain).finally(()=>{
        writing=null;
        // Edits scheduled between the last loop turn and settlement must still
        // be persisted, never silently lost.
        if(latest!==null)ensureDrain();
      });
    }
    return writing;
  };
  return {
    save(json){
      if(!bridge.available)return Promise.resolve();
      if(typeof json!=='string')throw Error('Project save must be serialized JSON');
      latest=json;
      revision++;
      return ensureDrain();
    },
    async flush(){
      while(writing || latest!==null){
        if(!writing)ensureDrain();
        await writing;
      }
      if(lastError)throw lastError;
    },
    get pending(){return Number(Boolean(writing))+Number(latest!==null);},
    get lastError(){return lastError;},
    get revision(){return revision;}
  };
}

