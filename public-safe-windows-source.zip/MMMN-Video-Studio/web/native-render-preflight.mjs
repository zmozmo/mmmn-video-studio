// Pure offline-first render validation. Tauri's Rust backend rechecks untrusted input.
const IMAGE_FORMATS = new Set(['jpg', 'jpeg', 'png', 'webp']);
const VIDEO_FORMATS = new Set(['mp4', 'mov', 'm4v', 'webm']);
const AUDIO_FORMATS = new Set(['mp3', 'm4a', 'wav', 'ogg', 'aac']);
const PRESETS = new Set(['youtube', 'tiktok', 'facebook', 'square']);
const nameExt = name => String(name||'').split('.').pop().toLowerCase();
export async function planNativeRender(chapter, assets, getInfo, preset='youtube') {
  if (!chapter || !Array.isArray(chapter.scenes) || !chapter.scenes.length || chapter.scenes.length>1000)
    throw Error('Chapter needs between 1 and 1000 timeline scenes.');
  if (!Number.isFinite(chapter.recordedSeconds) || chapter.recordedSeconds < .5 || chapter.recordedSeconds > 43200)
    throw Error('Narrator recording duration must be available (0.5 sec–12 hours).');
  if (!PRESETS.has(preset)) throw Error('Unsupported render size.');
  if (!Number.isInteger(chapter.number) || chapter.number < 1 || chapter.number > 1000) throw Error('Chapter number invalid.');
  const byId = new Map((assets||[]).map(x=>[x.id,x]));
  // The last imported narration track is authoritative: the app clears the
  // opposite ID on import. Older saved projects may still have both IDs,
  // in which case video wins for backwards compatibility.
  const video = byId.get(chapter.videoAssetId);
  const audio = byId.get(chapter.audioAssetId);
  const source = video && VIDEO_FORMATS.has(nameExt(video.name)) ? video :
    audio && AUDIO_FORMATS.has(nameExt(audio.name)) ? audio : null;
  if (!source) throw Error('Import a supported narrator video or audio recording (MP3, WAV, M4A, OGG or AAC).');
  if (!await getInfo(source)) throw Error(`Narrator recording is missing on this device: ${source.name}`);
  let total = 0;
  const scenes = [];
  for (let i=0;i<chapter.scenes.length;i++) {
    const scene = chapter.scenes[i], asset = byId.get(scene.assetId);
    if (!asset || !IMAGE_FORMATS.has(nameExt(asset.name))) throw Error(`Scene ${i+1} needs a supported local picture.`);
    if (!await getInfo(asset)) throw Error(`Scene ${i+1} picture is missing on this device: ${asset.name}`);
    const duration = Number(scene.duration);
    if (!Number.isFinite(duration) || duration < .25 || duration > 3600) throw Error(`Scene ${i+1} duration is invalid.`);
    total += duration;
    if (total > 43200) throw Error('Total chapter runtime exceeds 12 hours.');
    scenes.push({assetId:asset.id,ext:nameExt(asset.name),duration,motion:['pan','zoom','still'].includes(scene.motion)?scene.motion:'still'});
  }
  if (Math.abs(total-chapter.recordedSeconds)>.5)
    throw Error(`Scene timeline ${total.toFixed(2)}s does not match narration ${chapter.recordedSeconds.toFixed(2)}s; adjust scene boundaries first.`);
  return {
    chapterNumber:chapter.number,sourceVideoId:source.id,sourceVideoExt:nameExt(source.name),
    scenes,preset,recordedSeconds:chapter.recordedSeconds
  };
}
