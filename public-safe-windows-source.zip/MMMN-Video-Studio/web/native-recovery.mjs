// Native-only, local full-media backups. Never calls fetch() or cloud endpoints.
export function makeNativeRecovery(tauri){
  const invoke=tauri?.core?.invoke;
  if(typeof invoke!=='function')return {available:false};
  return {
    available:true,
    create:()=>invoke('create_full_local_backup'),
    list:()=>invoke('list_local_backups'),
    verify:(id)=>{
      if(!/^snapshot-[0-9]+-[0-9]+$/.test(String(id)))throw Error('Invalid backup identifier');
      return invoke('verify_local_backup',{id});
    },
    restore:(id)=>{
      if(!/^snapshot-[0-9]+-[0-9]+$/.test(String(id)))throw Error('Invalid backup identifier');
      return invoke('restore_local_backup',{id});
    }
  };
}
