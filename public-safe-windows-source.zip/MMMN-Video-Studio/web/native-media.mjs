// No Internet, no cloud writes. Files are streamed to app-local native storage.
export const NATIVE_CHUNK_BYTES = 512 * 1024;
const extMap = {'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/quicktime':'mov','video/webm':'webm','audio/mpeg':'mp3','audio/mp4':'m4a','audio/wav':'wav','audio/x-wav':'wav','audio/ogg':'ogg','audio/aac':'aac'};
// A fixed-size SHA256 per chunk gives Rust evidence that it received the bytes
// actually read from the original File slice. WebCrypto only holds one chunk.
export async function chunkSha256(bytes){
  if(!globalThis.crypto?.subtle)throw Error('Secure local hashing unavailable; media was NOT imported');
  const digest=await globalThis.crypto.subtle.digest('SHA-256',bytes);
  return Array.from(new Uint8Array(digest),n=>n.toString(16).padStart(2,'0')).join('');
}
const allowed = new Set(['png','jpg','jpeg','webp','gif','mp4','m4v','mov','webm','mp3','m4a','wav','ogg','aac']);
export function extensionFor(name='',mime=''){
  const candidate = String(name).split('.').pop().toLowerCase();
  const ext = allowed.has(candidate) ? candidate : extMap[mime];
  if(!ext || !allowed.has(ext))throw Error(`Unsupported media extension: ${name||mime}`);
  return ext;
}
export function makeNativeMedia(tauri){
  const invoke=tauri?.core?.invoke;
  const convert=tauri?.core?.convertFileSrc;
  if(typeof invoke!=='function' || typeof convert!=='function')return {available:false};
  const info=(id,name,mime)=>invoke('get_media_info',{id,ext:extensionFor(name,mime)});
  return {
    available:true, info,
    verify:(id,name,mime,expected_sha256)=>invoke('verify_native_media',{
      id, ext:extensionFor(name,mime), expectedSha256:expected_sha256
    }),
    async store(id,file,name=file.name||'',onProgress=()=>{}){
      const ext=extensionFor(name,file.type);
      if(!Number.isSafeInteger(file.size)||file.size<=0)throw Error('Invalid media size');
      await invoke('begin_media_import',{id,ext,total:file.size});
      try{
        let offset=0;
        while(offset<file.size){
          const chunk=new Uint8Array(await file.slice(offset,offset+NATIVE_CHUNK_BYTES).arrayBuffer());
          const checksum=await chunkSha256(chunk);
          const next=await invoke('import_media_chunk',chunk,{headers:{'x-media-id':id,'x-media-offset':String(offset),'x-media-sha256':checksum}});
          if(next!==offset+chunk.byteLength)throw Error('Native importer returned an unexpected byte offset');
          offset=next;onProgress(offset,file.size);
        }
        const result=await invoke('finalize_media_import',{id});
        if(result?.size!==file.size || result?.id!==id || result?.ext!==ext ||
          typeof result?.sha256!=='string' || !/^[a-f0-9]{64}$/.test(result.sha256))
          throw Error('Native import integrity acknowledgement failed; do not trust this media.');
        return result;
      }catch(err){await invoke('abort_media_import',{id}).catch(()=>{});throw err;}
    },
    url(path){return convert(path);}
  };
}
