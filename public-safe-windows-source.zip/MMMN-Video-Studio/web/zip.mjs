const encoder=new TextEncoder(), decoder=new TextDecoder();
function table(){let t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;}
const CRC=table();
export function crc32(bytes){let crc=0xffffffff;for(let i=0;i<bytes.length;i++)crc=CRC[(crc^bytes[i])&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
export async function makeZip(entries) {
 let local=[],central=[],offset=0;
 for(const entry of entries){
  const name=String(entry.name||'').replaceAll('\\','/');if(!name||name.startsWith('/')||name.split('/').some(x=>x==='..'))throw Error('Invalid archive path');
  const data=entry.data instanceof Blob?new Uint8Array(await entry.data.arrayBuffer()):entry.data instanceof Uint8Array?entry.data:encoder.encode(String(entry.data));
  if(data.length>0xffffffff)throw Error('One file exceeds ZIP32 limit');
  const filename=encoder.encode(name),crc=crc32(data),localHeader=new Uint8Array(30+filename.length),lh=new DataView(localHeader.buffer);
  lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x800,true);lh.setUint16(8,0,true);lh.setUint32(14,crc,true);lh.setUint32(18,data.length,true);lh.setUint32(22,data.length,true);lh.setUint16(26,filename.length,true);localHeader.set(filename,30);
  const c=new Uint8Array(46+filename.length),cv=new DataView(c.buffer);
  cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,filename.length,true);cv.setUint32(42,offset,true);c.set(filename,46);
  local.push(localHeader,data);central.push(c);offset+=localHeader.length+data.length;
 }
 if(entries.length>65535||offset>0xffffffff)throw Error('Archive exceeds ZIP32 limit');
 const centralSize=central.reduce((n,x)=>n+x.length,0),end=new Uint8Array(22),v=new DataView(end.buffer);
 v.setUint32(0,0x06054b50,true);v.setUint16(8,entries.length,true);v.setUint16(10,entries.length,true);v.setUint32(12,centralSize,true);v.setUint32(16,offset,true);
 return new Blob([...local,...central,end],{type:'application/zip'});
}
export async function readZip(blob){
 const bytes=new Uint8Array(await blob.arrayBuffer()),v=new DataView(bytes.buffer),files=new Map();let eocd=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--){if(v.getUint32(i,true)===0x06054b50){eocd=i;break;}}
 if(eocd<0)throw Error('ZIP central directory missing');
 const count=v.getUint16(eocd+10,true),start=v.getUint32(eocd+16,true);let at=start;
 for(let i=0;i<count;i++){
  if(v.getUint32(at,true)!==0x02014b50)throw Error('Invalid ZIP directory');
  const flags=v.getUint16(at+8,true),method=v.getUint16(at+10,true),crc=v.getUint32(at+16,true),n=v.getUint32(at+20,true),nameLen=v.getUint16(at+28,true),extra=v.getUint16(at+30,true),comment=v.getUint16(at+32,true),offset=v.getUint32(at+42,true);
  if(method!==0)throw Error('Only uncompressed MMMN ZIP backups are supported');
  const name=decoder.decode(bytes.subarray(at+46,at+46+nameLen));
  if(name.startsWith('/')||name.split('/').some(x=>x==='..'))throw Error('Unsafe archive path');
  if(v.getUint32(offset,true)!==0x04034b50)throw Error('Broken ZIP file');
  const ptr=offset+30+v.getUint16(offset+26,true)+v.getUint16(offset+28,true);
  if(ptr+n>bytes.length)throw Error('Broken ZIP length');
  const data=bytes.slice(ptr,ptr+n);if(crc32(data)!==crc)throw Error('Corrupted ZIP content');files.set(name,data);
  at+=46+nameLen+extra+comment;
 }
 return files;
}
