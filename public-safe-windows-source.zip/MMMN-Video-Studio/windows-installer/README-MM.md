# Windows Setup Upgrade Lab (Installer အစစ် ဖြန့်ချိမှု မဟုတ်သေး)

ဒီ Folder မှာ Python Portable Trial ကို Windows .exe တစ်ခုအဖြစ် PyInstaller နဲ့ Build လုပ်ပြီး NSIS Setup (current user) ထုတ်ရန် Source နဲ့ **အမှန်တကယ် Upgrade စမ်းမယ့်** GitHub Actions Workflow ပါဝင်ပါတယ်။

- Stable Install Directory: `%LOCALAPPDATA%\Programs\MMMN Video Studio`
- Stable Project/Media Directory: `%LOCALAPPDATA%\MMMN-Video-Studio-Trial`
- နောက် Setup ကို Installer Directory တစ်နေရာတည်းမှာ အပေါ်ကနေ Update တင်မယ်။ Uninstall မလုပ်ပါ။
- App/Render အလုပ်လုပ်နေချိန် Update မတင်ပါနဲ့။ အလုပ်ပြီး App ပိတ်ပြီးမှ Update တင်ပါ။
- Windows CI မှာ Installer **A → Project & Media Create → Installer B အပေါ်ကနေတင် → Project, Media SHA, Preupgrade Recovery, FFmpeg စစ်** ပြီးမှ Debug Installer Artifact ခွင့်ပြုမယ်။
- App Data ကို Uninstall လုပ်ရင်တောင် အလိုအလျောက်မဖျက်ပါ။ User ကိုယ်တိုင်ရွေးပြီး Backup ယူပြီးမှ ဖျက်နိုင်ပါတယ်။

**တည်ဆောက်ပြီး သက်သေမပြနိုင်သေးတဲ့အချက်များ**: Windows GitHub Actions ကို ဒီ Chat မှာ မတင်/မ Run ရသေး၊ Setup အစစ် Compile/Install/Upgrade မစမ်းရသေး၊ FFmpeg Binary redistribution license notice မပြီးသေး၊ long GB-size videos မစမ်းရသေး၊ Offline Burmese AI Model မပါသေး။

Source တွင် `windows-installer/MMMN-Video-Studio.nsi` နှင့် `.github/workflows/windows-installer-upgrade-lab.yml` ကိုကြည့်ပါ။
