; MMMN Offline Windows Studio, per-user installer. In-place upgrades intentionally
; overwrite program files, NEVER the separate LOCALAPPDATA project/media folder.
; Compile only on a trusted Windows runner AFTER actual EXE and upgrade checks.
Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "FileFunc.nsh"

!ifndef APP_VERSION
  !error "APP_VERSION is mandatory"
!endif
!ifndef APP_PAYLOAD
  !error "APP_PAYLOAD is mandatory (full Windows PyInstaller folder)"
!endif

!define APP_NAME "MMMN Video Studio"
!define APP_EXE "MMMN-Video-Studio.exe"
!define UNINSTALL_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\MMMNVideoStudio"

Name "${APP_NAME} ${APP_VERSION}"
OutFile "MMMN-Video-Studio-Setup-${APP_VERSION}.exe"
InstallDir "$LOCALAPPDATA\Programs\MMMN Video Studio"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetOverwrite on
ShowInstDetails show
ShowUninstDetails show

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  SetShellVarContext current
  ; Fixed, per-user path. This is never a user data folder.
  StrCpy $INSTDIR "$LOCALAPPDATA\Programs\MMMN Video Studio"
  ; File overwrite while renderer runs is unsafe. Installer must be retried
  ; after the application is closed; never force kill a running render.
  IfFileExists "$INSTDIR\${APP_EXE}" 0 done
    ClearErrors
    FileOpen $1 "$INSTDIR\${APP_EXE}" a
    ${If} ${Errors}
      MessageBox MB_OK|MB_ICONEXCLAMATION "Close MMMN Video Studio (and its video export) before installing an update. Existing project data is safe."
      Abort
    ${EndIf}
    FileClose $1
  done:
FunctionEnd

Section "Application (updates existing installation)" SEC_APP
  SetOutPath "$INSTDIR"
  ; Only program files are overwritten; all user data is elsewhere.
  File /r "${APP_PAYLOAD}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateDirectory "$SMPROGRAMS"
  CreateShortcut "$SMPROGRAMS\MMMN Video Studio.lnk" "$INSTDIR\${APP_EXE}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayName" "${APP_NAME}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "Publisher" "MMMN (personal offline project)"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "DisplayIcon" "$INSTDIR\${APP_EXE}"
  WriteRegStr HKCU "${UNINSTALL_KEY}" "UninstallString" '$"$INSTDIR\Uninstall.exe$"'
  WriteRegStr HKCU "${UNINSTALL_KEY}" "QuietUninstallString" '$"$INSTDIR\Uninstall.exe$" /S'
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINSTALL_KEY}" "NoRepair" 1
SectionEnd

Function un.onInit
  SetShellVarContext current
  ; Do not remove a running app's files. Preserve every project/recording.
  IfFileExists "$INSTDIR\${APP_EXE}" 0 finished
    ClearErrors
    FileOpen $1 "$INSTDIR\${APP_EXE}" a
    ${If} ${Errors}
      MessageBox MB_OK|MB_ICONEXCLAMATION "Close MMMN Video Studio before uninstalling. Project and media files are not deleted by this uninstaller."
      Abort
    ${EndIf}
    FileClose $1
  finished:
FunctionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\MMMN Video Studio.lnk"
  ; Uninstall ONLY files installed by this package. Even if a user put a
  ; personal file in the program folder, do not recursively destroy it.
  ; PyInstaller --onedir stores its runtime resources under _internal.
  ; Never touch $LOCALAPPDATA\MMMN-Video-Studio-Trial, backups or exports.
  Delete "$INSTDIR\${APP_EXE}"
  RMDir /r "$INSTDIR\_internal"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR" ; remains if unrelated files exist; safer than deleting them
  DeleteRegKey HKCU "${UNINSTALL_KEY}"
SectionEnd
