@echo off
set "ROOT=%LOCALAPPDATA%\MMMN-Video-Studio-Trial"
if not exist "%ROOT%" mkdir "%ROOT%"
start "" explorer.exe "%ROOT%"
