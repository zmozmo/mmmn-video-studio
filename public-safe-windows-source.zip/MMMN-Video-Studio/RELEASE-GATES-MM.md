# VERSION 0.12.0 — STATUS

For the current release audit and blocker list, see **V0.12-WINDOWS-RELEASE-STATUS-MM.md**. This source is NOT an installer.

# MMMN Video Studio — Windows Setup.exe မထုတ်ခင် Release Gate v0.10.0

**ဤ Package သည် SOURCE/PREINSTALL သာဖြစ်သည်။ Setup.exe မပါ။**

## မပြောင်းရမည့် စည်းမျဉ်းများ
- App name: `MMMN Video Studio`; identifier `com.mmmn.videostudio`; currentUser NSIS installer; Windows user account တူရမည်။
- Version အသစ်ကို Setup အသစ်ထပ်တင်ခြင်းဖြင့် In-place Upgrade ရမည်။ Previous install ကို ကိုယ်တိုင် Uninstall မလုပ်ရ။
- Personal manuscript, video, image, project, timelines, exports, backups မည်သည့်အရာကိုမျှ Google Drive သို့ Auto Upload မလုပ်ရ။
- User data ကို installer files ထဲ မသိမ်းရ; App update နဲ့ cache cleanup တို့ကြောင့် မပျက်ရ။
- Native App သည် Internet မလိုဘဲ run/edit/preview/render လုပ်နိုင်ရမည်။ Direct Drive input သည် OPTIONAL online action သာ ဖြစ်ရမည်။
- အသံထဲက မြန်မာစာတန်းကို မသေချာလျှင် အသံနှင့်အချိန်ကို အတည်မပြုဘဲ Review ပြရမည်။

## Release Gate များ — အစဉ်လိုက်

1. **Data architecture — PARTIAL / BLOCKER**
   - Chapter/narration/large MP4 (200MB, 1GB, 3GB စမ်းမည်) + imported images ကို Native local folder ထဲ အမြဲတမ်းသိမ်းနိုင်ရမည်။
   - Browser IndexedDB အပေါ် အဓိကမှီခိုမှု ဖယ်ရှားရန်; Windows user Local AppData / project-specific Media directory အသုံးပြုရန်။
   - Full-media Backup / Restore / Drive input-only rule ကို စမ်းရန်။
   - Duplicated imports, wrong folder, file moved, disk full, interruption တွေမှာ data မဖျက်မိရန်။

2. **Native render/export — PARTIAL / BLOCKER**
   - App UI ကနေ 16:9, 9:16, 4:5, 1:1 MP4 နှင့် draft preview ထုတ်နိုင်ရမည်။
   - FFmpeg ကို Windows installer ထဲ offline bundle/sidecar ပုံစံမှန်စွာ ထည့်၍ licensing notices ပါစေရမည်။
   - Python လိုအပ်လျှင် တစ်ချက်နှိပ် Export အတွက် ကိုယ်ပိုင် runtime ဖြင့် package လုပ်ရန် သို့မဟုတ် native Rust UI-to-FFmpeg bridge ပြောင်းရန်။
   - Video ၁ ခန်းနှင့် အခန်းများစွာ; audio duration/timing mismatch; missing assets; cut vs dissolve; user cancel စမ်းရန်။

3. **Windows native compile and security — BLOCKER**
   - Windows 11 x64 ပေါ်မှာ `cargo check`, `tauri build`, WebView2/NSIS installer တကယ်အောင်မြင်ရမည်။
   - JS/Rust dependencies `package-lock.json` နှင့် `Cargo.lock` မှာ lock ထားရမည် (source artifact reproducible)။
   - No remote script/CDN, no silent uploads, minimum filesystem permission, optional model downloads explicit consent.
   - Unsigned installer တွေမှာ Windows SmartScreen warning ဖြစ်နိုင်ကြောင်း အသိပေးမည်; hash / source version reproducibility စစ်မည်။

4. **In-place upgrade & recovery — BLOCKER**
   - Clean install, create project, import photo/large video, manually adjust shot, close app.
   - Update Setup.exe vNext အဟောင်းအပေါ် ထပ် install, manual uninstall လုံးဝမလုပ်။
   - App reopen + chapter count + media playback + timing lock + exported MP4 + backup restore ကောင်း/မကောင်း စစ်။
   - Power loss / disk full / damaged JSON / pre-upgrade recovery snapshot / rollback စမ်း။

5. **Offline user journey — BLOCKER**
   - Internet ပိတ်ထားပြီး App စတင် → local video import → scene timing suggestions → image folder import → preview → MP4 export → app reopen.
   - Burmese SRT import/export Unicode correct; Burmese speech recognition may stay separately marked optional until proven with actual recording.
   - 8 known portraits are reference-only, **scene backgrounds** အပြည့်မရှိသေး။ Placeholder/ draft ကို final လို့ မမှတ်ရ။
   - Touch/keyboard + Windows 11 WebView2 on user HP ZBook (16GB RAM) စမ်း။

6. **Distribution & rollback — BLOCKER**
   - Setup.exe SHA256 checksum + version + test report + fixed ID.
   - Installer release download Windows 11 user account တူတူမှာ in-place Upgrade ပြန်တင်နိုင်ရမည်။
   - Setup မတင်ခင် full local backup ထုတ်၊ integrity စစ်၊ Restore rehearsal တစ်ကြိမ် လုပ်ပြီးမှ Installer test လုပ်။

## v0.10.0 မှာ Source အဆင့် ပြီးစီး/စမ်းပြီးသား
- NSIS currentUser + stable identifier static guard; Tauri WebView2 `offlineInstaller` config; Windows CI preflight skeleton.
- Project metadata native JSON + previous/preupgrade snapshots (native logic Windows runtime မှာ စမ်းဖို့ ကျန်)။
- ZIP မပြည့်ဘဲ `Complete Backup` လို့ မပြတော့ပါ။ File မရှိရင် error တား၊ ZIP CRC + archive index စစ်၊ Restore မတိုင်ခင် manifest မီဒီယာအားလုံးပါ/မပါ စစ်။
- Save queue failed ဆိုရင် explicit failure surfacing; backup ထုတ်မတိုင်ခင် pending saves flush.
- Existing SRT alignment, pause suggestion, scene manual edit, Python renderer unit tests (native GUI မဟုတ်သေး)။

## **ဆုံးဖြတ်ချက်**
Setup.exe ကို v0.10.0 မှာ **မထုတ်ရ**။ အထက် Gate 1, 2, 3, 4, 5, 6 အတွက် Windows actual evidence လိုအပ်သည်။ Source-only Tests အောင်မြင်ခြင်းကို Windows Installer Ready နှင့် မရောရ။

## ခင်ဗျား လက်ရှိလုပ်စရာ
ဘာမှ မလုပ်ရသေး။ Source လုပ်ငန်းတိုးတက်မှုနဲ့ release gate evidence မပြည့်စုံခင် ZIP အဟောင်းကို install/uninstall မစမ်းရပါ။ Windows Setup တကယ်ရသောအခါ တစ်ကြိမ် install + နောက် Version Setup ထပ်တင်နည်းကို သီးသန့် ညွှန်ကြားမည်။

## v0.10.0 Pre-install Status (Source-only)

- Chunked native image/video/audio import + asset protocol code: **structurally implemented**, Windows runtime **unverified**.
- Native chapter Draft Render FFmpeg bridge: **structurally implemented**; FFmpeg stand-alone technical proof passed. Native button execution and shipping bundled FFmpeg **unverified**.
- Original Narrator Video audio stream is selected for export; user voice remains original. Native Render currently cuts scenes, no cinematic crossfade.
- Native full-media ZIP Backup for 512 MiB+ files **missing**. This remains a critical release blocker.
- JS/Python source Tests pass, Chrome GUI navigation blocked; Rust/Cargo/NSIS Windows Build untested.
- Google Drive is input-only; no upload or cloud export added.

**Decision: No Windows Setup.exe yet. Release readiness is NOT established.**
