@echo off
setlocal
cd /d "%~dp0"
echo ======================================================
echo MMMN Video Studio - Windows Installer Build and Test
echo No existing user projects will be deleted.
echo ======================================================
echo.
echo [1/2] Checking required programs...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\check-windows-build-prerequisites.ps1"
if errorlevel 1 goto :missing
echo.
echo [2/2] Building and testing a real Windows EXE and installer...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\build-windows-setup-lab.ps1"
if errorlevel 1 goto :failed
echo.
echo BUILD FINISHED. Unsigned lab installer only.
echo See WINDOWS-SETUP-LAB-OUTPUT\BUILD-REPORT.txt
echo Full command log: WINDOWS-SETUP-LAB-OUTPUT\BUILD-CONSOLE-LOG.txt
echo Real installed upgrade test MUST pass before production use.
pause
exit /b 0
:missing
echo.
echo MISSING PREREQUISITES. Open WINDOWS-PREREQUISITE-REPORT.txt
pause
exit /b 1
:failed
echo.
echo BUILD/TEST FAILED. Open WINDOWS-SETUP-LAB-OUTPUT\BUILD-REPORT.txt
echo Also send WINDOWS-SETUP-LAB-OUTPUT\BUILD-CONSOLE-LOG.txt
pause
exit /b 1
