@echo off
setlocal
cd /d "%~dp0"
echo MMMN Video Studio -- verify installed program files, no project data changes
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 tools\windows_trial_updater.py --verify-installed
) else (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 required.
    pause
    exit /b 1
  )
  python tools\windows_trial_updater.py --verify-installed
)
if errorlevel 1 (
  echo Installed program verification FAILED. Project data was not changed.
  pause
  exit /b 1
)
pause
endlocal
