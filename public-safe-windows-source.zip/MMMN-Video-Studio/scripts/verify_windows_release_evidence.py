"""Fail-closed verifier for a Windows installer lab artifact.

Only run AFTER the Windows runner actually installed A, upgraded to B,
rendered MP4, and uninstalled B. A prepared workflow is not evidence.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

REQUIRED = {
    'VERIFIED-IN-PLACE-UPGRADE.txt': 'INSTALLER UPGRADE LAB PASS:',
    'VERIFIED-UNINSTALL-DATA-PRESERVED.txt': 'UNINSTALL DATA PRESERVATION PASS:',
    'FFMPEG-VERIFIED.txt': 'Media contract PASS H264/AAC;',
}

def verify(root: Path) -> dict:
    root = root.resolve()
    installer = root / 'Setup-B.exe'
    if not installer.is_file() or installer.stat().st_size < 1024:
        raise ValueError('Windows setup.exe is absent or implausibly small')
    sha = hashlib.sha256(installer.read_bytes()).hexdigest()
    checksum = (root / 'Setup-B.exe.sha256').read_text(encoding='ascii').strip()
    if not re.fullmatch(r'[0-9a-fA-F]{64}\s+Setup-B\.exe', checksum):
        raise ValueError('Installer checksum line has incorrect format')
    if checksum.split()[0].lower() != sha:
        raise ValueError('Installer SHA-256 does not match actual bytes')
    for filename, marker in REQUIRED.items():
        text = (root / filename).read_text(encoding='utf-8-sig')
        if marker not in text:
            raise ValueError(f'Windows lab success marker missing: {filename}')
    for filename in ('installed-base-self-test.json','installed-upgrade-self-test.json',
                     'installed-upgrade-e2e.json'):
        parsed = json.loads((root/filename).read_text(encoding='utf-8-sig'))
        if parsed.get('status') != 'PASS':
            raise ValueError(f'Windows native evidence is not PASS: {filename}')
    tests = json.loads((root/'python-tests.json').read_text(encoding='utf-8'))
    if not tests.get('passed') or not tests.get('completed') or not tests.get('full_coverage'):
        raise ValueError('Bounded Python full suite is not fully verified')
    return {'status':'PASS', 'platform':'Windows native runner',
            'artifact':'UNSIGNED LAB INSTALLER - NOT A SIGNED PRODUCTION RELEASE',
            'sha256':sha, 'size_bytes':installer.stat().st_size,
            'windows_install_upgrade_render_uninstall':'VERIFIED',
            'python_test_count': tests.get('test_count')}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--folder',required=True,type=Path)
    p.add_argument('--report',type=Path)
    args=p.parse_args()
    try:
        data=verify(args.folder)
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as error:
        print('WINDOWS RELEASE EVIDENCE FAIL:',error,file=sys.stderr)
        return 1
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(data,indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
