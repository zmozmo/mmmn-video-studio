#!/usr/bin/env python3
"""Runs the exact native FFmpeg draft-render argument pattern against synthetic data.
This is NOT an end-to-end Tauri/Windows test. Requires ffmpeg, ffprobe, Pillow optional.
"""
import json
import shutil
import struct
import subprocess
import tempfile
import zlib
from pathlib import Path


def png(path, rgb, width=320, height=180):
    def chunk(kind, data):
        return struct.pack('!I',len(data))+kind+data+struct.pack('!I', zlib.crc32(kind+data)&0xffffffff)
    pixel=bytes(rgb)
    rows=b''.join(b'\0'+pixel*width for _ in range(height))
    path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!IIBBBBB',width,height,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(rows))+chunk(b'IEND',b''))


def run():
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        raise RuntimeError('ffmpeg and ffprobe not installed for this developer smoke test')
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);(root/'media').mkdir();(root/'exports').mkdir()
        png(root/'media'/'asset-123456.png',(170,55,40)); png(root/'media'/'asset-654321.png',(50,110,170))
        (root/'exports'/'draft.ffconcat').write_text(
            "ffconcat version 1.0\nfile '../media/asset-123456.png'\nduration 2.000000\nfile '../media/asset-654321.png'\nduration 2.000000\nfile '../media/asset-654321.png'\n")
        subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-f','lavfi','-i','sine=frequency=400:sample_rate=48000:duration=4','-c:a','aac',str(root/'media'/'narrator.mp4')],check=True)
        subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(root/'exports'/'draft.ffconcat'),'-i',str(root/'media'/'narrator.mp4'),'-map','0:v:0','-map','1:a:0','-vf','scale=640:360:force_original_aspect_ratio=increase,crop=640:360,fps=30,format=yuv420p','-t','4.000','-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-b:a','160k','-movflags','+faststart',str(root/'exports'/'draft.mp4')],check=True)
        info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,codec_type','-show_entries','format=duration,size','-of','json',str(root/'exports'/'draft.mp4')]))
        codecs={s['codec_name'] for s in info['streams']}
        assert {'h264','aac'}<=codecs,info
        assert 3.9<float(info['format']['duration'])<4.1,info
        assert int(info['format']['size'])>1000,info
        print('NATIVE FFmpeg COMMAND SHAPE SMOKE PASS — 4-second H.264/AAC, synthetic source; Tauri UI not tested')


if __name__=='__main__':run()
