"""Run isolated Python test modules with bounded execution time.

Default is full coverage. --quick skips costly long-video integration only; the
result explicitly lists omitted modules and cannot count as full release proof.
"""
import argparse
import json
from pathlib import Path
import re
import subprocess
import os
import signal
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
SLOW = {'long_chapter_render_test.py'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--quick', action='store_true', help='Skip slow long-video integration tests (not a release gate)')
    parser.add_argument('--timeout', type=int, default=180, help='Per-test-module timeout in seconds')
    parser.add_argument('--report', default='', help='Optional JSON report path')
    args = parser.parse_args()
    if args.timeout < 1:
        parser.error('--timeout must be positive')
    files = sorted((ROOT / 'tests').glob('*_test.py'))
    results = []
    skipped = []
    def save_report():
        all_pass = bool(results) and all(row['status'] == 'PASS' for row in results)
        pending = [p.name for p in files if p.name not in skipped and p.name not in {r['module'] for r in results}]
        completed = not pending
        report = {'mode': 'quick' if args.quick else 'full',
                  'completed': completed,
                  'full_coverage': completed and not skipped,
                  'passed': completed and all_pass, 'test_count': sum(row['tests'] for row in results),
                  'skipped_modules': skipped, 'pending_modules': pending,
                  'results': results}
        if args.report:
            destination = Path(args.report)
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(destination.suffix + '.tmp')
            temporary.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
            temporary.replace(destination)
        return report

    for test in files:
        if args.quick and test.name in SLOW:
            skipped.append(test.name)
            print(f'SKIP {test.name} (long-running integration; --quick only)', flush=True)
            save_report()
            continue
        print(f'RUN  {test.name}', flush=True)
        started = time.monotonic()
        try:
            command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-p', test.name]
            popen_options = {'cwd': ROOT, 'stdout': subprocess.PIPE,
                             'stderr': subprocess.PIPE, 'text': True}
            if os.name == 'nt':
                popen_options['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
            else:
                popen_options['start_new_session'] = True
            # Do not use Popen as a context manager: __exit__ can wait forever
            # when a renderer child inherits an output pipe after a timeout.
            process = subprocess.Popen(command, **popen_options)
            try:
                stdout, stderr = process.communicate(timeout=args.timeout)
            except subprocess.TimeoutExpired:
                # Terminate the entire process group, not only the Python parent.
                if os.name == 'nt':
                    try:
                        subprocess.run(['taskkill', '/F', '/T', '/PID', str(process.pid)],
                                       capture_output=True, timeout=10, check=False)
                    except (OSError, subprocess.TimeoutExpired):
                        pass
                else:
                    try: os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                try:
                    process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    try: process.kill()
                    except ProcessLookupError: pass
                    # Do not block indefinitely on inherited child pipes.
                    for stream in (process.stdout, process.stderr):
                        if stream: stream.close()
                    try: process.wait(timeout=3)
                    except subprocess.TimeoutExpired: pass
                raise
            finally:
                if process.poll() is None:
                    try: process.kill()
                    except ProcessLookupError: pass
            completed = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
            output = (completed.stdout or '') + (completed.stderr or '')
            match = re.search(r'Ran (\d+) tests? in ', output)
            count = int(match.group(1)) if match else 0
            passed = completed.returncode == 0 and bool(match)
            status = 'PASS' if passed else 'FAIL'
            results.append({'module': test.name, 'status': status, 'tests': count,
                            'seconds': round(time.monotonic()-started, 2), 'output': output[-2500:] if not passed else ''})
        except subprocess.TimeoutExpired as exc:
            status = 'TIMEOUT'
            results.append({'module': test.name, 'status': status, 'tests': 0,
                            'seconds': round(time.monotonic()-started, 2), 'output': str(exc)})
        print(f'{status} {test.name} ({results[-1]["seconds"]}s)', flush=True)
        save_report()
        if status != 'PASS':
            print(results[-1]['output'], flush=True)
    report = save_report()
    all_pass = report['passed']
    print(f'PYTHON {report["mode"].upper()}: {report["test_count"]} tests; '
          f'{sum(r["status"]=="PASS" for r in results)}/{len(results)} modules passed; '
          f'{len(skipped)} skipped; overall {"PASS" if all_pass else "FAIL"}', flush=True)
    return 0 if all_pass else 1


if __name__ == '__main__':
    raise SystemExit(main())
