"""Promote the Windows *installed-and-tested* Setup-B.exe without rebuilding it.

Never run on a developer's personal files. Windows CI first proves install,
upgrade, MP4 export, uninstall and project/media integrity; only then may this
script copy identical executable bytes to the public-facing release filename.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
try:
    from .verify_windows_release_evidence import verify
except ImportError:
    from verify_windows_release_evidence import verify


def pe_header(path: Path) -> dict:
    """Reject non-PE files accidentally passed as setup.exe.

    NSIS setup launchers may be x86 even when they contain a Windows x64 app.
    This sanity check is not a digital signature or a sandbox execution test.
    """
    with path.open('rb') as stream:
        data = stream.read(4096)
    if len(data) < 128 or data[:2] != b'MZ':
        raise ValueError('Installer does not start with an MZ executable header')
    offset = int.from_bytes(data[0x3c:0x40], 'little')
    if offset < 0x40 or offset + 24 > len(data) or data[offset:offset + 4] != b'PE\x00\x00':
        raise ValueError('Installer PE header is absent or malformed')
    machine = int.from_bytes(data[offset+4:offset+6], 'little')
    if machine not in (0x14c, 0x8664):
        raise ValueError(f'Unsupported Windows installer PE machine type {machine:#x}')
    return {'machine': hex(machine), 'pe_offset': offset}


def promote(folder: Path, version: str) -> dict:
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', version):
        raise ValueError('Final release version must be major.minor.patch, never a lab or debug version')
    folder = folder.resolve()
    verified = verify(folder)  # fail closed if any evidence is absent or inconsistent
    installer = folder / 'Setup-B.exe'
    if installer.stat().st_size < 1024 * 1024:
        raise ValueError('Installer too small to include the required packaged Windows runtime and media tools')
    pe = pe_header(installer)
    checksum = verified['sha256']
    candidate = folder / f'MMMN-Video-Studio-Setup-{version}.exe'
    staging = folder / (candidate.name + '.pending')
    if staging.exists():
        staging.unlink()
    try:
        shutil.copyfile(installer, staging)
        with staging.open('rb') as stream:
            result_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
        if result_hash != checksum:
            raise ValueError('Promoted candidate differs from tested Windows installer')
        staging.replace(candidate)
    finally:
        staging.unlink(missing_ok=True)
    (folder / (candidate.name + '.sha256')).write_text(f'{checksum}  {candidate.name}\n', encoding='ascii')
    result = {
        'status': 'PASS', 'platform': 'Windows native runner required',
        'version': version, 'artifact': candidate.name,
        'signed': False, 'sha256': checksum,
        'tested_installer': 'Setup-B.exe',
        'exact_tested_bytes_reused': True,
        'windows_ci_evidence': 'RELEASE-EVIDENCE-VERIFIED.json',
        'pe': pe,
    }
    (folder / 'WINDOWS-RELEASE-CANDIDATE.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True, type=Path)
    parser.add_argument('--version', required=True)
    args = parser.parse_args()
    try:
        data = promote(args.folder, args.version)
    except (ValueError, FileNotFoundError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print('WINDOWS RELEASE PROMOTION BLOCKED:', exc, file=sys.stderr)
        return 1
    print(json.dumps(data, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
