# Windows 11 x64 only. Builds an UNSIGNED LAB setup.exe and tests the real packaged EXE.
# This is NOT production certification. Never deletes or modifies a real user project.
param([string]$NsIsPath = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $root
$reportDir = Join-Path $root 'WINDOWS-SETUP-LAB-OUTPUT'
New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
$report = Join-Path $reportDir 'BUILD-REPORT.txt'
$transcript = Join-Path $reportDir 'BUILD-CONSOLE-LOG.txt'
# Preserve the native tool output (pip, PyInstaller, FFmpeg and NSIS) even if a
# child process fails. The short BUILD-REPORT alone is not enough to debug it.
$transcriptStarted = $false
try {
  Start-Transcript -Path $transcript -Force -ErrorAction Stop | Out-Null
  $transcriptStarted = $true
} catch {
  Write-Warning ('Cannot start PowerShell transcript: ' + $_.Exception.Message)
}
$lines = [System.Collections.Generic.List[string]]::new()
function Log([string]$message) { Write-Host $message; $script:lines.Add($message) }
function Run([string]$label,[string]$bin,[string[]]$arguments) {
  Log "RUN $label"
  & $bin @arguments
  if ($LASTEXITCODE -ne 0) { throw "$label failed (exit=$LASTEXITCODE)" }
}
try {
  if ($env:OS -ne 'Windows_NT' -or [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString() -ne 'X64') {
    throw 'Requires actual Windows x64. Cross-platform source-only checks cannot substitute.'
  }
  $node = (Get-Command node.exe -ErrorAction Stop).Source
  $python = (Get-Command python.exe -ErrorAction Stop).Source
  $version = (Get-Content 'version.txt' -Raw).Trim()
  if ($version -notmatch '^\d+\.\d+\.\d+$') { throw 'Invalid release version' }
  $nsisCandidates = @($NsIsPath, 'C:\Program Files (x86)\NSIS\makensis.exe', 'C:\Program Files\NSIS\makensis.exe')
  $nsis = $nsisCandidates | Where-Object { $_ -and (Test-Path $_ -PathType Leaf) } | Select-Object -First 1
  if (!$nsis) { $cmd = Get-Command makensis.exe -ErrorAction SilentlyContinue; if ($cmd) { $nsis = $cmd.Source } }
  if (!$nsis) { throw 'Install NSIS and pass -NsIsPath or add makensis.exe to PATH' }
  New-Item -ItemType Directory -Path (Join-Path $root 'portable\bin') -Force | Out-Null
  foreach ($tool in @('ffmpeg.exe','ffprobe.exe')) {
    $local = Join-Path $root "portable\bin\$tool"
    if (!(Test-Path $local)) {
      $found = Get-Command $tool -ErrorAction SilentlyContinue
      if (!$found) { throw "Missing $tool. Provide trusted Windows x64 FFmpeg and FFprobe in portable\bin" }
      Copy-Item $found.Source $local -Force
    }
  }
  $ff = Join-Path $root 'portable\bin\ffmpeg.exe'
  $fp = Join-Path $root 'portable\bin\ffprobe.exe'
  Run 'ffprobe executable' $fp @('-version')
  $encoders = & $ff -hide_banner -encoders 2>&1 | Out-String
  if ($LASTEXITCODE -ne 0 -or $encoders -notmatch 'libx264') { throw 'Packaged FFmpeg lacks libx264' }
  $env:PATH = (Join-Path $root 'portable\bin') + ';' + $env:PATH
  Run 'JavaScript tests' $node @('--test')
  Run 'Python tests bounded' $python @('scripts/run-python-tests.py','--timeout','180','--report',(Join-Path $reportDir 'python-tests.json'))
  $venvDir = Join-Path $root '.mmmn-build-tools'
  $venvPy = Join-Path $venvDir 'Scripts\python.exe'
  if (!(Test-Path $venvPy)) { Run 'isolated build virtualenv' $python @('-m','venv',$venvDir) }
  Run 'PyInstaller dependency' $venvPy @('-m','pip','install','--disable-pip-version-check','--no-input','pyinstaller==6.16.0')
  $dist = Join-Path $root '.mmmn-setup-lab-dist'
  Run 'Windows PyInstaller onedir' $venvPy @('-m','PyInstaller','--noconfirm','--clean','--onedir','--console',
    '--name','MMMN-Video-Studio','--distpath',$dist,'--workpath',(Join-Path $root '.mmmn-setup-lab-work'),
    '--specpath',(Join-Path $root '.mmmn-setup-lab-spec'),
    '--add-data','web;web','--add-data','renderer;renderer',
    '--add-data','TRIAL-REVISION.txt;.','--add-data','portable/bin;portable/bin','portable/launcher.py')
  $payload = Join-Path $dist 'MMMN-Video-Studio'
  $exe = Join-Path $payload 'MMMN-Video-Studio.exe'
  if (!(Test-Path $exe)) { throw 'EXE not generated' }
  Run 'packaged EXE self-test' $exe @('--self-test')
  Run 'real packaged EXE offline media/backup/render integration' $venvPy @('tests/windows_portable_exe_smoke.py','--exe',$exe)
  Run 'real packaged EXE Edge UI smoke' $venvPy @('tests/windows_edge_ui_smoke.py','--exe',$exe)
  Run 'NSIS setup.exe compile (lab only)' $nsis @('/V3',"/DAPP_VERSION=$version","/DAPP_PAYLOAD=$payload",'windows-installer/MMMN-Video-Studio.nsi')
  $setupName = "MMMN-Video-Studio-Setup-$version.exe"
  if (!(Test-Path $setupName)) { throw 'NSIS reported success but setup.exe is missing' }
  $destination = Join-Path $reportDir $setupName
  Move-Item $setupName $destination -Force
  $hash = (Get-FileHash $destination -Algorithm SHA256).Hash
  "$hash  $setupName" | Set-Content -Encoding ascii (Join-Path $reportDir "$setupName.sha256")
  Log "BUILD PASS: $destination"
  Log "SHA256: $hash"
  Log 'IMPORTANT: UNSIGNED LAB INSTALLER ONLY. In-place upgrade and install tests not performed by this builder.'
  Log 'Do not install this on an account containing valuable MMMN project data before verified backup and upgrade rehearsal.'
  exit 0
} catch {
  Log ('BUILD FAILED: ' + $_.Exception.Message)
  Log 'No installer was approved. Existing installed program / user project data were not intentionally changed.'
  exit 1
} finally {
  $lines.Add(('CONSOLE LOG: ' + $transcript))
  $lines | Set-Content -Path $report -Encoding UTF8
  if ($transcriptStarted) { Stop-Transcript | Out-Null }
}
