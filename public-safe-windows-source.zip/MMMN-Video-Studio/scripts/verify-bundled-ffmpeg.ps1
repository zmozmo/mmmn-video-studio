# Offline, local verification. Does not download, install, upload or modify anything.
$ErrorActionPreference = 'Stop'
$dir = Join-Path $PSScriptRoot '..\src-tauri\resources\bin'
$exe = Join-Path $dir 'ffmpeg.exe'
$info = Join-Path $dir 'FFMPEG-BUILD-INFO.txt'
if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Windows FFmpeg not bundled yet.' }
if (!(Test-Path -LiteralPath $info -PathType Leaf)) { throw 'Missing FFmpeg redistribution/license record.' }
$contents = Get-Content -LiteralPath $info -Raw
$m = [regex]::Match($contents, '(?m)^SHA256:\s*([A-Fa-f0-9]{64})\s*$')
if (!$m.Success) { throw 'FFmpeg build information needs a valid SHA256 line.' }
$expected = $m.Groups[1].Value.ToUpperInvariant()
$actual = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToUpperInvariant()
if ($expected -ne $actual) { throw 'Bundled FFmpeg checksum mismatch. Refusing Windows release.' }
$version = & $exe -hide_banner -version 2>&1 | Out-String
if ($LASTEXITCODE -ne 0 -or $version -notmatch 'ffmpeg version') { throw 'FFmpeg cannot run locally.' }
$encoders = & $exe -hide_banner -encoders 2>&1 | Out-String
if ($LASTEXITCODE -ne 0 -or $encoders -notmatch '(?m)^\s*V[^\r\n]*\blibx264\b' -or $encoders -notmatch '(?m)^\s*A[^\r\n]*\baac\b') {
  throw 'FFmpeg must include libx264 video and AAC audio encoders.'
}
# Tiny offline smoke test: no outside network, no source media touched.
$out = Join-Path $env:TEMP ([System.IO.Path]::GetRandomFileName() + '.mp4')
try {
  & $exe -nostdin -hide_banner -loglevel error -y -f lavfi -i 'color=c=blue:s=64x64:r=10:d=0.5' -f lavfi -i 'sine=frequency=440:duration=0.5' -map 0:v:0 -map 1:a:0 -c:v libx264 -pix_fmt yuv420p -c:a aac -shortest $out
  if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $out) -or (Get-Item $out).Length -lt 1024) {
    throw 'FFmpeg H.264/AAC offline render smoke test failed.'
  }
} finally { Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue }
Write-Host "FFmpeg offline check PASS; SHA256=$actual"
