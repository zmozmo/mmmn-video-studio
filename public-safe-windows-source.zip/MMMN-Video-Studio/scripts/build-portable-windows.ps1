# MMMN Video Studio: source-only, local, Windows x64 portable EXE builder.
# One-time build may require internet for PyInstaller; the finished EXE is offline.
# Does not change an existing installation, delete AppData, or create NSIS setup.exe.
param()
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$logPath = Join-Path $root 'BUILD-RESULTS.txt'
$start = Get-Date
$lines = [System.Collections.Generic.List[string]]::new()
function Log([string]$message) {
  Write-Host $message
  $script:lines.Add($message)
}
function RunChecked([string]$description, [string]$command, [string[]]$arguments) {
  Log $description
  & $command @arguments
  if ($LASTEXITCODE -ne 0) { throw "$description failed (exit=$LASTEXITCODE)" }
}
try {
  if ($env:OS -ne 'Windows_NT') { throw 'Run this builder only on Windows 10/11 x64.' }
  Set-Location $root
  $arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
  if ($arch -ne 'X64') { throw "Only x64 Windows builds have been prepared; detected $arch." }
  $py = Get-Command py.exe -ErrorAction SilentlyContinue
  $python = Get-Command python.exe -ErrorAction SilentlyContinue
  if ($py) { $pycmd = $py.Source; $pyargs = @('-3') }
  elseif ($python) { $pycmd=$python.Source; $pyargs=@() }
  else { throw 'Python 3 not found. Please install Python 3 first.' }
  RunChecked 'Check Python version' $pycmd ($pyargs + @('-c','import sys; assert sys.version_info >= (3,11); print(sys.version)'))
  $ff = Join-Path $root 'portable\bin\ffmpeg.exe'
  $fp = Join-Path $root 'portable\bin\ffprobe.exe'
  if (!(Test-Path $ff) -or !(Test-Path $fp)) {
    $onPath=Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    $probeOnPath=Get-Command ffprobe.exe -ErrorAction SilentlyContinue
    if (!$onPath -or !$probeOnPath) {
      throw 'Both ffmpeg.exe and ffprobe.exe are required. Place trusted Windows x64 copies in portable\bin or install FFmpeg and FFprobe on PATH.'
    }
    New-Item -ItemType Directory -Path (Join-Path $root 'portable\bin') -Force | Out-Null
    Copy-Item $onPath.Source $ff -Force
    Copy-Item $probeOnPath.Source $fp -Force
  }
  # Check the actual bundled binaries, not unrelated system tools.
  $encoderText = (& $ff -hide_banner -encoders 2>&1 | Out-String)
  if ($LASTEXITCODE -ne 0 -or $encoderText -notmatch 'libx264') { throw 'Bundled FFmpeg does not support the required libx264 encoder.' }
  RunChecked 'Check bundled FFprobe' $fp @('-version')
  # Only this builder process inherits the packaged FFmpeg path. User PATH is unchanged.
  $env:PATH = (Join-Path $root 'portable\bin') + ';' + $env:PATH
  $node=Get-Command node.exe -ErrorAction SilentlyContinue
  if (!$node) { throw 'Node.js 22+ required to run the mandatory source tests before packaging.' }
  RunChecked 'Run all JavaScript regression tests' $node.Source @('--test')
  $toolvenv = Join-Path $root '.mmmn-build-tools'
  $venvpy = Join-Path $toolvenv 'Scripts\python.exe'
  if (!(Test-Path $venvpy)) {
    RunChecked 'Create isolated build-only Python environment' $pycmd ($pyargs + @('-m','venv',$toolvenv))
  }
  RunChecked 'Run Python and end-to-end local backend tests' $venvpy @('scripts/run-python-tests.py','--timeout','180','--report','portable-python-tests.json')
  # Packaging requirements are installed inside .mmmn-build-tools, never into global Python.
  RunChecked 'Install PyInstaller for this local build only' $venvpy @('-m','pip','install','--disable-pip-version-check','--no-input','pyinstaller==6.16.0')
  $work=Join-Path $root '.mmmn-pyi-work'
  $dist=Join-Path $root '.mmmn-pyi-dist'
  $spec=Join-Path $root '.mmmn-pyi-spec'
  RunChecked 'Compile portable Windows executable with offline web/UI assets' $venvpy @(
    '-m','PyInstaller','--noconfirm','--clean','--onedir','--console',
    '--name','MMMN-Video-Studio','--workpath',$work,'--distpath',$dist,'--specpath',$spec,
    '--add-data','web;web','--add-data','renderer;renderer',
    '--add-data','TRIAL-REVISION.txt;.','--add-data','portable/bin;portable/bin',
    'portable/launcher.py'
  )
  $sourceDir=Join-Path $dist 'MMMN-Video-Studio'
  $exe=Join-Path $sourceDir 'MMMN-Video-Studio.exe'
  if (!(Test-Path $exe)) { throw 'Executable missing after packaging.' }
  RunChecked 'REAL Windows EXE self-test: isolated storage + H264 video frames + AAC audio' $exe @('--self-test')
  # A passing FFmpeg-only self-test does not prove import/save/backup/restore/UI.
  # Run the full offline integration against the REAL generated EXE before copying it.
  RunChecked 'REAL Windows EXE integration: local UI, imported narration, full backup, restore, 60-frame MP4' $venvpy @(
    (Join-Path $root 'tests\windows_portable_exe_smoke.py'), '--exe', $exe
  )
  RunChecked 'REAL Windows EXE Edge browser UI smoke test (isolated profile)' $venvpy @(
    (Join-Path $root 'tests\windows_edge_ui_smoke.py'), '--exe', $exe
  )
  $output=Join-Path $root 'WINDOWS-PORTABLE-OUTPUT'
  $staging=Join-Path $root 'WINDOWS-PORTABLE-OUTPUT.pending'
  # Never write to installed application or MMMN user-data directory.
  if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
  Copy-Item $sourceDir $staging -Recurse
  $stagedExe=Join-Path $staging 'MMMN-Video-Studio.exe'
  RunChecked 'Verify copied Windows EXE again' $stagedExe @('--self-test')
  if (Test-Path $output) {
    $older=Join-Path $root ('WINDOWS-PORTABLE-OUTPUT-previous-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
    Rename-Item $output (Split-Path $older -Leaf)
  }
  Rename-Item $staging (Split-Path $output -Leaf)
  $hash=(Get-FileHash (Join-Path $output 'MMMN-Video-Studio.exe') -Algorithm SHA256).Hash
  Log "WINDOWS PORTABLE EXE BUILD PASS; SHA256 $hash"
  Log 'Project and media are stored in %LOCALAPPDATA%\MMMN-Video-Studio-Trial, not in this folder.'
  Log 'NO SETUP.EXE WAS CREATED OR INSTALLED. This is a portable Windows test build.'
  exit 0
} catch {
  Log ('WINDOWS PORTABLE EXE BUILD FAILED: '+$_.Exception.Message)
  Log 'No user project, recording, media, or installed app was intentionally changed.'
  exit 1
} finally {
  $lines.Add('Elapsed: '+((Get-Date)-$start).ToString())
  $lines | Set-Content -Path $logPath -Encoding UTF8
}
