// Offline-only test bundle: transforms the existing small ESM modules to local
// closures so Chromium can exercise the UI when networking is unavailable.
// Not a production build and never fetches external dependencies.
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname,basename} from 'node:path';
const root=resolve(import.meta.dirname,'..','web');
const deps=['core.mjs','backup-safety.mjs','edit-history.mjs','native-state.mjs',
 'native-media.mjs','native-recovery.mjs','native-render-preflight.mjs',
 'zip.mjs','visual-brief.mjs','auto-edit.mjs'];
const imp=/\bimport\s*\{([^}]+)\}\s*from\s*(['"])([^'"\n]+)\2\s*;?/g;
function transform(source) {
 let imports=[];let exports=[];
 source=source.replace(imp,(_m,names,_q,ref)=>{
   if(!ref.startsWith('./'))throw Error('Nonlocal import refused: '+ref);
   imports.push(`const {${names}} = __mods[${JSON.stringify(basename(ref))}];`);
   return '';
 });
 source=source.replace(/\bexport\s+(async\s+)?function\s+(\w+)/g,(_m,a,n)=>{exports.push(n);return `${a||''}function ${n}`;});
 source=source.replace(/\bexport\s+(const|let|class)\s+(\w+)/g,(_m,a,n)=>{exports.push(n);return `${a} ${n}`;});
 return {code:imports.join('\n')+'\n'+source,exports};
}
let code='(function(){"use strict";const __mods=Object.create(null);\n';
for(const name of deps){const {code:body,exports}=transform(readFileSync(resolve(root,name),'utf8'));
 code+=`__mods[${JSON.stringify(name)}]=(function(){\n${body}\nreturn {${[...new Set(exports)].join(',')}};\n})();\n`;
}
const app=transform(readFileSync(resolve(root,'app.js'),'utf8'));
code+=app.code+'\n})();\n//# sourceURL=MMMN-inmemory-UI-smoke.js\n';
const out=process.argv[2]||'/tmp/mmmn-test-ui-bundle.js';
writeFileSync(out,code);console.log(out+' '+code.length+' bytes');
