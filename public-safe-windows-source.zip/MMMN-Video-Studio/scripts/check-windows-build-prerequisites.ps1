# Read-only Windows build prerequisites check; does not install or change system settings.
$ErrorActionPreference = 'Continue'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$results = [System.Collections.Generic.List[string]]::new()
function Check($name, $ok, $detail) {
  $state = if ($ok) { 'PASS' } else { 'MISSING' }
  $line = "$state | $name | $detail"
  Write-Host $line
  $script:results.Add($line)
}
$isWindows = ($env:OS -eq 'Windows_NT')
Check 'Windows operating system' $isWindows 'Actual Windows 11 x64 required for installer/upgrade validation'
$arch = [System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString()
Check 'x64 architecture' ($arch -eq 'X64') $arch
foreach ($item in @(@('Node.js','node.exe'),@('Python','python.exe'),@('NSIS','makensis.exe'),@('FFmpeg','ffmpeg.exe'),@('FFprobe','ffprobe.exe'))) {
  $name = $item[0]; $command = $item[1]; $found = Get-Command $command -ErrorAction SilentlyContinue
  if ($name -eq 'NSIS' -and !$found) {
    foreach ($candidate in @('C:\Program Files (x86)\NSIS\makensis.exe','C:\Program Files\NSIS\makensis.exe')) {
      if (Test-Path $candidate -PathType Leaf) { $found = @{Source=$candidate}; break }
    }
  }
  if ($name -in @('FFmpeg','FFprobe') -and !$found) {
    $local = Join-Path $root ('portable\bin\'+$command)
    if (Test-Path $local -PathType Leaf) { $found = @{Source=$local} }
  }
  Check $name ([bool]$found) $(if($found){$found.Source}else{'Not found; installation required'})
}
$edgePaths = @('C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe','C:\Program Files\Microsoft\Edge\Application\msedge.exe')
$edge = Get-Command msedge.exe -ErrorAction SilentlyContinue
Check 'Microsoft Edge for UI smoke test' ([bool]$edge -or [bool]($edgePaths | Where-Object {Test-Path $_ -PathType Leaf})) 'Edge must be installed on Windows'
$failed = @($results | Where-Object { $_ -like 'MISSING*' }).Count
$dest = Join-Path $root 'WINDOWS-PREREQUISITE-REPORT.txt'
$results.Add("MISSING COUNT: $failed")
$results.Add('After resolving missing prerequisites, run BUILD-WINDOWS-SETUP-LAB.cmd')
$results.Add('This report does not assert native Windows install/upgrade/render success.')
$results | Set-Content -Encoding UTF8 $dest
Write-Host "`nReport saved: $dest"
if ($failed -gt 0) { exit 1 } else { exit 0 }
