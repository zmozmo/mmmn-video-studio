# No automatic download. Supply a trusted redistributable Windows x64 FFmpeg executable.
param([Parameter(Mandatory=$true)][string]$FfmpegExe)
$ErrorActionPreference='Stop'
$src=(Resolve-Path -LiteralPath $FfmpegExe).Path
$dest=Join-Path $PSScriptRoot '..\src-tauri\resources\bin'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$version=& $src -hide_banner -version 2>&1 | Select-Object -First 5 | Out-String
if ($LASTEXITCODE -ne 0 -or $version -notmatch 'ffmpeg version') { throw 'Not a valid runnable FFmpeg binary' }
$license=& $src -L 2>&1 | Select-Object -First 70 | Out-String
if ($LASTEXITCODE -ne 0) { throw 'Cannot identify FFmpeg license' }
Copy-Item -LiteralPath $src -Destination (Join-Path $dest 'ffmpeg.exe') -Force
$hash=(Get-FileHash (Join-Path $dest 'ffmpeg.exe') -Algorithm SHA256).Hash
@"
FFmpeg Windows executable - external third-party program
SHA256: $hash
Source executable: $src

$version

License output (verify actual LGPL/GPL requirements before redistribution):
$license

Redistribution notice: If distributing an FFmpeg binary, fulfill that particular
build's license obligations. This text alone does not satisfy source-code delivery
or attribution obligations. Do not use an unknown build without verifying it.
"@ | Set-Content -LiteralPath (Join-Path $dest 'FFMPEG-BUILD-INFO.txt') -Encoding UTF8
Write-Host "FFmpeg prepared for Windows installer, SHA256: $hash"
