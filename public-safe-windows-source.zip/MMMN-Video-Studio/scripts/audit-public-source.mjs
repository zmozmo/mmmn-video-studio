/** Fail closed before committing any MMMN source to a PUBLIC repository.
 * No full novel text, user recordings, private Google Drive identifiers or secrets.
 * This is a safety screening aid, not a guarantee of zero sensitive content.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
function awaitableHash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');}

const root=path.resolve(process.env.MMMN_AUDIT_ROOT || path.resolve(import.meta.dirname,'..'));
const issues=[];
const demoImages = new Map([
  ['src-tauri/icons/128x128.png', '499bab1d659dc60740b5483360815463b487ceef394de57cc495c403186fd61e'],
  ['src-tauri/icons/128x128@2x.png', '4d07c081556f15f98c33bc03f11966955877b43c7e9f7a5096b78faa42810798'],
  ['src-tauri/icons/32x32.png', '9f494a549da1ea4a38513d55514f20e8eae647ec7c41fc6589999ab760caf346'],
  ['src-tauri/icons/icon.ico', '9fa3717a9d3063db77556f6fbb24f28cc438d2515ff527cc2393251130961ea2'],
  ['web/resources/images/01_Htut_Khaung.png', '6c0f1b0591e6870a80b092798dc533eb113230d270adde85c7b7931a38befcb1'],
  ['web/resources/images/02_Htun_Gyi.png', '84e18756c9ebe0e30d8356b7d1612f937d3bbbc0a64fc2e96d849dbc573aee52'],
  ['web/resources/images/03_Maung_Khein.png', '0bf4f2649926fddd98a0a31461faa61e4e4285938263ee88d120bfaab99a0825'],
  ['web/resources/images/04_Pyo_May_Khin.png', 'aa69229dbf8293edaa29ebd9066672c01c09c9a4a1db2761e600942669b0912d'],
  ['web/resources/images/05_U_Thet_Tun.png', 'f0285b38007015d647f725d06692a8b4a451afca8c46045d43971a9f2d83c75b'],
  ['web/resources/images/06_U_Thaik_Maung.png', '6d76a631d250f9e85dfc0e565b06e0967f22c44a2ee3544cc27940ae6c5865ef'],
  ['web/resources/images/Bird_Cry_Island_Setting_Visual_Board_v01.png', 'bb8c0a93dc0f8e0764dbbfd4b6823d0a9ea4ad14bd38cb460edd8744df8be8d1'],
  ['web/resources/images/Visual_Concept_Moodboard_1970s.png', '30ea5b0debc6281a2964eff7f706ae9a44c553573cdaa57de5fabfcbe2e9a26f'],
]);

const blockedDirs=new Set(['.git','node_modules','dist','dist-base','dist-upgrade','build','build-base','build-upgrade','.mmmn-build-tools','WINDOWS-SETUP-LAB-OUTPUT','__pycache__']);
const skipExt=new Set(['.png','.jpg','.jpeg','.gif','.webp','.ico','.mp4','.mp3','.wav','.ogg','.exe','.dll','.pdf','.woff','.woff2']);
const forbiddenExt=/\.(?:pem|p12|pfx|key|sqlite|sqlite3|db|env|bak|zip|7z|rar|tar|gz|pdf|docx|xlsx|pptx|mp4|mp3|wav|mov|webm)$/i;
const secretPatterns=[
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /(?:github_pat_|ghp_|gho_)[A-Za-z0-9_]{16,}/,
  /(?:cloudinary_api_secret|google_client_secret|api[_-]?secret)\s*[=:]\s*['"]?[A-Za-z0-9_\-]{12,}/i,
  /https?:\/\/drive\.google\.com\/(?:drive\/folders\/|file\/d\/|open\?id=)/i,
];
function check(relative){
 const absolute=path.join(root,relative);const stat=fs.statSync(absolute);
 if(stat.isDirectory()){
   const part=path.basename(relative);
   if(blockedDirs.has(part)||part.startsWith('.mmmn-setup-lab'))return;
   for(const name of fs.readdirSync(absolute))check(path.join(relative,name));
   return;
 }
 if(!stat.isFile())return;
 const unix=relative.split(path.sep).join('/');
 if(forbiddenExt.test(unix) || /(^|\/)\.env(?:\.|$)/.test(unix))issues.push(`${unix}: secret/data extension`);
 if(/\/(?:recordings|personal|backups|originals)\//i.test('/'+unix))issues.push(`${unix}: private project folder`);
 if(stat.size>10*1024*1024)issues.push(`${unix}: unexpectedly large source file`);
 if(['.png','.ico'].includes(path.extname(unix).toLowerCase())){
   const expected=demoImages.get(unix);
   if(!expected || (awaitableHash(absolute))!==expected)issues.push(`${unix}: binary image is not an approved demo/icon asset`);
 }
 if(skipExt.has(path.extname(unix).toLowerCase()))return;
 const content=fs.readFileSync(absolute,'utf8');
 for(const re of secretPatterns){if(re.test(content)){
   // This audit script necessarily contains the signatures; do not flag itself.
   if(unix!=='scripts/audit-public-source.mjs')issues.push(`${unix}: sensitive data pattern`);
   break;
 }}
 if(unix==='web/resources/novel.txt' && !content.startsWith('Demo placeholder.'))issues.push(`${unix}: non-demo manuscript content`);
 if(unix==='web/resources/drive-index.json' && content.trim()!=='{}')issues.push(`${unix}: drive references must be empty in public build`);
}
for(const file of fs.readdirSync(root))check(file);
if(issues.length){console.error('PUBLIC SOURCE AUDIT FAIL\n'+issues.join('\n'));process.exitCode=1;}
else console.log('PUBLIC SOURCE AUDIT PASS (heuristic source/secret/data checks; manual review still required)');
