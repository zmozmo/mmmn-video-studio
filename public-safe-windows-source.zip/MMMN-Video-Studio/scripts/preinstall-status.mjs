import fs from 'node:fs';
const tauri=JSON.parse(fs.readFileSync('src-tauri/tauri.conf.json','utf8'));
const rust=fs.readFileSync('src-tauri/src/lib.rs','utf8');
const snap=fs.readFileSync('src-tauri/src/snapshots.rs','utf8');
const ui=fs.readFileSync('web/app.js','utf8');
const tasks=[
 ['Stable app identity + in-place NSIS config',tauri.identifier==='com.mmmn.videostudio'&&tauri.bundle.windows.nsis.installMode==='currentUser'],
 ['Windows WebView2 offline installer planned',tauri.bundle.windows.webviewInstallMode?.type==='offlineInstaller'],
 ['Source backup integrity guard',ui.includes('verifyBackupIndex(await readZip(zip))')],
 ['Native media import built into source',rust.includes('import_media_chunk')&&rust.includes('finalize_media_import')],
 ['Native local H264/AAC render command implemented',rust.includes('render_chapter_command')],
 ['Streaming native snapshot and restore source',snap.includes('copy_hash')&&snap.includes('restore_local_backup')&&snap.includes('Sha256')],
 ['Separate recovery utility and tests',fs.existsSync('tools/snapshot_recovery.py')&&fs.existsSync('tests/native_snapshot_recovery_test.py')],
 ['Bundled licensed FFmpeg Windows binary ready',fs.existsSync('src-tauri/resources/bin/ffmpeg.exe')&&fs.existsSync('src-tauri/resources/bin/FFMPEG-BUILD-INFO.txt')],
 ['NPM lockfile ready',fs.existsSync('package-lock.json')],
 ['Rust Cargo.lock ready',fs.existsSync('src-tauri/Cargo.lock')],
 ['Windows native compile validated',false],
 ['Windows installer setup.exe built + hash verified',false],
 ['Install → in-place upgrade → restored data verified on Windows',false],
 ['Full GUI end-to-end (import→edit→render→backup→restore)',false]
];
let passed=0;
for (const [title,ok] of tasks){if(ok)passed++;console.log(`${ok?'PASS   ':'BLOCKED'} ${title}`)}
console.log(`\nSource readiness: ${passed}/${tasks.length} checks present. ${tasks.length-passed} blockers or unverified stages remain.`);
console.log('SETUP.EXE RELEASE: NOT AUTHORIZED / NOT TESTED.');
if(process.argv.includes('--require-ready')&&passed!==tasks.length)process.exitCode=1;
