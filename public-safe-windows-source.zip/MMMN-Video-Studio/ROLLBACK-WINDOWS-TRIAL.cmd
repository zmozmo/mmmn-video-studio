@echo off
setlocal
cd /d "%~dp0"
echo MMMN Video Studio -- RESTORE PREVIOUS PROGRAM VERSION
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 tools\windows_trial_updater.py --rollback
) else (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 required. No files changed.
    pause
    exit /b 1
  )
  python tools\windows_trial_updater.py --rollback
)
if errorlevel 1 (
  echo Rollback could not complete. No user data was removed.
  pause
  exit /b 1
)
pause
endlocal
