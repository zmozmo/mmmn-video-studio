@echo off
setlocal
cd /d "%~dp0"
echo MMMN Video Studio - Build Offline Windows Portable EXE
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-portable-windows.ps1"
set "MMMN_BUILD_RESULT=%ERRORLEVEL%"
if not "%MMMN_BUILD_RESULT%"=="0" (
  echo.
  echo BUILD FAILED. Read BUILD-RESULTS.txt for the cause. Your MMMN projects were NOT deleted.
) else (
  echo.
  echo Build passed: WINDOWS-PORTABLE-OUTPUT\MMMN-Video-Studio.exe
  echo This is a portable trial, NOT an installer.
)
pause
exit /b %MMMN_BUILD_RESULT%
