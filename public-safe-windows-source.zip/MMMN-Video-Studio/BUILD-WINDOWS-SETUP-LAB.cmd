@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\build-windows-setup-lab.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" (echo BUILD FAILED. Read WINDOWS-SETUP-LAB-OUTPUT\BUILD-REPORT.txt) else (echo UNSIGNED LAB INSTALLER BUILT. Windows in-place upgrade evidence is still required.)
pause
exit /b %EXIT_CODE%
