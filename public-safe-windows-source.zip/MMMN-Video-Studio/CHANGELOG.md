## Windows-only audio narration and export safety — 2026-11-07

- Fixed the blocking bug where importing an MP3/WAV audio recording succeeded but the MP4 Export preflight required a camera/video input.
- Supported narration sources: MP3, WAV, M4A, OGG, AAC, or original recorded video. Uses original audio; no generated voice or cloud call.
- One-click Windows export view now prioritizes MP4 and hides CMD/ZIP build instructions in installed portable mode.
- Default export quality is full platform resolution, not half-resolution preview.
- Audio-import failure leaves the previous recording reference unchanged.
- Existing video projects remain supported, including their original source IDs.
- Added real FFmpeg audio-only WAV/MP3 H.264/AAC integration checks, pause-analysis check, and installed-executable e2e smoke coverage.
- Windows native setup.exe build, Windows 11 install/upgrade QA, and public GitHub CI remain UNVERIFIED and BLOCKED by GitHub write integration permissions / unavailable Windows runner.

## Windows Trial R7 — 2026-11-01
- Non-blocking local render jobs, progress/percent status, and safe FFmpeg cancellation.
- One-active-render guard, persisted completed MP4 exports, browser refresh reconnection for active job.
- Quick Preview at half resolution and Full Quality at existing preset resolution.
- Narrator video duration preflight before expensive scene encoding.
- New Python integration tests for HTTP auth, jobs, preview frame/audio and cancellation.
- Not a Windows native installer; no install/upgrade claim.

## v0.14.0 — Pre-install source hardening

See `V0.14-CHANGELOG-MM.md` and `V0.14-RELEASE-AUDIT-MM.md`.

## v0.12.0 — Windows build + render safety

- Fixed Tauri 2 offline FFmpeg resource destination mapping.
- Fail-closed renderer binary lookup for Windows release builds.
- Added dual frontend/Rust narration duration and local media preflight.
- Added Windows FFmpeg SHA-256 / x264 / AAC / smoke test build gate.
- Added manual GitHub Actions Windows Rust/Tauri no-bundle compile audit and lockfile artifacts.
- Added Windows upgrade before/after read-only media hash checker.
- Added audio-preserving 2-scene real FFmpeg regression fixture.
- Setup.exe NOT built; no native Windows validation is claimed.

## v0.11.0 Windows Recovery Foundation — Source only
**Setup.exe မထုတ်ရသေးပါ။** Streaming native media snapshot, SHA-256 verify, restore, Offline recovery tool, Windows FFmpeg packaging gate တို့ကို ထည့်ထားသည်။
**Windows Rust Compile/Installer/Install→Upgrade မစမ်းရသေးပါ။** အသေးစိတ် `V0.11-RELEASE-REVIEW-MM.md` ကို ဖတ်ပါ။

---

## 0.9.0 — Windows Installer Preparation and Upgrade Data Safety

- NSIS currentUser Setup.exe configuration, stable app ID, Windows Actions build pipeline.
- Native JSON project persistence, recovery copy, pre-upgrade snapshot on version change.
- Migration from existing localStorage and new Windows Updates panel + backup guidance.
- Upgrade contract CI guard, 7 extra unit tests. No completed Windows installer claim.

## v0.8.0
- Add offline FFmpeg pause timing analysis and read-only timing JSON import.
- Preserve manually approved/SRT boundaries and protect against recording-length changes.
- Add Windows helper, Python and JS unit tests, real 12s MP4 silence-detection fixture.
- Drive remains input only; no Google Drive file writes.

# v0.7.0 — Narration Evidence Alignment + Safe Export Preflight

- Timestamped Burmese SRT cue → actual manuscript scene matching in chronological order. Exact text first, conservative character n-gram fallback for imperfect transcript. Cue match CSV (local).
- New **Narration Evidence နဲ့ Scene Auto-Align**: proposes cut boundaries from cues without overwriting manual locks. Proposed timestamps still require video review.
- SRT Cue Navigator: jump narration video/audio to an exact subtitle timestamp when manually adjusting a scene.
- **CPU renderer final safety gate:** rejects missing images, missing audio tracks, video/audio duration vs scene-duration mismatch >1 sec BEFORE rendering hundreds of shots; `--check-only` for free quick validation.
- 30 JavaScript tests (23 existing + 7 new), 6 Python media preflight tests, 4-second technical MP4 H.264/AAC smoke. Live user narration and Burmese ASR model not tested.
- Source only. No compiled EXE/APK, no native read-only Drive OAuth, no Google Drive writes, no background cloud dependency. Browser UI E2E still blocked by local sandbox navigation restrictions.

# v0.6.0 (2026-10-30) — Local SRT correction and human review

- Editable Myanmar SRT subtitle panel (save local project, export corrected `.srt` to device).
- SRT overlap/out-of-video range diagnostics before accepting edited subtitle text.
- Conservative SRT alignment: source timestamps propose scene anchors; scenes with manually adjusted `manual-locked` boundaries retain their timing when aligned again. Rejected/unmatched cues remain estimates.
- Next Review Scene button and local per-chapter Review CSV (unassigned image, image not confirmed, timing estimated).
- Fix cumulative split count in scene splitter (number of newly added scenes now accurate).
- 23 core logic tests pass; local CPU test video with crossfade+PIP output 4.00 seconds H.264/AAC.
- No network upload or Google Drive write. NO full UI E2E in this sandbox (browser blocks navigation), NO Windows EXE/Android APK and NO proven Burmese ASR in this release.

# v0.5.0 (2026-10-30)

- Local explainable keyword/phrase-overlap matching between each chapter scene and its visual plan requirements. Nothing is silently called semantic AI.
- Auto Suggest Scene Pictures with review confidence, conservative overwrite behavior and manual confirmation locks.
- Mark Start Here: precise scene boundary movement at current narrator video/audio playhead; neighbor duration compensation keeps total unchanged.
- Optional visual-change sentence splitter: detect multiple illustration needs within a single existing paragraph/scene, e.g. Yangon street then tea shop; requires human approval.
- Export per-scene Visual Match Review CSV locally for missing/uncertain assignments.
- Existing Drive input-only, offline CPU render and non-GPU architecture preserved.

# v0.4.0 (2026-10-30)

- MMMN-only local video editor.
- Story scene split at current narrator playhead or midpoint, merge adjacent scenes.
- Manual scene duration changes preserve total narration timeline using neighbor compensation (last shot locked).
- Visual Requirement ID selector and auto-link to locally imported matching BI-### image.
- Missing-visual CSV report downloaded **only to local device**.
- Warning on rebuilding scenes (to protect manual changes).
- Count narration video as recorded chapter in progress stats.
- Optional external offline `whisper.cpp` SRT bridge (requires user-provided executable and locally downloaded multilingual model; not tested with Burmese model).

# v0.3.0 — October 30 2026
- Original narrator-video import and local source monitor.
- Optional SRT timestamp parsing/chronological scene anchors, with unaligned scenes labelled estimates.
- Manual ±0.5s scene-boundary shift, motion and still/pan/zoom selection.
- Optional PIP, cut or blended transitions in CPU FFmpeg renderer; soundtrack comes from original recording.
- Media storage limit warning and --source-video local-path override.
- Local-first and Drive read-only policies preserved.
- Validation: 7 Node tests pass, sample 6-second MP4 (H.264/AAC) pass. UI E2E unavailable in test sandbox. Windows/Android native binaries not built.

## 2026-11-04 continuation
- Added bounded per-module Python verification and explicit quick/full reports.
- No installer released; Windows native installation evidence still required.
