@echo off
setlocal
cd /d "%~dp0"
echo MMMN Video Studio -- OFFLINE Windows trial install / in-place update
echo Program files update. Projects/videos/photos/backups are NEVER uninstalled.
echo.
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 tools\windows_trial_updater.py
) else (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 is required for this Windows Trial.
    echo No existing installation or project files were changed.
    pause
    exit /b 1
  )
  python tools\windows_trial_updater.py
)
if errorlevel 1 (
  echo.
  echo UPDATE FAILED. Your original program and projects remain protected.
  pause
  exit /b 1
)
echo.
echo SUCCESS: Open MMMN Video Studio Trial from Start Menu.
echo Updates: unzip a newer package and double-click THIS file again.
pause
endlocal
