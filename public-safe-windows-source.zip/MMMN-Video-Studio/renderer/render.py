#!/usr/bin/env python3
"""MMMN Studio CPU-only offline renderer; Python stdlib + FFmpeg, no cloud or paid APIs."""
from __future__ import annotations
import argparse, json, math, shutil, subprocess, sys, tempfile
from pathlib import Path

PRESETS={"youtube":(1920,1080),"tiktok":(1080,1920),"reels":(1080,1920),"shorts":(1080,1920),"square":(1080,1080),"facebook":(1080,1350)}
FPS=24

def run(cmd):
    result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace')
    if result.returncode:
        raise RuntimeError('FFmpeg command failed:\n'+' '.join(str(a) for a in cmd[:10])+' ...\n'+result.stderr[-2800:])

def asset_path(base,asset):
    rel=asset.get('exportPath')
    if not rel:return None
    base=base.resolve()
    file=(base/rel).resolve()
    if not file.is_relative_to(base):raise ValueError('Unsafe media path')
    return file if file.is_file() else None

def filter_video(motion,width,height,seconds,fps):
    # Scene transitions happen after shots are created; do not fade through black.
    if motion=='still':
        return f'scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},format=yuv420p'
    base=f'scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},'
    if motion=='pan':
        z='1.12';x=f'(iw-iw/zoom)*on/{max(1,int(seconds*fps)-1)}';y='ih/2-(ih/zoom/2)'
    else:
        z='min(zoom+0.00055,1.13)';x='iw/2-(iw/zoom/2)';y='ih/2-(ih/zoom/2)'
    return base+f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={width}x{height}:fps={fps},format=yuv420p"


def probe_duration(path):
    command=['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]
    r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if r.returncode:raise RuntimeError('Cannot inspect narration media: '+r.stderr[:400])
    try:return float(r.stdout.strip())
    except ValueError:raise RuntimeError('Invalid narration duration')


def probe_stream(path,kind):
    r=subprocess.run(['ffprobe','-v','error','-select_streams',f'{kind}:0',
            '-show_entries','stream=index','-of','csv=p=0',str(path)],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if r.returncode:raise ValueError('Cannot inspect narration streams: '+r.stderr[:250])
    return bool(r.stdout.strip())


def validate_narration(sound,seconds,presenter='none',draft=False):
    """Preflight before expensive CPU rendering; never silently truncate a final narration."""
    if sound is None:
        if not draft:raise ValueError('Final MP4 requires a narration video/audio file')
        return
    if not sound.is_file():raise ValueError('Narration file not found: '+str(sound))
    if not probe_stream(sound,'a'):
        raise ValueError('Narration source has no audio track. Select a recording with your voice.')
    if presenter=='pip' and not probe_stream(sound,'v'):
        raise ValueError('Presenter PIP needs a video recording, not audio-only media.')
    source_seconds=probe_duration(sound)
    if not draft and abs(source_seconds-seconds)>1.0:
        raise ValueError(f'Narration {source_seconds:.2f}s vs visual timeline {seconds:.2f}s: '
                         'difference >1 second. Adjust scene boundaries before final export to prevent missing words or silent ending.')


def validate_chapter(ch,assets,base,draft=False,external_video=None,presenter='none'):
    scenes=ch.get('scenes') or fallback_scenes(ch)
    duration=sum(max(.3,float(x.get('duration') or 1)) for x in scenes)
    missing=[]
    if not draft:
        for scene in scenes:
            asset=assets.get(scene.get('assetId'))
            if not asset or not asset_path(base,asset):
                missing.append(f"{scene.get('id','scene')}: background {scene.get('imageRequirementId') or 'unplanned'} missing")
    video=external_video
    if video is None:
        va=assets.get(ch.get('videoAssetId'))
        video=asset_path(base,va) if va else None
    audio_asset=assets.get(ch.get('audioAssetId'))
    audio=asset_path(base,audio_asset) if audio_asset else None
    sound=video or audio
    if presenter=='pip' and not video:
        missing.append('Presenter PIP selected, but narrator video not provided')
    if missing:
        raise ValueError('Final scene preflight failed (first 15):\n'+'\n'.join(missing[:15])+
                         (f'\n... and {len(missing)-15} more' if len(missing)>15 else ''))
    validate_narration(sound,duration,presenter if video else 'none',draft)
    return scenes,duration,video,audio

def join_clips(clips,work,scenes,transition_mode='dissolve',fps=24):
    joined=work/'visuals.mp4'
    if len(clips)==1:shutil.copy2(clips[0],joined);return joined
    if transition_mode=='cut':
        segments=clips
    else:
        tr=max(1,round(min(.5,min(max(.3,float(s.get('duration') or 1)) for s in scenes)/2)*fps))/fps
        segments=[]
        # Blend short adjacent frame windows; avoids GPU and supports stock FFmpeg.
        # Main + transitions sum to the original scene timeline, so narration stays continuous.
        for i,scene in enumerate(scenes):
            seconds=max(.3,float(scene.get('duration') or 1))
            skip=tr if i else 0
            length=seconds-skip
            main=work/f'main_{i:04d}.mp4'
            run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(clips[i]),'-ss',f'{skip:.5f}',
                 '-t',f'{length:.5f}','-vf','setpts=PTS-STARTPTS', '-an','-c:v','libx264',
                 '-preset','ultrafast','-crf','25','-r',str(fps),'-pix_fmt','yuv420p',str(main)])
            segments.append(main)
            if i+1<len(clips):
                a=work/f'transition_{i:04d}.mp4';next_scene=clips[i+1]
                # Last tr seconds from extended previous shot, first tr of next shot.
                start=seconds
                fg=(f'[0:v]trim=start={start:.5f}:end={start+tr:.5f},setpts=PTS-STARTPTS[x];'
                    f'[1:v]trim=start=0:end={tr:.5f},setpts=PTS-STARTPTS[y];'
                    f"[x][y]blend=all_expr='A*(1-T/{tr:.5f})+B*(T/{tr:.5f})',format=yuv420p[v]")
                run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(clips[i]),'-i',str(next_scene),
                     '-filter_complex',fg,'-map','[v]','-an','-c:v','libx264','-preset','ultrafast',
                     '-crf','25','-r',str(fps),'-pix_fmt','yuv420p',str(a)])
                segments.append(a)
    listing=work/'segments.txt'
    listing.write_text(''.join(f"file '{p.name}'\n" for p in segments),encoding='utf-8')
    run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(listing),
         '-c','copy','-movflags','+faststart',str(joined)])
    return joined


def fallback_scenes(chapter):
    text=chapter.get('text','')
    paras=[x.strip() for x in text.splitlines() if x.strip()]
    if not paras:return [{'text':'','duration':12,'motion':'still','assetId':None}]
    # First render can work even without explicit storyboard; edit in UI for precision.
    duration=max(10,len(text.replace(' ',''))/500*60)
    count=max(1,math.ceil(duration/30))
    return [{'text':paras[min(len(paras)-1,int(i*len(paras)/count))], 'duration':duration/count,'motion':'zoom','assetId':None} for i in range(count)]

def ffmpeg_check():
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):raise SystemExit('FFmpeg/FFprobe မတွေ့ပါ။ Install FFmpeg (free) and add both to PATH.')

def render_chapter(ch,assets,base,work,preset,force_draft=False,external_video=None,presenter='none'):
    width,height=PRESETS[preset];fps=FPS
    if force_draft:
        # Preview resolution must retain the final platform aspect ratio.
        preview_scale=min(1.,640/max(width,height))
        width=max(2,int(round(width*preview_scale/2))*2)
        height=max(2,int(round(height*preview_scale/2))*2)
        fps=12
    scenes,duration,video,audio=validate_chapter(ch,assets,base,force_draft,external_video,presenter)
    mode=ch.get('transitionMode','dissolve')
    tr=(max(1,round(min(.5,min(max(.3,float(x.get('duration') or 1)) for x in scenes)/2)*fps))/fps) if mode!='cut' and len(scenes)>1 else 0
    clips=[]
    for i,scene in enumerate(scenes):
        sec=max(.3,float(scene.get('duration') or 1))
        asset=assets.get(scene.get('assetId'));image=asset_path(base,asset) if asset else None
        clip=work/f'shot_{i:04d}.mp4'
        # Each clip overlaps the next by tr seconds; xfade subtracts that overlap.
        length=sec+(tr if i<len(scenes)-1 else 0)
        if image:
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate',str(fps),'-i',str(image),'-vf',filter_video(scene.get('motion','zoom'),width,height,length,fps),'-t',str(length),'-an','-c:v','libx264','-preset','ultrafast' if force_draft else 'veryfast','-crf','29' if force_draft else '23','-r',str(fps),'-pix_fmt','yuv420p',str(clip)]
        else:
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',f'color=c=0x152334:s={width}x{height}:r={fps}', '-t',str(length),'-an','-c:v','libx264','-preset','ultrafast' if force_draft else 'veryfast','-crf','29' if force_draft else '23','-r',str(fps),'-pix_fmt','yuv420p',str(clip)]
        run(cmd);clips.append(clip)
        print(f'    scene {i+1}/{len(scenes)} rendered ({sec:.1f}s)',flush=True)
    joined=join_clips(clips,work,scenes,mode,fps)
    sound=video or audio
    output=work/'chapter.mp4'
    if video and presenter=='pip':
        pip_width=max(120,int(width*.24)//2*2)
        # PIP is the ORIGINAL narrator footage, no claim of person segmentation or green-screen removal.
        # Audio comes unmodified from the original narration-video track.
        filtergraph=(f'[1:v]scale={pip_width}:-2,format=yuv420p[p];'
                     f'[0:v][p]overlay=W-w-24:H-h-24:shortest=0:repeatlast=1,format=yuv420p[out]')
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(joined),'-i',str(video),
             '-filter_complex',filtergraph,'-map','[out]','-map','1:a:0','-c:v','libx264',
             '-preset','veryfast','-crf','23','-c:a','aac','-b:a','192k','-t',f'{duration:.3f}',
             '-movflags','+faststart',str(output)])
    elif sound:
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(joined),'-i',str(sound),
             '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k',
             '-t',f'{duration:.3f}','-movflags','+faststart',str(output)])
    else:
        run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(joined),'-f','lavfi','-i','anullsrc=r=48000:cl=stereo',
             '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k',
             '-t',f'{duration:.3f}','-movflags','+faststart',str(output)])
    return output


def main():
    ap=argparse.ArgumentParser(description='MMMN Free Offline CPU MP4 Renderer')
    ap.add_argument('--project',default='project.json');ap.add_argument('--preset',choices=PRESETS,default='youtube')
    ap.add_argument('--chapter',default='1',help='Chapter number (1-22) or all')
    ap.add_argument('--draft',action='store_true',help='Small/fast test render');ap.add_argument('--output',default='')
    ap.add_argument('--source-video',default='',help='Local original narration video file path (no upload)')
    ap.add_argument('--presenter',choices=['none','pip'],default='',help='Optional narrator video PIP (not background removal)')
    ap.add_argument('--check-only',action='store_true',help='Validate local images/audio/durations before CPU rendering; does not create an MP4')
    args=ap.parse_args();ffmpeg_check();base=Path(args.project).resolve().parent
    with open(args.project,encoding='utf-8') as f:p=json.load(f)
    chapters=p.get('chapters') or []
    if args.chapter=='all':selected=chapters;tag='all'
    else:
        number=int(args.chapter)
        if number<1 or number>len(chapters):raise SystemExit('Invalid chapter number')
        selected=[chapters[number-1]];tag=f'ch{number:02d}'
    if not selected:raise SystemExit('No chapters')
    if args.source_video and len(selected)!=1:raise SystemExit('--source-video requires --chapter NUMBER (not all)')
    assets={a.get('id'):a for a in p.get('assets',[])}
    if not args.draft:
        missing=[]
        for ch in selected:
            audio=assets.get(ch.get('audioAssetId'));video=assets.get(ch.get('videoAssetId'))
            if not ((audio and asset_path(base,audio)) or (video and asset_path(base,video)) or args.source_video):
                missing.append(f"{ch.get('title')}: Narration video/audio missing")
            for scene in ch.get('scenes') or fallback_scenes(ch):
                asset=assets.get(scene.get('assetId'))
                if not asset or not asset_path(base,asset):
                    missing.append(f"{ch.get('title')}, {scene.get('id','scene')}: background {scene.get('imageRequirementId','unplanned')} missing")
        if missing:
            raise SystemExit('Final MP4 blocked: incomplete story visuals/audio.\n'+'\n'.join(missing[:20])+ (f'\n... plus {len(missing)-20} more' if len(missing)>20 else '')+'\nUse --draft only for a temporary preview.')
    # Preflight before allocating frames or creating output files. 
    # A complete chapter must have a voice recording with duration matching the visuals.
    for ch in selected:
        validate_chapter(ch,assets,base,args.draft,
                         Path(args.source_video).expanduser().resolve() if args.source_video else None,
                         args.presenter or ch.get('presenterMode','none'))
    if args.check_only:
        print(f'PREFLIGHT PASS: {len(selected)} chapter(s); '+ ('DRAFT (media may be missing)' if args.draft else 'all media + narration verified') + '. No video rendered.')
        return
    destination=Path(args.output) if args.output else base/f'MMMN-{tag}-{args.preset}{"-draft" if args.draft else ""}.mp4'
    destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mmmn_render_') as tmp:
        temp=Path(tmp);all_outputs=[]
        for j,ch in enumerate(selected):
            work=temp/f'ch_{j:03d}';work.mkdir();print('Chapter:',ch.get('title',j+1),flush=True)
            output=render_chapter(ch,assets,base,work,args.preset,args.draft,Path(args.source_video).expanduser().resolve() if args.source_video else None, args.presenter or ch.get('presenterMode','none'))
            all_outputs.append(output)
        if len(all_outputs)==1:shutil.copy2(all_outputs[0],destination)
        else:
            listing=temp/'chapters.txt'
            listing.write_text(''.join(f"file '{file.as_posix()}'\n" for file in all_outputs),encoding='utf-8')
            run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(destination)])
    print('MP4 READY:',destination)

if __name__=='__main__':
    try:main()
    except (RuntimeError,ValueError,OSError) as e:print('ERROR:',e,file=sys.stderr);sys.exit(1)
