#!/usr/bin/env python3
"""Optional 100% local video -> SRT bridge for an installed whisper.cpp CLI.

No model or executable bundled, no accounts and no network. This tool does NOT
promise good Burmese accuracy; review/correct the SRT before scene alignment.
"""
import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def convert_and_transcribe(video: Path, model: Path, whisper: Path, output: Path, threads: int = 4):
    for label, p in [('Video', video), ('multilingual whisper.cpp model', model), ('whisper-cli executable', whisper)]:
        if not p.is_file():
            raise FileNotFoundError(f'{label} not found: {p}')
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError('FFmpeg missing: install offline FFmpeg and add ffmpeg.exe to PATH')
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() != '.srt':
        raise ValueError('--output must end in .srt')
    if output.exists():
        raise FileExistsError(f'Output exists; preserve previous annotations: {output}')
    with tempfile.TemporaryDirectory(prefix='mmmn_asr_') as td:
        wav = Path(td) / 'narration.wav'
        subprocess.run([ffmpeg, '-hide_banner', '-loglevel', 'error', '-y', '-i', str(video),
                        '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', str(wav)], check=True)
        # whisper-cli -of expects a base name without .srt. Run completely offline.
        basename = str(Path(td) / 'captions')
        subprocess.run([str(whisper), '-m', str(model), '-f', str(wav), '-l', 'my',
                        '-t', str(max(1, min(16, threads))), '-ng', '-osrt', '-of', basename], check=True)
        produced = Path(basename + '.srt')
        if not produced.exists() or produced.stat().st_size < 4:
            raise RuntimeError('whisper-cli did not create a valid SRT')
        shutil.copy2(produced, output)
    return output


def main():
    p = argparse.ArgumentParser(description='Offline local narrator video -> Burmese SRT using your installed whisper.cpp; no uploads')
    p.add_argument('--video', required=True, type=Path, help='Your local recorded MP4/MOV')
    p.add_argument('--model', required=True, type=Path, help='Your local MULTILINGUAL ggml model (NOT *.en.bin)')
    p.add_argument('--whisper', required=True, type=Path, help='Local whisper-cli(.exe)')
    p.add_argument('--output', required=True, type=Path, help='New local output file ending .srt')
    p.add_argument('--threads', type=int, default=4)
    args = p.parse_args()
    if args.model.name.lower().endswith('.en.bin'):
        p.error('English-only models do not support Burmese. Use a multilingual ggml model.')
    try:
        out = convert_and_transcribe(args.video.resolve(), args.model.resolve(), args.whisper.resolve(), args.output, args.threads)
        print('SRT READY (please proofread Burmese):', out)
    except (OSError, RuntimeError, subprocess.CalledProcessError, ValueError) as err:
        print('ERROR:', err, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
