@echo off
setlocal
cd /d "%~dp0"
if not exist "project.json" (
  echo project.json missing. Extract the complete Render ZIP first.
  pause
  exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (echo FFmpeg not found in PATH. & pause & exit /b 1)
where ffprobe >nul 2>nul
if errorlevel 1 (echo ffprobe not found in PATH. & pause & exit /b 1)
set /p VIDEO=Enter full path to narrator MP4/MOV: 
set /p CHAPTER=Enter chapter number (e.g. 1): 
py -3 align_pauses.py --project "project.json" --video "%VIDEO%" --chapter %CHAPTER%
if errorlevel 1 (echo Audio analysis failed. & pause & exit /b 1)
echo Pause timing JSON created here. Import it using MMMN Studio - Pause Timing JSON (CPU).
pause
