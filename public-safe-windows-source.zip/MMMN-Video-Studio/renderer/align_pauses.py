#!/usr/bin/env python3
"""Offline narration pause-aware shot timing. NO speech recognition or network.

Use one local narrator recording per chapter; infer *possible* scene boundaries by
proportional Myanmar manuscript length, then optionally snap to a nearby audible
pause detected by FFmpeg. Every boundary remains a suggestion pending human review.
"""
from __future__ import annotations
import argparse
import json
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path

MIN_SCENE = 0.35


def run_probe(media: Path) -> float:
    if not media.is_file():
        raise ValueError(f'Local recording not found: {media}')
    if not shutil.which('ffprobe'):
        raise RuntimeError('ffprobe missing; install FFmpeg locally first')
    p = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type',
                        '-of', 'json', str(media)], capture_output=True, text=True, check=True)
    info = json.loads(p.stdout)
    if not any(s.get('codec_type') == 'audio' for s in info.get('streams', [])):
        raise ValueError('Recording has no audio track')
    duration = float(info.get('format', {}).get('duration') or 0)
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('Recording duration is invalid')
    return duration


def parse_silences(log: str, duration: float):
    """Return candidate mid-pause positions and silence lengths."""
    events=[]
    for line in log.splitlines():
        m=re.search(r'silence_start:\s*(-?[\d.]+)', line)
        if m:
            events.append(('start', float(m.group(1))))
        m=re.search(r'silence_end:\s*([\d.]+)', line)
        if m:
            events.append(('end', float(m.group(1))))
    pending=None; pauses=[]
    for typ, time in events:
        if typ=='start': pending=max(0,time)
        elif pending is not None:
            end=min(duration,time)
            if end>pending:
                pauses.append({'time':round((pending+end)/2,3), 'seconds':round(end-pending,3)})
            pending=None
    if pending is not None and duration>pending:
        pauses.append({'time':round((pending+duration)/2,3), 'seconds':round(duration-pending,3)})
    return [p for p in pauses if p['time']>.1 and p['time']<duration-.1]


def detect_silences(media: Path, duration: float, threshold: str='-32dB', min_pause: float=.25):
    if not shutil.which('ffmpeg'):
        raise RuntimeError('ffmpeg missing; install FFmpeg locally first')
    if not re.fullmatch(r'-?(?:\d+(?:\.\d+)?)(?:dB)?', threshold):
        raise ValueError('Invalid threshold (e.g. -32dB)')
    cmd=['ffmpeg','-nostdin','-hide_banner','-i',str(media),'-vn',
         '-af',f'silencedetect=noise={threshold}:d={min_pause:.3f}', '-f','null','-']
    result=subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('FFmpeg audio analysis failed: '+result.stderr[-800:])
    return parse_silences(result.stderr,duration)


def boundaries(scenes: list, duration: float, pauses: list, max_snap=4.0):
    """Lock human-approved boundaries; choose nearby pauses conservatively.

    Pauses are NOT proof that a sentence/scene finished. We explicitly label
    'pause-proposed' vs 'length-estimated'.
    """
    count=len(scenes)
    if not count:
        raise ValueError('No scenes; create a storyboard first')
    if duration<=count*MIN_SCENE:
        raise ValueError('Recording too short for the current number of shots')
    anchors={0:{'time':0.0,'status':'start'}}
    for i in range(1,count):
        sc=scenes[i]
        if sc.get('alignment')=='manual-locked':
            sec=float(sc.get('start',float('nan')))
            if not math.isfinite(sec):
                raise ValueError('Corrupt manual timing')
            anchors[i]={'time':sec,'status':'manual-locked'}
    anchors[count]={'time':duration,'status':'end'}
    fixed=list(sorted(anchors))
    for a,b in zip(fixed,fixed[1:]):
        if anchors[b]['time']-anchors[a]['time']<(b-a)*MIN_SCENE-1e-6:
            raise ValueError('Manual timing conflicts with recording duration; preserving it without changes')
    for a,b in zip(fixed,fixed[1:]):
        start,end=anchors[a]['time'],anchors[b]['time']
        weights=[max(1,len(re.sub(r'\s+','',str(scenes[i].get('text',''))))) for i in range(a,b)]
        total=sum(weights)
        accum=0;prev=start
        for i in range(a+1,b):
            accum+=weights[i-a-1]
            target=start+(end-start)*accum/total
            lo=prev+MIN_SCENE
            hi=end-(b-i)*MIN_SCENE
            # Place an untrusted narration pause near the expected story position;
            # do not pick distant pauses simply because they are conspicuous.
            allowed=[p for p in pauses if lo<=p['time']<=hi and abs(p['time']-target)<=max_snap]
            if allowed:
                p=min(allowed,key=lambda p:(abs(p['time']-target)-min(.6,p.get('seconds',0))*.07, -p.get('seconds',0)))
                t=p['time'];status='pause-proposed'
                note=f"Nearby pause {p['seconds']:.2f}s; expected {target:.2f}s (NOT spoken-text alignment)"
            else:
                t=max(lo,min(hi,target));status='length-estimated'
                note='Estimated by script length; no sufficiently close pause'
            anchors[i]={'time':round(t,3),'status':status,'note':note}
            prev=t
    out=[]
    for i,scene in enumerate(scenes):
        out.append({'sceneId':str(scene.get('id','')),'index':i,'start':round(anchors[i]['time'],3),
                    'end':round(anchors[i+1]['time'],3),'status':anchors[i]['status'],
                    'note':anchors[i].get('note','')})
    return out


def make_plan(project: dict, chapter_no: int, duration: float, pauses: list):
    chapters=project.get('chapters') or []
    if chapter_no<1 or chapter_no>len(chapters):
        raise ValueError(f'Chapter must be between 1 and {len(chapters)}')
    chapter=chapters[chapter_no-1]
    scenes=chapter.get('scenes') or []
    shots=boundaries(scenes,duration,pauses)
    return {'schema':'mmmn.pause-timing.v1','chapterNumber':chapter_no,'chapterId':chapter.get('id',''),
            'duration':round(duration,3),'recordingAnalysis':'ffmpeg-silencedetect; no transcription',
            'humanReviewRequired':True,'pauseCount':len(pauses),'scenes':shots}


def main():
    a=argparse.ArgumentParser(description='Local CPU-only pause-based timing suggestions for MMMN')
    a.add_argument('--project',default='project.json',type=Path)
    a.add_argument('--video',required=True,type=Path,help='A local MP4/MOV with speech audio')
    a.add_argument('--chapter',required=True,type=int)
    a.add_argument('--output',type=Path,help='Default: MMMN-chNN-pause-timing.json in current folder')
    a.add_argument('--threshold',default='-32dB',help='Audio silence threshold e.g. -32dB')
    a.add_argument('--min-pause',type=float,default=.25)
    a.add_argument('--max-snap',type=float,default=4)
    opts=a.parse_args()
    output=opts.output or Path(f'MMMN-ch{opts.chapter:02d}-pause-timing.json')
    if output.exists():
        a.error('Output already exists. Rename it to protect prior manual edits.')
    try:
        if opts.min_pause<.1 or opts.max_snap<0 or opts.max_snap>20:
            raise ValueError('min-pause must be >=0.1; max-snap between 0 and 20')
        with open(opts.project,encoding='utf-8') as f:project=json.load(f)
        dur=run_probe(opts.video)
        pauses=detect_silences(opts.video,dur,opts.threshold,opts.min_pause)
        plan=make_plan(project,opts.chapter,dur,pauses)
        # Manual boundaries must remain unchanged; do not overwrite an existing output.
        output.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        from collections import Counter
        print('LOCAL TIMING PLAN READY:',output.resolve())
        print('Recording:',round(dur,2),'seconds; pauses:',len(pauses),'status counts:',dict(Counter(x['status'] for x in plan['scenes'])))
        print('TIMING IS ONLY A SUGGESTION. Playback review and SRT/script alignment still needed.')
    except (ValueError,OSError,RuntimeError,subprocess.CalledProcessError,json.JSONDecodeError) as err:
        print('ERROR:',err,file=sys.stderr)
        sys.exit(1)

if __name__=='__main__':main()
