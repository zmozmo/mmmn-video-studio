# Python Test Modes — 2026-11-04

ဒီ source တွင် `scripts/run-python-tests.py` ကို ထည့်ထားသည်။ Test module တစ်ခုစီကို Python subprocess အသီးသီးဖြင့် စမ်းပြီး timeout နှင့် JSON report ကို မှတ်တမ်းတင်နိုင်သည်။

## Quick developer checks (NOT a full release proof)

Windows command prompt:

```cmd
py -3 scripts\run-python-tests.py --quick --timeout 35 --report python-quick-report.json
```

`--quick` ဖြင့် `long_chapter_render_test.py` ကို ရည်ရွယ်ချက်ရှိရှိ skip လုပ်သည်။ Quick PASS ကို Full Suite PASS ဟု မဆိုရ။

## Full module checks

```cmd
py -3 scripts\run-python-tests.py --timeout 180 --report python-full-report.json
```

Module timeout/failure ရှိလျှင် nonzero exit code ပြန်ပေးသည်။ FFmpeg integration နှင့် long chapter test တို့ အချိန်ကြာနိုင်သည်။ Windows Installer ကို approve လုပ်ရန် Native Windows EXE/Setup, install→upgrade, backup/restore နှင့် GUI test တို့ကို Windows တွင် အမှန်တကယ် PASS လုပ်ရန် လိုသေးသည်။

`npm.cmd test` (JavaScript), `npm.cmd run test:release` (source contracts), `npm.cmd run verify:installer-ready` (Windows acceptance safety gate) တို့ကို သီးသန့် run ရမည်။ Release gate ပိတ်ထားခြင်းကို bypass မလုပ်ရ။
