@echo off
setlocal
cd /d "%~dp0"
echo [MMMN] Windows portable trial backend tests
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 -m unittest discover -s tests -p "*_test.py" -v
) else (
  python -m unittest discover -s tests -p "*_test.py" -v
)
if errorlevel 1 (echo Tests FAILED. & pause & exit /b 1)
where node.exe >nul 2>&1
if %errorlevel%==0 (
  echo [MMMN] Optional JavaScript tests
  node --test tests\*.test.mjs
  if errorlevel 1 (echo JavaScript tests FAILED. & pause & exit /b 1)
)
echo [MMMN] Tests finished. Native installer tests still required before setup.exe.
pause
endlocal
