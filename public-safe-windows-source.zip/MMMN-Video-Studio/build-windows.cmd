@echo off
setlocal
cd /d "%~dp0"
set "PATH=%PATH%;%USERPROFILE%\.cargo\bin"
echo [MMMN] Windows current-user installer. Updates use the SAME installer identity.
where npm.cmd >nul 2>&1 || (echo ERROR: Node.js LTS not installed. & exit /b 1)
where cargo.exe >nul 2>&1 || (echo ERROR: Rust MSVC toolchain not installed. & exit /b 1)
if not exist src-tauri\resources\bin\ffmpeg.exe (echo ERROR: Offline FFmpeg is missing. Run scripts\prepare-ffmpeg-windows.ps1 with your licensed Windows x64 FFmpeg binary. & exit /b 1)
if not exist src-tauri\resources\bin\FFMPEG-BUILD-INFO.txt (echo ERROR: FFmpeg build/license info missing. & exit /b 1)
if not exist package-lock.json (echo ERROR: package-lock.json required for reproducible Windows release. & exit /b 1)
if not exist src-tauri\Cargo.lock (echo ERROR: Cargo.lock required for reproducible Windows release. & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\verify-bundled-ffmpeg.ps1"
if errorlevel 1 exit /b 1
call npm.cmd ci --no-audit --no-fund
if errorlevel 1 exit /b 1
call npm.cmd run test:release
if errorlevel 1 exit /b 1
REM IMPORTANT: installer build is locked until all independent Windows acceptance checks.
REM v0.13.0 is PREINSTALL SOURCE. Do not bypass this condition to distribute setup.exe.
call npm.cmd run verify:installer-ready
if errorlevel 1 (echo RELEASE BLOCKED: Windows install and in-place upgrade proof are not complete. & exit /b 1)
call npm.cmd test
if errorlevel 1 exit /b 1
call npm.cmd run tauri:build -- --config src-tauri/installer.conf.json --bundles nsis
if errorlevel 1 exit /b 1
echo.
echo Installer available in: src-tauri\target\release\bundle\nsis\
for %%F in (src-tauri\target\release\bundle\nsis\*.exe) do powershell -NoProfile -Command "Get-FileHash -Algorithm SHA256 -LiteralPath '%%F'"
echo First time: install setup.exe. For NEXT releases close the app and run the NEW setup.exe; do not manually uninstall.
explorer "src-tauri\target\release\bundle\nsis"
endlocal
