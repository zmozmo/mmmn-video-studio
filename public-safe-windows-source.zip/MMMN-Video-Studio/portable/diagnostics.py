"""Offline MMMN Windows portable-trial readiness check, no cloud/network access."""
from __future__ import annotations
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from studio_server import Studio, root_dir, WEB


def check():
    print('MMMN Video Studio — Offline Windows Trial Health Check')
    print('='*58)
    issues = []
    root = root_dir()
    root.mkdir(parents=True,exist_ok=True)
    print('Python:', sys.version.split()[0])
    for name in ['index.html','app.js','style.css','resources/starter-project.json']:
        path = WEB/name
        if not path.is_file() or path.stat().st_size == 0:
            issues.append(f'UI file missing: {name}')
    print('UI package:', 'PASS' if not issues else 'INCOMPLETE')
    try:
        with tempfile.NamedTemporaryFile(prefix='.mmmn-write-test-',dir=root,delete=True) as f:
            f.write(b'OK');f.flush()
        print('Local data write:', 'PASS')
    except OSError as error:
        issues.append(f'Cannot write local data folder: {error}')
        print('Local data write: FAIL')
    try:
        total,used,free = shutil.disk_usage(root)
        print('Free storage:', f'{free/(1024**3):.2f} GiB')
        if free < 1*1024**3:print('WARNING: Less than 1 GiB free; long MP4 renders need more space.')
    except OSError as error:
        issues.append(f'Cannot check disk space: {error}')
    try:
        studio=Studio(root,token='diagnostics-only')
        current=studio.load_project_state()
        print('Saved project:', 'VALID' if current else 'NOT CREATED (normal for first run)')
        if not studio.ffmpeg:raise OSError('ffmpeg.exe not found in portable/bin or PATH')
        ffmpeg=Path(studio.ffmpeg)
        if not ffmpeg.is_file():raise OSError(f'FFmpeg not a file: {ffmpeg}')
        result=subprocess.run([str(ffmpeg),'-hide_banner','-encoders'],capture_output=True,text=True,timeout=12)
        if result.returncode or 'libx264' not in result.stdout or 'aac' not in result.stdout:
            raise OSError('FFmpeg does not support libx264 + AAC required for MP4 export')
        probe=Path(studio.ffmpeg).with_name('ffprobe.exe')
        if not probe.is_file():probe=Path(studio.ffmpeg).with_name('ffprobe')
        if not probe.is_file() and not shutil.which('ffprobe'):raise OSError('ffprobe.exe missing; required for narration preflight and final frame verification')
        print('FFmpeg + ffprobe H.264/AAC:', 'PASS')
    except (OSError,ValueError,subprocess.TimeoutExpired) as error:
        issues.append(f'MP4 export prerequisites: {error}')
        print('FFmpeg H.264/AAC: NOT READY')
    # Speech model is optional: never block manual SRT editing or MP4 export.
    try:
        speech=studio.offline_speech_status()
        print('Offline Myanmar SRT:', 'OPTIONAL READY ('+speech['modelName']+')' if speech['ready'] else 'OPTIONAL — model / whisper-cli not installed')
        if not speech['ready']:
            print('  Optional tools folder:', speech['toolsFolder'])
            print('  Optional models folder:', speech['modelsFolder'])
    except (OSError,ValueError) as error:
        print('Offline Myanmar SRT: OPTIONAL, unavailable:',error)
    print('Cloud/Google Drive:', 'NOT USED')
    print('Local data folder:', root)
    if issues:
        print('\nItems to fix:')
        for issue in issues:print('-',issue)
        print('\nWindows MP4 export needs a locally available trusted FFmpeg build.')
        print('Place ffmpeg.exe in portable\\bin or make it available on PATH.')
        return 1
    print('\nREADY for the portable trial. This is NOT a Windows installer validation.')
    return 0


if __name__=='__main__':
    raise SystemExit(check())
