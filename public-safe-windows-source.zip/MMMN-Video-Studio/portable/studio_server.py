"""MMMN Video Studio portable Windows trial. Python stdlib only, loopback-only.

Not an installer: the stable user-data folder survives replacing this source directory.
Does not upload to Google Drive, access the Internet, or modify the manuscript.
"""
from __future__ import annotations

import argparse
import contextlib
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlsplit

RESOURCE_ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
WEB = RESOURCE_ROOT / 'web'
IDENTIFIER = 'com.mmmn.videostudio'
PORT = 8765
MAX_JSON = 16 * 1024 * 1024
MAX_CHUNK = 1024 * 1024
EXTS = {'png','jpg','jpeg','webp','gif','mp4','m4v','mov','webm','mp3','m4a','wav','ogg','aac'}
NARRATION_EXTS = {'mp4', 'mov', 'm4v', 'webm', 'mp3', 'm4a', 'wav', 'ogg', 'aac'}
ID_PATTERN = re.compile(r'^[A-Za-z0-9_-]{6,90}$')
BACKUP_PATTERN = re.compile(r'^snapshot-[0-9]{10,20}-[0-9]{1,15}$')
HEX64 = re.compile(r'^[a-fA-F0-9]{64}$')
EXPORT_NAME = re.compile(r'^(?:chapter-[0-9]{1,4}-[a-zA-Z0-9_-]{8,40}|book-[a-f0-9]{16})\.mp4$')
CHAPTER_EXPORT_NAME = re.compile(r'^chapter-([0-9]{1,4})-[a-zA-Z0-9_-]{8,40}\.mp4$')
LOCK = threading.RLock()


def single_byte_range(header: str | None, size: int):
    """Resolve one HTTP byte range without loading a multi-GB video into RAM.

    None means a full response. Unsupported/multiple/unsatisfiable ranges
    raise ValueError so clients get 416 instead of a misleading 200 download.
    """
    if header is None:
        return None
    if not isinstance(header, str) or size < 0 or not header.startswith('bytes='):
        raise ValueError('Invalid byte range')
    match = re.fullmatch(r'bytes=(\d*)-(\d*)', header)
    if not match or not (match.group(1) or match.group(2)) or size == 0:
        raise ValueError('Unsupported or unsatisfiable byte range')
    first, last = match.groups()
    if not first:  # Suffix range: bytes=-500
        amount = int(last)
        if amount < 1:
            raise ValueError('Invalid suffix range')
        return max(0, size - amount), size - 1
    start = int(first)
    end = min(int(last), size - 1) if last else size - 1
    if start >= size or end < start:
        raise ValueError('Unsatisfiable byte range')
    return start, end

class RenderCancelled(Exception):
    pass



def root_dir():
    override = os.environ.get('MMMN_TRIAL_DATA_DIR')
    if override:
        return Path(override).resolve()
    # Preview data is isolated from future Tauri installation, and stable across updates.
    local = os.environ.get('LOCALAPPDATA')
    return (Path(local) if local else Path.home() / '.local' / 'share') / 'MMMN-Video-Studio-Trial'


class Studio:
    def __init__(self, root: Path, token: str, ffmpeg: str | None = None):
        self.root = root.resolve()
        self.token = token
        # Local-only. Users may place a freely licensed Windows FFmpeg executable
        # in portable/bin; never download or execute unknown software automatically.
        bundled = RESOURCE_ROOT / 'portable' / 'bin' / 'ffmpeg.exe'
        self.ffmpeg = ffmpeg or os.environ.get('MMMN_FFMPEG') or (str(bundled) if bundled.is_file() else shutil.which('ffmpeg'))
        self.root.mkdir(parents=True, exist_ok=True)
        for folder in ('media', 'imports', 'exports', 'snapshots', 'transcripts', 'tools', 'models', 'render-cache'):
            (self.root / folder).mkdir(exist_ok=True)
        self._jobs_lock = threading.RLock()
        self._render_jobs = {}
        self._active_render_job = None
        self.record_upgrade_checkpoint()

    def record_upgrade_checkpoint(self):
        """On each portable package change, preserve verified project metadata.

        This is NOT a full media backup. Original recordings/images remain in
        stable local media storage. The user should also keep an external copy.
        """
        revision_file=RESOURCE_ROOT/'TRIAL-REVISION.txt'
        revision=revision_file.read_text(encoding='utf-8').strip() if revision_file.is_file() else 'legacy'
        if not re.fullmatch(r'[A-Za-z0-9._-]{1,80}',revision):
            raise ValueError('Unsafe trial revision marker')
        tracker=self.root/'trial-revision.json'
        old=json.loads(tracker.read_text(encoding='utf-8')) if tracker.is_file() else {}
        if old.get('revision')==revision:return
        project=self.root/'project-state.json'
        if project.is_file():
            source=project.read_bytes()
            try:self.valid_state(source.decode('utf-8'))
            except (UnicodeDecodeError,ValueError) as e:
                # Use a valid previous copy for the checkpoint. Do not touch
                # the corrupt current bytes; load_project_state can recover.
                previous=self.root/'project-state.previous.json'
                if not previous.is_file():
                    raise ValueError('Existing project is damaged. Upgrade stopped without replacing it: '+str(e))
                source=previous.read_bytes()
                try:self.valid_state(source.decode('utf-8'))
                except (UnicodeDecodeError,ValueError):
                    raise ValueError('Current and previous projects are damaged. No file was overwritten.')
            folder=self.root/'preupgrade-metadata'
            folder.mkdir(exist_ok=True)
            stamp=time.time_ns()
            target=folder/f'preupgrade-{stamp}.json'
            pending=folder/f'preupgrade-{stamp}.pending'
            pending.write_bytes(source)
            if hashlib.sha256(pending.read_bytes()).digest()!=hashlib.sha256(source).digest():
                pending.unlink(missing_ok=True)
                raise ValueError('Preupgrade metadata copy failed verification')
            os.replace(pending,target)
        pending=self.root/'trial-revision.pending'
        pending.write_text(json.dumps({'revision':revision,'previousRevision':old.get('revision'),
                        'checkedAt':int(time.time()),'metadataOnly':True}),encoding='utf-8')
        os.replace(pending,tracker)

    @staticmethod
    def media_id(value):
        if not isinstance(value, str) or not ID_PATTERN.fullmatch(value):
            raise ValueError('Invalid media ID')
        return value

    @staticmethod
    def ext(value):
        if not isinstance(value, str) or value not in EXTS:
            raise ValueError('Unsupported media extension')
        return value

    def media(self, mid, ext):
        return self.root / 'media' / f'{self.media_id(mid)}.{self.ext(ext)}'

    @staticmethod
    def checksum(path: Path):
        h = hashlib.sha256()
        size = 0
        with path.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                size += len(chunk)
                h.update(chunk)
        return size, h.hexdigest()

    @staticmethod
    def valid_state(raw):
        if not isinstance(raw, str) or len(raw.encode('utf-8')) > MAX_JSON:
            raise ValueError('Project JSON is missing or too large')
        obj = json.loads(raw)
        if not isinstance(obj, dict) or not isinstance(obj.get('chapters'), list) or not isinstance(obj.get('assets'), list):
            raise ValueError('Project must contain chapters and assets arrays')
        return obj

    def load_project_state(self, **_):
        for name in ('project-state.json', 'project-state.previous.json', 'project-state.older.json', 'project-state.preupgrade.json'):
            path = self.root / name
            if path.is_file():
                try:
                    data = path.read_text(encoding='utf-8')
                    self.valid_state(data)
                    return data
                except (OSError, ValueError, json.JSONDecodeError):
                    pass
        if any((self.root / n).exists() for n in ('project-state.json', 'project-state.previous.json')):
            raise ValueError('Saved project and recovery copy are both damaged. Nothing was overwritten.')
        return None

    def save_project_state(self, json: str, **_):
        self.valid_state(json)
        path = self.root / 'project-state.json'
        stage = self.root / 'project-state.pending.json'
        stage.write_text(json, encoding='utf-8')
        with stage.open('rb') as f:
            os.fsync(f.fileno())
        if path.is_file():
            try:
                self.valid_state(path.read_text(encoding='utf-8'))
            except (ValueError, OSError):
                backup_path = self.root / 'project-state.previous.json'
                if not backup_path.is_file():
                    raise ValueError('Damaged project; no verified recovery copy. Save stopped without overwriting.')
                self.valid_state(backup_path.read_text(encoding='utf-8'))
                damaged = self.root / f'project-state.corrupt-{int(time.time()*1000)}.json'
                path.rename(damaged)
                shutil.copy2(backup_path,path)
            backup = self.root / 'project-state.previous.json'
            older = self.root / 'project-state.older.json'
            if backup.is_file():
                shutil.copy2(backup, older)
            shutil.copy2(path, backup)
        os.replace(stage, path)
        return None

    def project_storage_info(self, **_):
        return {'path':str(self.root),'projectFile':'project-state.json',
                'hasProject':(self.root/'project-state.json').is_file(),
                'hasRecovery':(self.root/'project-state.previous.json').is_file(),
                'hasPreupgradeBackup':any((self.root/'preupgrade-metadata').glob('preupgrade-*.json'))
                    if (self.root/'preupgrade-metadata').is_dir() else False,
                'storage':'windows-portable-trial-local-only'}

    def begin_media_import(self, id: str, ext: str, total: int, **_):
        self.media_id(id);self.ext(ext)
        if not isinstance(total,int) or not (0 < total <= 100*1024**3):
            raise ValueError('Media must be 1 byte to 100 GB')
        if self.media(id,ext).exists():
            raise ValueError('Media ID is already in use')
        partial = self.root / 'imports' / f'{id}.partial'
        metadata = self.root / 'imports' / f'{id}.json'
        with partial.open('xb'):
            pass
        try:
            with metadata.open('x',encoding='utf-8') as f:
                json.dump({'ext':ext,'total':total},f)
        except Exception:
            partial.unlink(missing_ok=True)
            raise
        return None

    def import_media_chunk(self, id, offset, sha256, data):
        self.media_id(id)
        if not data or len(data)>MAX_CHUNK or not isinstance(offset,int) or offset<0:
            raise ValueError('Invalid chunk size or offset')
        if not isinstance(sha256,str) or not HEX64.fullmatch(sha256) or hashlib.sha256(data).hexdigest()!=sha256.lower():
            raise ValueError('Media chunk checksum mismatch; nothing written')
        meta = json.loads((self.root/'imports'/f'{id}.json').read_text())
        if offset+len(data)>meta['total']:
            raise ValueError('Chunk exceeds declared total')
        part = self.root/'imports'/f'{id}.partial'
        with part.open('r+b') as f:
            f.seek(0,2)
            if f.tell()!=offset:raise ValueError('Out of order chunk')
            f.write(data)
        return offset+len(data)

    def finalize_media_import(self, id: str, **_):
        self.media_id(id)
        metadata=self.root/'imports'/f'{id}.json'
        meta=json.loads(metadata.read_text())
        target=self.media(id,meta['ext'])
        part=self.root/'imports'/f'{id}.partial'
        size, sha=self.checksum(part)
        if size!=meta['total']:raise ValueError(f'Incomplete import {size}/{meta["total"]}')
        if target.exists():raise ValueError('Media ID collision; original preserved')
        with part.open('rb') as handle: os.fsync(handle.fileno())
        os.replace(part,target)
        metadata.unlink()
        return {'path':self.url(id,meta['ext']),'id':id,'ext':meta['ext'],'size':size,'sha256':sha}

    def abort_media_import(self,id:str,**_):
        self.media_id(id)
        (self.root/'imports'/f'{id}.partial').unlink(missing_ok=True)
        (self.root/'imports'/f'{id}.json').unlink(missing_ok=True)
        return None

    def url(self,mid,ext):
        self.media_id(mid);self.ext(ext)
        return f'/__media/{mid}.{ext}?token={self.token}'

    def get_media_info(self,id:str,ext:str,**_):
        path=self.media(id,ext)
        if not path.is_file() or path.is_symlink():return None
        return {'path':self.url(id,ext),'size':path.stat().st_size}

    def verify_native_media(self,id:str,ext:str,expectedSha256:str,**_):
        path=self.media(id,ext)
        if not isinstance(expectedSha256,str) or not HEX64.fullmatch(expectedSha256):raise ValueError('Invalid checksum')
        if path.is_symlink():raise ValueError('Media symlink refused')
        size,actual=self.checksum(path)
        if actual!=expectedSha256.lower():raise ValueError('Media SHA-256 mismatch; restore verified backup')
        return {'id':id,'ext':ext,'size':size,'sha256':actual,'verified':True,'path':self.url(id,ext)}

    def declared_media(self, project):
        expected={}
        for a in project.get('assets',[]):
            if not a.get('nativeStored') and not (a.get('localStored') and not a.get('bundledUrl')):
                continue
            mid=self.media_id(a['id'])
            ext=self.ext(a['name'].rsplit('.',1)[-1].lower())
            if mid in expected:raise ValueError('Duplicate media ID in project')
            expected[mid]=ext
        if len(expected)>10000:raise ValueError('Too many media files')
        return expected

    def inspect_snapshot(self, folder):
        if not folder.is_dir() or folder.is_symlink():raise ValueError('Snapshot folder missing or unsafe')
        project_file=folder/'project-state.json'
        manifest_file=folder/'manifest.json'
        if project_file.is_symlink() or manifest_file.is_symlink():
            raise ValueError('Snapshot metadata symlink disallowed')
        data=project_file.read_bytes()
        project=self.valid_state(data.decode('utf-8'))
        manifest=json.loads(manifest_file.read_text(encoding='utf-8'))
        if manifest.get('format')!='mmmn-local-snapshot-v1' or manifest.get('stateSha256')!=hashlib.sha256(data).hexdigest():
            raise ValueError('Project checksum or snapshot format invalid')
        want=self.declared_media(project)
        entries=manifest.get('media',[])
        if len(entries)!=len(want):raise ValueError('Media list incomplete')
        total=0; seen=set()
        for entry in entries:
            mid=self.media_id(entry['id']);ext=self.ext(entry['ext'])
            if mid in seen or want.get(mid)!=ext:raise ValueError('Unexpected media in snapshot')
            seen.add(mid)
            p=folder/'media'/f'{mid}.{ext}'
            if p.is_symlink():raise ValueError('Media symlink disallowed')
            size,digest=self.checksum(p)
            if size!=entry['bytes'] or digest!=entry['sha256']:raise ValueError('Media checksum mismatch')
            total+=size
        return manifest,project,total

    def create_full_local_backup(self,**_):
        original=self.root/'project-state.json'
        if original.is_symlink():raise ValueError('Project metadata symlink disallowed')
        if not original.is_file():raise ValueError('Save a project first')
        data=original.read_bytes()
        project=self.valid_state(data.decode('utf-8'))
        midmap=self.declared_media(project)
        # Fail before copying multi-GB recordings if there is insufficient disk space.
        requested = sum(self.media(mid, ext).stat().st_size for mid,ext in midmap.items())
        if shutil.disk_usage(self.root).free < requested + 64*1024*1024:
            raise ValueError('Not enough free disk space for a complete local backup. Select another drive for your recovery copy.')
        sid=f'snapshot-{time.time_ns()}-{os.getpid()}'
        dest=self.root/'snapshots'/sid
        partial=self.root/'snapshots'/(sid+'.partial')
        partial.mkdir(exist_ok=False)
        try:
            (partial/'media').mkdir()
            media=[];total=0
            for mid,ext in sorted(midmap.items()):
                p=self.media(mid,ext)
                if p.is_symlink():raise ValueError('Source media symlink not allowed')
                destfile=partial/'media'/f'{mid}.{ext}'
                shutil.copyfile(p,destfile)
                size,digest=self.checksum(destfile)
                if not size:raise ValueError('Empty media')
                total+=size
                media.append({'id':mid,'ext':ext,'bytes':size,'sha256':digest})
            (partial/'project-state.json').write_bytes(data)
            (partial/'manifest.json').write_text(json.dumps({'format':'mmmn-local-snapshot-v1','appVersion':'portable-trial',
                     'stateSha256':hashlib.sha256(data).hexdigest(),'media':media},indent=2),encoding='utf-8')
            self.inspect_snapshot(partial)
            partial.rename(dest)
            return {'id':sid,'path':str(dest),'files':len(media),'bytes':total,'verified':True}
        except BaseException:
            shutil.rmtree(partial,ignore_errors=True)
            raise

    def list_local_backups(self,**_):
        return [{'id':p.name,'path':str(p)} for p in sorted((self.root/'snapshots').iterdir(),reverse=True)
                if p.is_dir() and BACKUP_PATTERN.fullmatch(p.name)]

    def verify_local_backup(self,id:str,**_):
        if not isinstance(id,str) or not BACKUP_PATTERN.fullmatch(id):raise ValueError('Invalid snapshot ID')
        manifest,_,bytes_=self.inspect_snapshot(self.root/'snapshots'/id)
        return {'id':id,'verified':True,'files':len(manifest['media']),'bytes':bytes_,'appVersion':manifest['appVersion']}

    def restore_local_backup(self,id:str,**_):
        if not isinstance(id,str) or not BACKUP_PATTERN.fullmatch(id):raise ValueError('Invalid snapshot ID')
        source=self.root/'snapshots'/id
        manifest,project,_=self.inspect_snapshot(source)
        estimated=sum(e['bytes'] for e in manifest['media'])
        if shutil.disk_usage(self.root).free < 2*estimated + 64*1024*1024:
            raise ValueError('Not enough disk space to preserve current project and restore backup safely')
        before=self.create_full_local_backup() if (self.root/'project-state.json').is_file() else None
        # A millisecond timestamp alone can collide during repeated or automated
        # restores. Never overwrite media already referenced by another project.
        # Keep each restore operation's media IDs unpredictable and unique.
        stamp=f'{int(time.time()*1000)}-{secrets.token_hex(8)}'
        mapping={};created=[]
        try:
            for i,entry in enumerate(manifest['media']):
                newid=f'restore-{stamp}-{i}'
                outfile=self.media(newid,entry['ext'])
                # Exclusive create is intentional: copyfile() overwrites existing
                # paths, which could corrupt a previous verified restoration.
                with (source/'media'/f'{entry["id"]}.{entry["ext"]}').open('rb') as reader, outfile.open('xb') as writer:
                    shutil.copyfileobj(reader,writer,length=1024*1024)
                    writer.flush()
                    os.fsync(writer.fileno())
                created.append(outfile)
                size,digest=self.checksum(outfile)
                if size!=entry['bytes'] or digest!=entry['sha256']:raise ValueError('Restored media failed checksum')
                mapping[entry['id']]=newid
            def remap(obj):
                if isinstance(obj,list):return [remap(v) for v in obj]
                if isinstance(obj,dict):return {k:(mapping[v] if k in ('id','assetId','videoAssetId','audioAssetId') and isinstance(v,str) and v in mapping else remap(v)) for k,v in obj.items()}
                return obj
            project=remap(project)
            new_state=json.dumps(project,ensure_ascii=False,separators=(',',':'))
            self.save_project_state(new_state)
            return {'restored':True,'media':len(manifest['media']),'beforeSnapshot':before['id'] if before else None,'project':new_state}
        except Exception:
            # Metadata may have committed, so never delete copied files in error path.
            raise

    def analyze_narration_pauses(self,chapterNumber:int,chapterId:str,sourceVideoId:str,
                                 sourceVideoExt:str,recordedSeconds:float,scenes:list,**_):
        """No cloud, no speech transcript. Return an unapproved timing proposal."""
        import importlib.util
        import math
        if not self.ffmpeg or not Path(self.ffmpeg).is_file():
            raise ValueError('Offline FFmpeg missing; pause analysis cancelled')
        if not isinstance(chapterNumber,int) or not 1<=chapterNumber<=1000:
            raise ValueError('Invalid chapter number')
        if not isinstance(chapterId,str) or not 1<=len(chapterId)<=120:
            raise ValueError('Invalid chapter ID')
        if sourceVideoExt not in NARRATION_EXTS:
            raise ValueError('Unsupported narrator recording extension')
        if not isinstance(scenes,list) or not 1<=len(scenes)<=1000:
            raise ValueError('No scenes for offline analysis')
        if not isinstance(recordedSeconds,(int,float)) or not math.isfinite(recordedSeconds) or not .5<=recordedSeconds<=43200:
            raise ValueError('Invalid narrator video length')
        file=self.media(sourceVideoId,sourceVideoExt)
        if not file.is_file() or file.is_symlink():raise ValueError('Narrator recording missing on device')
        for index,scene in enumerate(scenes):
            if not isinstance(scene,dict) or not isinstance(scene.get('id'),str) or len(scene['id'])>120:
                raise ValueError(f'Scene {index+1} is missing a valid ID')
        cmd=[self.ffmpeg,'-nostdin','-hide_banner','-i',str(file),'-vn',
             '-af','silencedetect=noise=-32dB:d=0.25','-f','null','-']
        result=subprocess.run(cmd,capture_output=True,text=True,timeout=3600)
        if result.returncode:
            raise ValueError('Audio pause analysis failed (is the recording muted?): '+result.stderr[-800:])
        if 'Audio:' not in result.stderr:
            raise ValueError('Narrator video has no audio stream')
        # Reuse the exact offline alignment algorithm shipped with the CLI tool.
        module_path=RESOURCE_ROOT/'renderer'/'align_pauses.py'
        spec=importlib.util.spec_from_file_location('mmmn_align_pauses_local',module_path)
        engine=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(engine)
        pauses=engine.parse_silences(result.stderr,recordedSeconds)
        proposals=engine.boundaries(scenes,recordedSeconds,pauses)
        return {'schema':'mmmn.pause-timing.v1','chapterNumber':chapterNumber,
                'chapterId':chapterId,'duration':round(recordedSeconds,3),
                'recordingAnalysis':'ffmpeg-silencedetect; no speech recognition',
                'humanReviewRequired':True,'pauseCount':len(pauses),'scenes':proposals}

    def offline_speech_status(self, **_):
        """User-supplied whisper.cpp and multilingual model; never downloads files."""
        tools = self.root / 'tools'
        models = self.root / 'models'
        bundled = RESOURCE_ROOT / 'portable' / 'bin'
        executable = next((p for p in (
            tools / 'whisper-cli.exe', tools / 'whisper-cli',
            bundled / 'whisper-cli.exe', bundled / 'whisper-cli'
        ) if p.is_file() and not p.is_symlink()), None)
        if executable is None:
            exe = shutil.which('whisper-cli') or shutil.which('whisper-cli.exe')
            executable = Path(exe) if exe else None
        supported = [p for p in models.glob('*.bin')
                     if p.is_file() and not p.is_symlink()
                     and not p.name.lower().endswith('.en.bin') and p.stat().st_size > 1024]
        # Smaller default for 16 GB / CPU machines; user may replace with another model.
        preferred = ('ggml-base.bin', 'ggml-small.bin', 'ggml-tiny.bin',
                     'ggml-medium.bin', 'ggml-large-v3-turbo.bin')
        supported.sort(key=lambda p:(preferred.index(p.name.lower()) if p.name.lower() in preferred else 99,p.name))
        model = supported[0] if supported else None
        problems = []
        if not self.ffmpeg or not Path(self.ffmpeg).is_file():
            problems.append('Offline FFmpeg missing')
        if not executable:
            problems.append('Place whisper-cli.exe in '+str(tools))
        if not model:
            problems.append('Place a multilingual ggml-*.bin model in '+str(models)+' (not *.en.bin)')
        return {'ready':not problems, 'problems':problems,
                'toolsFolder':str(tools),'modelsFolder':str(models),
                'modelName':model.name if model else None,
                'engine':'whisper.cpp optional, entirely offline; Burmese transcript requires manual review'}

    def transcribe_narration(self, chapterNumber:int, sourceVideoId:str,
                             sourceVideoExt:str, **_):
        """One chapter at a time, local-only SRT; original video and manuscript untouched."""
        if not isinstance(chapterNumber,int) or not 1 <= chapterNumber <= 1000:
            raise ValueError('Invalid chapter number')
        if sourceVideoExt not in NARRATION_EXTS:
            raise ValueError('Unsupported narration recording extension')
        video = self.media(sourceVideoId,sourceVideoExt)
        if not video.is_file() or video.is_symlink():
            raise ValueError('Narration video missing' if sourceVideoExt in {'mp4','mov','m4v','webm'} else 'Narration audio missing')
        status=self.offline_speech_status()
        if not status['ready']:
            raise ValueError('Offline transcription not ready: '+'; '.join(status['problems']))
        tools=self.root/'tools'
        exe = next((p for p in (tools/'whisper-cli.exe',tools/'whisper-cli',
                   RESOURCE_ROOT/'portable'/'bin'/'whisper-cli.exe',
                   RESOURCE_ROOT/'portable'/'bin'/'whisper-cli')
                   if p.is_file() and not p.is_symlink()), None)
        if exe is None:
            exe=Path(shutil.which('whisper-cli') or shutil.which('whisper-cli.exe'))
        models=[p for p in (self.root/'models').glob('*.bin')
                if p.is_file() and not p.is_symlink() and p.stat().st_size>1024
                and not p.name.lower().endswith('.en.bin')]
        preference=('ggml-base.bin','ggml-small.bin','ggml-tiny.bin','ggml-medium.bin','ggml-large-v3-turbo.bin')
        models.sort(key=lambda p:(preference.index(p.name.lower()) if p.name.lower() in preference else 99,p.name))
        model=models[0]
        from tempfile import TemporaryDirectory
        with TemporaryDirectory(prefix='transcribe-',dir=self.root/'transcripts') as working:
            working=Path(working)
            wav=working/'speech.wav'
            audio_cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                       '-i',str(video),'-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',str(wav)]
            try:
                audio=subprocess.run(audio_cmd,capture_output=True,text=True,timeout=7200)
            except subprocess.TimeoutExpired as e:
                raise ValueError('Audio extraction timed out') from e
            if audio.returncode or not wav.is_file() or wav.stat().st_size<44:
                raise ValueError('Audio extraction failed: '+audio.stderr[-500:])
            basename=working/'captions'
            cmd=[str(exe),'-m',str(model),'-f',str(wav),'-l','my','-t','4',
                 '-ng','-osrt','-of',str(basename)]
            try:
                done=subprocess.run(cmd,capture_output=True,text=True,timeout=24*3600)
            except subprocess.TimeoutExpired as e:
                raise ValueError('Offline speech recognition timed out') from e
            generated=working/'captions.srt'
            if done.returncode or not generated.is_file():
                raise ValueError('whisper.cpp transcription failed: '+done.stderr[-600:])
            text=generated.read_text(encoding='utf-8-sig')
            if len(text.encode('utf-8'))>MAX_JSON or not re.search(
                r'\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[,.]\d{3}',text):
                raise ValueError('Speech recognition did not return valid SRT timestamps')
            destination=self.root/'transcripts'/f'chapter-{chapterNumber}-{secrets.token_hex(6)}.srt'
            # Never overwrite an earlier corrected transcript.
            destination.write_text(text,encoding='utf-8')
            return {'srt':text,'file':destination.name,'modelName':model.name,
                    'humanReviewRequired':True,'source':'local whisper.cpp multilingual'}

    def start_render_job(self, **request):
        """Start exactly one offline render without blocking the app interface."""
        if not isinstance(request.get('scenes'),list) or not 1<=len(request['scenes'])<=1000:
            raise ValueError('Render needs between 1 and 1000 scenes')
        with self._jobs_lock:
            if self._active_render_job:
                active=self._render_jobs.get(self._active_render_job)
                if active and active['status'] in ('queued','running','cancelling'):
                    raise ValueError('A render is already running. Cancel or finish it first.')
            job_id='render-'+secrets.token_hex(12)
            cancel=threading.Event()
            entry={'id':job_id,'status':'queued','phase':'Queued for local encoding',
                   'completed':0,'total':max(1,3*len(request['scenes'])+3),
                   'percent':0,'output':None,'error':None,'_cancel':cancel}
            self._render_jobs[job_id]=entry
            self._active_render_job=job_id
            # Keep recent completed entries for status checks, but not forever.
            for old in list(self._render_jobs)[:-12]:
                if old!=job_id and self._render_jobs[old]['status'] in ('complete','failed','cancelled'):
                    self._render_jobs.pop(old,None)
        def task():
            def progress(phase,completed,total):
                with self._jobs_lock:
                    entry.update(status='running',phase=phase,
                         completed=completed,total=total,
                         percent=min(99,round(completed/max(1,total)*100)))
            try:
                progress('Preparing local media',0,entry['total'])
                result=self.render_chapter_command(**request,_progress=progress,_cancel=cancel)
                with self._jobs_lock:
                    if cancel.is_set():
                        entry.update(status='cancelled',phase='Cancelled',output=None)
                    else:
                        entry.update(status='complete',phase='MP4 verified and saved',
                                     completed=entry['total'],percent=100,output=result)
            except RenderCancelled:
                with self._jobs_lock:entry.update(status='cancelled',phase='Cancelled; source media unchanged')
            except Exception as exc:
                with self._jobs_lock:entry.update(status='failed',phase='Render failed safely',error=str(exc)[:1000])
            finally:
                with self._jobs_lock:
                    if self._active_render_job==job_id:self._active_render_job=None
        threading.Thread(target=task,name='mmmn-render-'+job_id,daemon=True).start()
        return self.get_render_job_status(id=job_id)

    def current_render_job(self,**_):
        with self._jobs_lock:
            active=self._active_render_job
        return self.get_render_job_status(id=active) if active else None

    def get_render_job_status(self,id:str,**_):
        if not isinstance(id,str) or not re.fullmatch(r'render-[a-f0-9]{24}',id):
            raise ValueError('Invalid render job ID')
        with self._jobs_lock:
            entry=self._render_jobs.get(id)
            if not entry:raise ValueError('Unknown render job; previous run may have closed')
            return {k:v for k,v in entry.items() if not k.startswith('_')}

    def cancel_render_job(self,id:str,**_):
        with self._jobs_lock:
            entry=self._render_jobs.get(id)
            if not entry:raise ValueError('Unknown render job')
            if entry['status'] in ('queued','running','cancelling'):
                entry['_cancel'].set()
                entry['status']='cancelling'
                entry['phase']='Stopping FFmpeg safely'
        return self.get_render_job_status(id=id)

    def _book_join(self, filenames, *, _progress=None, _cancel=None):
        """Concatenate completed chapter exports without modifying them.

        No re-encoding is attempted: incompatible dimensions, FPS or codecs are
        rejected instead of silently producing a corrupted long-form MP4.
        """
        import math
        import tempfile
        if not isinstance(filenames,list) or not 2<=len(filenames)<=100:
            raise ValueError('Choose between 2 and 100 chapter MP4 files')
        chapters=[];paths=[]
        for name in filenames:
            match=CHAPTER_EXPORT_NAME.fullmatch(name) if isinstance(name,str) else None
            if not match:raise ValueError('Only local chapter exports may be joined')
            chapter=int(match.group(1))
            if chapter in chapters:raise ValueError('Choose only one export per chapter')
            chapters.append(chapter)
            path=self.root/'exports'/name
            if not path.is_file() or path.is_symlink() or path.stat().st_size<1024:
                raise ValueError('Chapter MP4 missing, unsafe or empty: '+name)
            paths.append(path)
        if chapters!=sorted(chapters):
            raise ValueError('Select chapters in ascending order (1, 2, 3, …)')
        if not self.ffmpeg or not Path(self.ffmpeg).is_file():
            raise ValueError('Offline FFmpeg required for full-book MP4')
        probe=str(Path(self.ffmpeg).with_name('ffprobe.exe'))
        if not Path(probe).is_file():
            probe=shutil.which('ffprobe') or str(Path(self.ffmpeg).with_name('ffprobe'))
        if not Path(probe).is_file():raise ValueError('FFprobe required for validating chapter video files')
        def check_cancel():
            if _cancel is not None and _cancel.is_set():raise RenderCancelled('Book merge cancelled')
        def report(phase,count):
            if _progress:_progress(phase,count,len(paths)+2)
        signature=None;durations=[];frame_counts=[]
        for i,path in enumerate(paths):
            check_cancel()
            outcome=subprocess.run([probe,'-v','error','-count_frames','-show_entries',
                  'stream=codec_type,codec_name,width,height,r_frame_rate,nb_read_frames:format=duration',
                  '-of','json',str(path)],capture_output=True,text=True,timeout=300)
            if outcome.returncode:raise ValueError('Cannot read chapter MP4: '+path.name)
            info=json.loads(outcome.stdout)
            streams={v.get('codec_type'):v for v in info.get('streams',[])}
            v=streams.get('video',{});a=streams.get('audio',{})
            sig=(v.get('codec_name'),v.get('width'),v.get('height'),v.get('r_frame_rate'),a.get('codec_name'))
            if sig[0]!='h264' or sig[4]!='aac' or not sig[1] or not sig[2] or sig[3] not in ('30/1','30'):
                raise ValueError('A chapter export is not compatible H.264 / AAC / 30 fps: '+path.name)
            if signature is None:signature=sig
            if sig!=signature:raise ValueError('Chapter exports must use the same resolution, FPS and codecs. Re-export with one preset.')
            duration=float(info.get('format',{}).get('duration') or 0)
            frames=int(v.get('nb_read_frames') or 0)
            if not math.isfinite(duration) or duration<=0 or frames<10:
                raise ValueError('Incomplete chapter MP4: '+path.name)
            durations.append(duration);frame_counts.append(frames)
            report(f'Checking chapter {chapters[i]} ({i+1}/{len(paths)})',i+1)
        total=sum(durations)
        estimated=sum(p.stat().st_size for p in paths)
        # Concatenation generally creates a similarly sized new file. Never
        # start a long process when disk space is clearly insufficient.
        if shutil.disk_usage(self.root).free < estimated+64*1024*1024:
            raise ValueError('Insufficient free storage for the combined full-book MP4')
        with tempfile.TemporaryDirectory(prefix='book-merge-',dir=self.root/'exports') as temp:
            stage=Path(temp)
            # The list contains only generated, validated filenames; stage the
            # manifest beside the source files so concat has no arbitrary paths.
            listing=stage/'chapters.ffconcat'
            def quote_path(path):
                return str(path).replace(chr(92),'/').replace(chr(39), chr(39)+chr(92)+chr(39)+chr(39))
            listing.write_text('ffconcat version 1.0\n'+''.join(f"file '{quote_path(p)}'\n" for p in paths),encoding='utf-8')
            pending=stage/'book.partial.mp4'
            cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                 '-f','concat','-safe','0','-i',str(listing),'-map','0:v:0','-map','0:a:0',
                 '-c','copy','-movflags','+faststart',str(pending)]
            check_cancel()
            with subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) as proc:
                while True:
                    try:
                        stdout,stderr=proc.communicate(timeout=.5)
                        break
                    except subprocess.TimeoutExpired:
                        if _cancel is not None and _cancel.is_set():
                            proc.terminate()
                            try:proc.communicate(timeout=3)
                            except subprocess.TimeoutExpired:proc.kill();proc.communicate()
                            raise RenderCancelled('Book merge cancelled')
                if proc.returncode or not pending.is_file() or pending.stat().st_size<1024:
                    raise ValueError('Joining chapter MP4 files failed: '+stderr[-800:])
            report('Checking complete book MP4',len(paths)+1)
            check_cancel()
            outcome=subprocess.run([probe,'-v','error','-count_frames','-show_entries',
              'stream=codec_type,codec_name,nb_read_frames:format=duration','-of','json',str(pending)],
              capture_output=True,text=True,timeout=600)
            if outcome.returncode:raise ValueError('Full-book MP4 failed verification')
            info=json.loads(outcome.stdout)
            streams={v.get('codec_type'):v for v in info.get('streams',[])}
            frames=int(streams.get('video',{}).get('nb_read_frames') or 0)
            duration=float(info.get('format',{}).get('duration') or 0)
            # Validate frames and duration independently: a playable header
            # does not mean the video contains all chapter pictures.
            if streams.get('video',{}).get('codec_name')!='h264' or streams.get('audio',{}).get('codec_name')!='aac' \
                  or frames!=sum(frame_counts) or abs(duration-total)>max(.35,len(paths)*.08):
                raise ValueError(f'Full-book MP4 incomplete: frames {frames}/{sum(frame_counts)}, time {duration:.3f}/{total:.3f}')
            check_cancel()
            destination=self.root/'exports'/f'book-{secrets.token_hex(8)}.mp4'
            os.replace(pending,destination)
            report('Verified full-book MP4 saved locally',len(paths)+2)
            return str(destination)

    def start_book_merge_job(self,filenames:list,**_):
        """Queue a cancelable, verification-first offline full-book export."""
        if not isinstance(filenames,list) or not 2<=len(filenames)<=100:
            raise ValueError('Choose 2–100 chapters first')
        with self._jobs_lock:
            active=self._render_jobs.get(self._active_render_job) if self._active_render_job else None
            if active and active['status'] in ('queued','running','cancelling'):
                raise ValueError('Another export is already running')
            jid='render-'+secrets.token_hex(12)
            cancel=threading.Event()
            entry={'id':jid,'status':'queued','phase':'Queued full-book merge','completed':0,
                   'total':len(filenames)+2,'percent':0,'output':None,'error':None,'_cancel':cancel}
            self._render_jobs[jid]=entry
            self._active_render_job=jid
        def progress(phase,done,total):
            with self._jobs_lock:
                entry.update(status='running',phase=phase,completed=done,total=total,
                             percent=min(99,round(done/max(1,total)*100)))
        def task():
            try:
                output=self._book_join(filenames,_progress=progress,_cancel=cancel)
                with self._jobs_lock:
                    entry.update(status='complete',phase='Verified full-book MP4 ready',
                                 completed=entry['total'],percent=100,output=output)
            except RenderCancelled:
                with self._jobs_lock:entry.update(status='cancelled',phase='Full-book merge cancelled')
            except Exception as exc:
                with self._jobs_lock:entry.update(status='failed',phase='Full-book merge failed safely',error=str(exc)[:1000])
            finally:
                with self._jobs_lock:
                    if self._active_render_job==jid:self._active_render_job=None
        threading.Thread(target=task,name='mmmn-book-merge',daemon=True).start()
        return self.get_render_job_status(id=jid)

    def list_local_exports(self,**_):
        files=[]
        for item in (self.root/'exports').iterdir():
            if not EXPORT_NAME.fullmatch(item.name) or not item.is_file() or item.is_symlink():
                continue
            files.append({'name':item.name,'size':item.stat().st_size,
                          'url':f'/__exports/{item.name}?token={self.token}'})
        return sorted(files,key=lambda x:x['name'],reverse=True)[:100]

    # Segment-first export: the old FFconcat-of-still-images approach could silently
    # produce a 4-second MP4 containing only ONE video frame. Never use that path.
    RENDER_DIMENSIONS = {'youtube':(1920,1080), 'tiktok':(1080,1920),
                         'facebook':(1080,1350), 'square':(1080,1080)}
    RENDER_FPS = 30

    # Cache only reproducible ENCODED VIDEO SCENES, never narration source,
    # user images, approved timelines, or completed MP4 exports. The cache is
    # an optimization, not part of the project or any recovery snapshot.
    RENDER_CACHE_LIMIT_BYTES = 2 * 1024**3
    RENDER_CACHE_FORMAT = 'mmmn-scene-h264-v1'

    def scene_cache_key(self, image: Path, *, motion: str, frames: int, width: int, height: int):
        size, digest = self.checksum(image)
        parameters = {'format':self.RENDER_CACHE_FORMAT,'imageSha256':digest,
                      'imageBytes':size,'motion':motion,'frames':frames,
                      'width':width,'height':height,'fps':self.RENDER_FPS,
                      'encoder':'libx264-veryfast-crf23-yuv420p'}
        serialized = json.dumps(parameters, sort_keys=True, separators=(',',':'))
        key = hashlib.sha256(serialized.encode('utf-8')).hexdigest()
        return key, parameters

    def cached_scene_to_stage(self, key: str, stage_path: Path, parameters: dict) -> bool:
        folder = self.root/'render-cache'
        cached, manifest = folder/f'scene-{key}.mp4', folder/f'scene-{key}.json'
        if not cached.is_file() or cached.is_symlink() or not manifest.is_file() or manifest.is_symlink():
            return False
        try:
            record = json.loads(manifest.read_text(encoding='utf-8'))
            size, checksum = self.checksum(cached)
            if (record.get('parameters') != parameters or record.get('bytes') != size
                    or record.get('sha256') != checksum or size < 256):
                return False
            # Both paths are on the app-local filesystem. Hardlinks reuse frames
            # without copying multi-GB movie segments; copy if unavailable.
            try: os.link(cached,stage_path)
            except OSError: shutil.copyfile(cached,stage_path)
            os.utime(cached,None)
            return True
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return False

    def save_scene_cache(self, key: str, stage_path: Path, parameters: dict):
        folder = self.root/'render-cache'
        # Failure to cache must never fail an otherwise valid MP4 export.
        temporary = folder/f'scene-{key}.{secrets.token_hex(6)}.pending'
        temporary_json = folder/f'scene-{key}.{secrets.token_hex(6)}.pending-json'
        cached, manifest = folder/f'scene-{key}.mp4',folder/f'scene-{key}.json'
        try:
            size, checksum = self.checksum(stage_path)
            if size < 256 or size > self.RENDER_CACHE_LIMIT_BYTES:
                return
            try: os.link(stage_path,temporary)
            except OSError: shutil.copyfile(stage_path,temporary)
            temporary_json.write_text(json.dumps({'parameters':parameters,'bytes':size,
                                 'sha256':checksum},separators=(',',':')),encoding='utf-8')
            # Publish video then metadata; a crash between them results in a
            # harmless cache miss, never use of unverified frames.
            os.replace(temporary,cached)
            os.replace(temporary_json,manifest)
            self.trim_render_cache()
        except OSError:
            pass
        finally:
            temporary.unlink(missing_ok=True)
            temporary_json.unlink(missing_ok=True)

    def trim_render_cache(self):
        folder = self.root/'render-cache'
        files = []
        for file in folder.glob('scene-*.mp4'):
            if file.is_symlink() or not re.fullmatch(r'scene-[0-9a-f]{64}\.mp4',file.name):
                continue
            try:
                stat=file.stat()
                files.append((stat.st_mtime, stat.st_size, file))
            except OSError:continue
        total = sum(item[1] for item in files)
        for _,size,path in sorted(files):
            if total<=self.RENDER_CACHE_LIMIT_BYTES:break
            try:
                path.unlink()
                path.with_suffix('.json').unlink(missing_ok=True)
                total-=size
            except OSError:pass

    def render_cache_info(self, **_):
        folder=self.root/'render-cache'
        files=[p for p in folder.glob('scene-*.mp4') if not p.is_symlink()
               and re.fullmatch(r'scene-[0-9a-f]{64}\.mp4',p.name)]
        return {'files':len(files),'bytes':sum(p.stat().st_size for p in files),
                'maxBytes':self.RENDER_CACHE_LIMIT_BYTES,
                'message':'Temporary scene renders only. Original media, project and exports remain untouched.'}

    def clear_render_cache(self, **_):
        with self._jobs_lock:
            if self._active_render_job:
                raise ValueError('Cannot clear scene cache while an export is running')
            folder=self.root/'render-cache'
            removed=0
            for path in folder.iterdir():
                if path.is_symlink() or not path.is_file(): continue
                if re.fullmatch(r'scene-[0-9a-f]{64}\.(mp4|json)',path.name):
                    path.unlink();removed+=1
            return {'removedCacheFiles':removed,'originalMediaPreserved':True}

    def render_chapter_command(self,chapterNumber:int,sourceVideoId:str,sourceVideoExt:str,
                               scenes:list,preset:str,recordedSeconds:float,
                               transitionMode:str='cut',quality:str='full',_progress=None,_cancel=None,**_):
        """CPU-only offline visual renderer; 30 fps, source recording contributes audio.

        Cuts and dissolves produce exactly the intended output frame count.
        Both audio-only and narrator-video files contribute the ORIGINAL voice.
        """
        import math
        import tempfile
        if not self.ffmpeg or not Path(self.ffmpeg).is_file():
            raise ValueError('FFmpeg not available locally. MP4 export was cancelled.')
        if not isinstance(chapterNumber,int) or not 1<=chapterNumber<=1000:raise ValueError('Invalid chapter')
        if not isinstance(scenes,list) or not 1<=len(scenes)<=1000:raise ValueError('No scenes')
        if preset not in self.RENDER_DIMENSIONS:raise ValueError('Unsupported render size')
        if transitionMode not in ('cut','dissolve'):raise ValueError('Unsupported transition')
        if quality not in ('preview','full'):raise ValueError('Invalid quality; choose Preview or Full')
        if sourceVideoExt not in NARRATION_EXTS:raise ValueError('Narration recording extension not supported')
        source=self.media(sourceVideoId,sourceVideoExt)
        if not source.is_file() or source.is_symlink():raise ValueError('Narration video missing or unsafe')
        # Don't spend hours rendering 100+ still-image shots only to discover
        # at the final mux that the narrator video contains NO audio.
        # ffprobe is part of normal FFmpeg distributions and also verifies
        # every final MP4 frame below; fail closed if it is missing.
        probe=next((str(candidate) for candidate in (
            Path(self.ffmpeg).with_name('ffprobe.exe'),
            Path(self.ffmpeg).with_name('ffprobe')
        ) if candidate.is_file()),None) or shutil.which('ffprobe')
        if not probe:raise ValueError('ffprobe not found. Install a trusted FFmpeg package containing ffmpeg + ffprobe before export.')
        preflight=subprocess.run([probe,'-v','error','-show_entries',
            'stream=codec_type:format=duration','-of','json',str(source)],
            capture_output=True,text=True,timeout=90)
        if preflight.returncode:raise ValueError('Narration video cannot be decoded by ffprobe')
        source_info=json.loads(preflight.stdout)
        if not any(item.get('codec_type')=='audio' for item in source_info.get('streams',[])):
            raise ValueError('Narration recording has no audio track; export cancelled BEFORE encoding any video scenes')
        source_duration=source_info.get('format',{}).get('duration')
        if source_duration is not None:
            source_duration=float(source_duration)
            if not math.isfinite(source_duration) or abs(source_duration-recordedSeconds)>.9:
                raise ValueError('Narration file duration differs from timeline. Re-import recording or adjust timing BEFORE exporting.')
        total=0.;prepared=[];frame_counts=[];previous_frames=0
        for index,scene in enumerate(scenes,1):
            if not isinstance(scene,dict):raise ValueError(f'Scene {index} is not an object')
            ext=scene['ext'];mid=scene['assetId']
            if ext not in {'png','jpg','jpeg','webp'}:raise ValueError('Unsupported scene image')
            image=self.media(mid,ext)
            if not image.is_file() or image.is_symlink():raise ValueError(f'Missing or unsafe scene image {index}')
            duration=float(scene['duration'])
            if not math.isfinite(duration) or not .25<=duration<=3600:raise ValueError(f'Scene {index} duration invalid')
            motion=scene.get('motion','still')
            if motion not in ('still','pan','zoom'):raise ValueError('Invalid scene motion')
            total+=duration
            if total>43200:raise ValueError('Total exceeds 12 hours')
            current_frames=round(total*self.RENDER_FPS)
            frames=current_frames-previous_frames
            if frames<1:raise ValueError('Scene too short to encode a frame')
            previous_frames=current_frames
            prepared.append((image,motion))
            frame_counts.append(frames)
        if not isinstance(recordedSeconds,(int,float)) or not math.isfinite(recordedSeconds) or not .5<=recordedSeconds<=43200 or abs(total-recordedSeconds)>.5:
            raise ValueError('Narration duration and scene timeline do not match')
        use_fade=(transitionMode=='dissolve' and len(prepared)>1)
        # Render every transition as its own short clip. The previous approach
        # opened ALL chapter scenes simultaneously; that exhausted memory above
        # 32 scenes. Fixed-size pair clips permit whole chapters with 100+ shots.
        fade_frames=min(14, min(frame_counts)//2) if use_fade else 0
        if use_fade and fade_frames<2:raise ValueError('Scene too short for cross dissolve; choose Hard Cut')
        lead=fade_frames//2
        tail=fade_frames-lead
        w,h=self.RENDER_DIMENSIONS[preset]
        if quality=='preview':w,h=w//2,h//2
        steps=len(prepared) + (2*len(prepared)-1 if use_fade else 0)+3
        done_steps=0
        def report(phase):
            nonlocal done_steps
            done_steps+=1
            if _progress:_progress(phase,done_steps,steps)
        def check_cancel():
            if _cancel is not None and _cancel.is_set():raise RenderCancelled('Render cancelled')
        def run_ffmpeg(cmd,timeout):
            check_cancel()
            if _cancel is None:return subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
            with subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) as proc:
                deadline=time.monotonic()+timeout
                while True:
                    try:
                        out,err=proc.communicate(timeout=.35)
                        check_cancel()
                        return subprocess.CompletedProcess(cmd,proc.returncode,out,err)
                    except subprocess.TimeoutExpired:
                        if _cancel.is_set():
                            proc.terminate()
                            try:proc.communicate(timeout=3)
                            except subprocess.TimeoutExpired:proc.kill();proc.communicate()
                            raise RenderCancelled('Render cancelled')
                        if time.monotonic()>deadline:
                            proc.kill();proc.communicate()
                            raise ValueError('FFmpeg scene timed out')
        outdir=self.root/'exports'
        outdir.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='render-pending-',dir=outdir) as temp:
            stage=Path(temp)
            segments=[]
            for index,((image,motion),base_frames) in enumerate(zip(prepared,frame_counts)):
                frames=base_frames+(lead if use_fade and index>0 else 0)+(tail if use_fade and index<len(prepared)-1 else 0)
                segment=stage/f'scene-{index:05d}.mp4'
                cache_key, cache_parameters = self.scene_cache_key(
                    image,motion=motion,frames=frames,width=w,height=h)
                if self.cached_scene_to_stage(cache_key,segment,cache_parameters):
                    segments.append(segment)
                    report(f'Reusing encoded scene {index+1}/{len(prepared)}')
                    continue
                # KEEP THE FULL PHOTO IN FRAME: portrait character art must not
                # lose heads when rendered as landscape video. Create a blurred
                # fill layer and overlay an uncropped original composition.
                fit=(f'[0:v]split=2[bg][fg];'
                     f'[bg]scale={w}:{h}:force_original_aspect_ratio=increase,'
                     f'crop={w}:{h},boxblur=12:1[blur];'
                     f'[fg]scale={w}:{h}:force_original_aspect_ratio=decrease,setsar=1[clear];'
                     f'[blur][clear]overlay=(W-w)/2:(H-h)/2')
                if motion=='zoom':
                    effect=(fit+f",zoompan=z='min(zoom+0.00035,1.065)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s={w}x{h}:fps={self.RENDER_FPS}")
                elif motion=='pan':
                    # Pan across 4% oversized COMPOSITE, not cropped portrait.
                    effect=(fit+f',scale={w+int(w*.05)}:{h+int(h*.05)},'
                            f"crop={w}:{h}:x='(in_w-out_w)*n/{max(1,frames-1)}':y='(in_h-out_h)/2'")
                else:effect=fit
                filt=effect+',setsar=1,format=yuv420p[v]'
                cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                     '-loop','1','-framerate',str(self.RENDER_FPS),'-i',str(image),
                     '-filter_complex',filt,'-map','[v]','-frames:v',str(frames),'-an',
                     '-c:v','libx264','-preset','veryfast','-crf','23',
                     '-pix_fmt','yuv420p','-r',str(self.RENDER_FPS),str(segment)]
                run=run_ffmpeg(cmd,timeout=3600)
                if run.returncode or not segment.is_file() or segment.stat().st_size<256:
                    raise ValueError(f'Scene {index+1} could not render: {run.stderr[-900:]}')
                self.save_scene_cache(cache_key,segment,cache_parameters)
                segments.append(segment)
                report(f'Encoding scene {index+1}/{len(prepared)}')
            picture_track=stage/'picture-track.mp4'
            if use_fade:
                # A transition is a fixed number of video FRAMES, not a duration
                # guessed from VFR timestamps. Extract non-overlap bodies and
                # short blended boundaries separately. At any moment FFmpeg has
                # at most two streams open. The final track is precisely the
                # sum of all original scene frame counts.
                pieces=[]
                for i,seg in enumerate(segments):
                    seg_frames=frame_counts[i]+(lead if i else 0)+(tail if i<len(segments)-1 else 0)
                    begin=fade_frames if i else 0
                    end=seg_frames-(fade_frames if i<len(segments)-1 else 0)
                    count=end-begin
                    if count<1:raise ValueError('Scene is too short for dissolve; use Hard Cut')
                    body=stage/f'piece-{2*i:05d}.mp4'
                    flt=f'trim=start_frame={begin}:end_frame={end},setpts=PTS-STARTPTS,format=yuv420p'
                    cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                         '-i',str(seg),'-vf',flt,'-frames:v',str(count),'-an',
                         '-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p',
                         '-r',str(self.RENDER_FPS),str(body)]
                    output=run_ffmpeg(cmd,timeout=3600)
                    if output.returncode or not body.is_file():
                        raise ValueError(f'Scene {i+1} body render failed: '+output.stderr[-1000:])
                    pieces.append(body)
                    report(f'Preparing scene {i+1} dissolve')
                    if i<len(segments)-1:
                        bridge=stage/f'piece-{2*i+1:05d}.mp4'
                        tail_begin=seg_frames-fade_frames
                        # 0 = prior composition, last frame = next composition.
                        fraction=max(1,fade_frames-1)
                        graph=(f'[0:v]trim=start_frame={tail_begin}:end_frame={seg_frames},setpts=PTS-STARTPTS[a];'
                               f'[1:v]trim=start_frame=0:end_frame={fade_frames},setpts=PTS-STARTPTS[b];'
                               f"[a][b]blend=all_expr='A*(1-min(1,N/{fraction}))+B*min(1,N/{fraction})':shortest=1,format=yuv420p[v]")
                        cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                             '-i',str(seg),'-i',str(segments[i+1]),'-filter_complex',graph,
                             '-map','[v]','-frames:v',str(fade_frames),'-an',
                             '-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p',
                             '-r',str(self.RENDER_FPS),str(bridge)]
                        output=run_ffmpeg(cmd,timeout=3600)
                        if output.returncode or not bridge.is_file():
                            raise ValueError(f'Scene {i+1} cross dissolve failed: '+output.stderr[-1000:])
                        pieces.append(bridge)
                        report(f'Blending scene {i+1} transition')
                listing=stage/'segments.ffconcat'
                listing.write_text('ffconcat version 1.0\n'+''.join(f"file '{seg.name}'\n" for seg in pieces),encoding='utf-8')
                cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                     '-f','concat','-safe','0','-i',str(listing),'-c','copy',str(picture_track)]
                output=run_ffmpeg(cmd,timeout=24*3600)
                report('Combining scenes')
                if output.returncode or not picture_track.is_file():
                    raise ValueError('Crossfade sequence join failed: '+output.stderr[-1200:])
            else:
                listing=stage/'segments.ffconcat'
                listing.write_text('ffconcat version 1.0\n'+''.join(f"file '{seg.name}'\n" for seg in segments),encoding='utf-8')
                cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                     '-f','concat','-safe','0','-i',str(listing),'-c','copy',str(picture_track)]
                output=run_ffmpeg(cmd,timeout=24*3600)
                report('Combining scenes')
                if output.returncode or not picture_track.is_file():
                    raise ValueError('Video segment join failed: '+output.stderr[-1200:])
            pending=stage/'export.partial.mp4'
            cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-y',
                 '-i',str(picture_track),'-i',str(source),'-map','0:v:0','-map','1:a:0',
                 '-c:v','copy','-c:a','aac','-b:a','160k','-t',f'{total:.6f}',
                 '-movflags','+faststart',str(pending)]
            result=run_ffmpeg(cmd,timeout=24*3600)
            report('Combining narrator audio')
            if result.returncode or not pending.is_file() or pending.stat().st_size<1024:
                raise ValueError('FFmpeg mux failed (narration must contain audio): '+result.stderr[-1200:])
            # Validate the actual exported video; merely having a H.264 header
            # is insufficient (an earlier renderer silently emitted ONE frame).
            if probe:
                info=subprocess.run([probe,'-v','error','-count_frames','-show_entries',
                    'stream=codec_type,codec_name,nb_read_frames:format=duration',
                    '-of','json',str(pending)],capture_output=True,text=True,timeout=180)
                if info.returncode:raise ValueError('Output MP4 verification failed')
                result_info=json.loads(info.stdout)
                streams={x.get('codec_type'):x for x in result_info.get('streams',[])}
                v=streams.get('video',{});a=streams.get('audio',{})
                expected=sum(frame_counts)
                frames=int(v.get('nb_read_frames') or 0)
                duration=float(result_info.get('format',{}).get('duration') or 0)
                if v.get('codec_name')!='h264' or a.get('codec_name')!='aac' or frames!=expected or abs(duration-total)>.3:
                    raise ValueError(f'Output MP4 incomplete: {frames}/{expected} video frames, duration {duration:.3f}s (expected {total:.3f}s). Source files untouched.')
            check_cancel()
            report('Verified MP4 video frames and audio')
            dest=outdir/f'chapter-{chapterNumber}-{secrets.token_hex(8)}.mp4'
            pending.replace(dest)
            return str(dest)


ALLOWED = {name for name in dir(Studio) if name in (
    'load_project_state','save_project_state','project_storage_info',
    'render_cache_info','clear_render_cache',
    'begin_media_import','finalize_media_import','abort_media_import',
    'get_media_info','verify_native_media','create_full_local_backup',
    'list_local_backups','verify_local_backup','restore_local_backup','render_chapter_command','start_render_job','get_render_job_status','current_render_job','cancel_render_job','analyze_narration_pauses','list_local_exports','offline_speech_status','transcribe_narration','start_book_merge_job')}


def handler_factory(studio):
    class Handler(BaseHTTPRequestHandler):
        server_version='MMMNLocal/1.0'
        def log_message(self, fmt, *args):
            # Do not print auth token or video media URLs to logs.
            return  # Never print local media URLs or session credentials
        def base_headers(self, type_='application/json; charset=utf-8', length=None):
            self.send_header('Content-Type',type_)
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self' blob: data:; connect-src 'self'; media-src 'self' blob:; img-src 'self' blob: data:; script-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none'")
            self.send_header('Cross-Origin-Resource-Policy','same-origin')
            if length is not None:self.send_header('Content-Length',str(length))
        def reply(self, code, data, ctype='application/json; charset=utf-8'):
            payload=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.base_headers(ctype,len(payload))
            self.end_headers()
            if self.command != 'HEAD':self.wfile.write(payload)
        def safe_origin(self):
            expected=f'127.0.0.1:{self.server.server_address[1]}'
            if self.headers.get('Host','') != expected: return False
            origin=self.headers.get('Origin')
            if origin and origin != 'http://'+expected:return False
            site=self.headers.get('Sec-Fetch-Site','')
            return site in ('','same-origin','none')
        def authorized(self):
            return self.safe_origin() and self.headers.get('X-MM-Token','')==studio.token
        def path_request(self):
            return urlsplit(self.path)
        def stream_file(self, path: Path, mime: str, download_name: str | None = None):
            """Stream local media/exports in bounded chunks; support video seeking and resume."""
            size=path.stat().st_size
            try:
                selected=single_byte_range(self.headers.get('Range'), size)
            except ValueError:
                self.send_response(416)
                self.base_headers(length=0)
                self.send_header('Accept-Ranges','bytes')
                self.send_header('Content-Range',f'bytes */{size}')
                self.end_headers()
                return
            start,end=selected if selected is not None else (0,size-1)
            count=end-start+1 if size else 0
            self.send_response(206 if selected is not None else 200)
            self.base_headers(mime,count)
            self.send_header('Accept-Ranges','bytes')
            if selected is not None:
                self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
            if download_name is not None:
                self.send_header('Content-Disposition',f'attachment; filename="{download_name}"')
            self.end_headers()
            if self.command == 'HEAD':return
            try:
                with path.open('rb') as stream:
                    stream.seek(start)
                    remaining=count
                    while remaining:
                        block=stream.read(min(remaining,1024*1024))
                        if not block:break
                        self.wfile.write(block)
                        remaining-=len(block)
            except (BrokenPipeError, ConnectionResetError):
                # A cancelled/resumed browser download must not kill the server.
                pass

        def do_HEAD(self):
            return self.do_GET()

        def do_GET(self):
            split=self.path_request();route=unquote(split.path)
            if not self.safe_origin():return self.reply(403,{'error':'Local origin required'})
            if route=='/__bridge.js':
                token=json.dumps(studio.token)
                js=f'''const token={token};
window.__MMMN_TRIAL__=true;
window.__TAURI__={{core:{{
  convertFileSrc(path){{return path;}},
  async invoke(command,args={{}},options={{}}){{
    const bin=command==='import_media_chunk';
    const headers={{'X-MM-Token':token,...(bin?(options.headers||{{}}):{{'Content-Type':'application/json'}})}};
    const res=await fetch('/__api/'+encodeURIComponent(command),{{method:'POST',headers,body:bin?args:JSON.stringify(args)}});
    const json=await res.json(); if(!res.ok)throw Error(json.error||'Local operation failed'); return json.result;
  }}
}}}};
'''.encode()
                return self.reply(200,js,'text/javascript; charset=utf-8')
            if route.startswith('/__exports/'):
                filename=route.rsplit('/',1)[-1]
                if not EXPORT_NAME.fullmatch(filename) or parse_qs(split.query).get('token',[''])[0]!=studio.token:
                    return self.reply(403,{'error':'Export access denied'})
                path=studio.root/'exports'/filename
                if not path.is_file() or path.is_symlink():return self.reply(404,{'error':'Export not found'})
                return self.stream_file(path,'video/mp4',download_name=filename)
            if route.startswith('/__media/'):
                filename=route.rsplit('/',1)[-1]
                mid,dot,ext=filename.rpartition('.')
                if not dot or parse_qs(split.query).get('token',[''])[0]!=studio.token:
                    return self.reply(403,{'error':'Access denied'})
                try:
                    path=studio.media(mid,ext)
                    if not path.is_file() or path.is_symlink():raise FileNotFoundError()
                except (ValueError,OSError):
                    return self.reply(404,{'error':'Media not found'})
                return self.stream_file(path,mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
            # Allow only files under the static UI folder; no directory listing or traversal.
            if route=='/':route='/index.html'
            path=(WEB/route.lstrip('/')).resolve()
            if not path.is_relative_to(WEB.resolve()) or not path.is_file():
                return self.reply(404,{'error':'Not found'})
            content=path.read_bytes()
            if route=='/index.html':
                content=content.replace(b'<script type="module" src="app.js"></script>',b'<script src="/__bridge.js"></script><script type="module" src="app.js"></script>')
            return self.reply(200,content,mimetypes.guess_type(path.name)[0] or 'application/octet-stream')
        def do_POST(self):
            split=self.path_request()
            if not split.path.startswith('/__api/') or not self.authorized():
                return self.reply(403,{'error':'Forbidden'})
            command=split.path.removeprefix('/__api/')
            if command not in ALLOWED and command!='import_media_chunk':return self.reply(404,{'error':'Unknown operation'})
            try:
                count=int(self.headers.get('Content-Length','-1'))
                if not 0<=count<=MAX_JSON:raise ValueError('Request body too large')
                # Rendering is independent of project metadata: avoid holding the
                # backup/import lock during a potentially hours-long CPU encode.
                if command in ('render_chapter_command','analyze_narration_pauses','transcribe_narration'):
                    params=json.loads(self.rfile.read(count))
                    if not isinstance(params,dict):raise ValueError('Expected a JSON object')
                    # The prior route accidentally invoked MP4 rendering for pause analysis.
                    result=getattr(studio,command)(**params)
                else:
                  with LOCK:
                    if command=='import_media_chunk':
                        if count>MAX_CHUNK:raise ValueError('Chunk too large')
                        id=self.headers['x-media-id'];offset=int(self.headers['x-media-offset'])
                        sha=self.headers['x-media-sha256']
                        result=studio.import_media_chunk(id,offset,sha,self.rfile.read(count))
                    else:
                        params=json.loads(self.rfile.read(count))
                        if not isinstance(params,dict):raise ValueError('Expected a JSON object')
                        result=getattr(studio,command)(**params)
                return self.reply(200,{'result':result})
            except (ValueError,KeyError,TypeError,FileNotFoundError,OSError,json.JSONDecodeError,subprocess.TimeoutExpired) as error:
                return self.reply(400,{'error':str(error)[:900]})
    return Handler


@contextlib.contextmanager
def one_running_studio(data_folder: Path):
    """Single active process per data directory, independent of HTTP port.

    Do not delete the lock file: removing a locked inode allows a second
    process to create and lock a different inode at the same path.
    """
    data_folder.mkdir(parents=True,exist_ok=True)
    path=data_folder/'.studio-instance.lock'
    with path.open('a+b') as handle:
        handle.seek(0,os.SEEK_END)
        if handle.tell()==0:
            handle.write(b'0');handle.flush()
        handle.seek(0)
        if os.name=='nt':
            import msvcrt
            try:msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
            except OSError as err:
                raise RuntimeError('MMMN Video Studio is already running with this project folder. Close the other window before reopening.') from err
            try:yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            try:fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except OSError as err:
                raise RuntimeError('MMMN Video Studio is already running with this project folder.') from err
            try:yield
            finally:fcntl.flock(handle.fileno(),fcntl.LOCK_UN)


def run(port=PORT, open_browser=True):
    import webbrowser
    token=secrets.token_urlsafe(32)
    with one_running_studio(root_dir()):
        studio=Studio(root_dir(),token)
        # Another unrelated local program might own the default 8765 port.
        # For normal launches, choose a free loopback port instead of failing.
        # CI/diagnostics with an explicit port MUST fail rather than attach to
        # the wrong server (a past test regression).
        try:
            server=ThreadingHTTPServer(('127.0.0.1',port),handler_factory(studio))
        except OSError:
            if port!=PORT or 'MMMN_TRIAL_PORT' in os.environ:
                raise
            server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(studio))
        actual_port=server.server_address[1]
        print(f'MMMN Windows portable trial: http://127.0.0.1:{actual_port}',flush=True)
        print(f'Local project & media: {studio.root}',flush=True)
        print('Use Ctrl+C to stop. No cloud upload. No installation.',flush=True)
        if open_browser:
            threading.Timer(.5,lambda:webbrowser.open(f'http://127.0.0.1:{actual_port}')).start()
        try:server.serve_forever()
        except KeyboardInterrupt:pass
        finally:server.server_close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=int(os.environ.get('MMMN_TRIAL_PORT',PORT)));p.add_argument('--no-browser',action='store_true')
    args=p.parse_args();run(args.port,not args.no_browser)
