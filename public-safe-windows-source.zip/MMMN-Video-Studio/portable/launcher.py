"""Offline Windows entry point. The self-test never touches the user's projects."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from studio_server import Studio, RESOURCE_ROOT, run


def self_test():
    """Exercise the packaged resources and a REAL two-stream H264/AAC render.

    This is safe to run on every Windows install/upgrade: use a disposable folder,
    never the user's LOCALAPPDATA and never a cloud endpoint.
    """
    checks = {}
    required = ('web/index.html', 'web/app.js', 'web/core.mjs',
                'web/resources/starter-project.json', 'renderer/render.py',
                'TRIAL-REVISION.txt')
    for relative in required:
        path = RESOURCE_ROOT / relative
        checks['resource:' + relative] = path.is_file() and path.stat().st_size > 0
    with tempfile.TemporaryDirectory(prefix='mmmn-self-test-') as folder:
        studio = Studio(Path(folder), 'self-test')
        checks['isolated_local_storage'] = studio.root == Path(folder).resolve()
        ff = studio.ffmpeg
        probe = next((str(p) for p in [
            Path(ff).with_name('ffprobe.exe'), Path(ff).with_name('ffprobe')
        ] if p.is_file()), None) if ff else None
        probe = probe or shutil.which('ffprobe')
        checks['ffmpeg_ffprobe_present'] = bool(ff and Path(ff).is_file() and probe)
        if checks['ffmpeg_ffprobe_present']:
            mp4 = Path(folder) / 'verified.mp4'
            cmd = [ff, '-nostdin', '-hide_banner', '-loglevel', 'error', '-y',
                   '-f','lavfi','-i','color=c=black:s=160x90:r=15',
                   '-f','lavfi','-i','sine=frequency=550:sample_rate=44100',
                   '-t','1', '-c:v','libx264','-pix_fmt','yuv420p',
                   '-c:a','aac','-shortest',str(mp4)]
            try:
                subprocess.run(cmd, check=True, capture_output=True, timeout=40)
                result = subprocess.run([probe, '-v','error','-count_frames',
                    '-show_entries','stream=codec_type,codec_name,nb_read_frames',
                    '-of','json',str(mp4)],check=True,capture_output=True,text=True,timeout=30)
                streams = {s.get('codec_type'): s for s in json.loads(result.stdout)['streams']}
                checks['real_video_frames'] = (
                    streams.get('video',{}).get('codec_name') == 'h264' and
                    int(streams.get('video',{}).get('nb_read_frames') or 0) >= 12)
                checks['real_aac_audio'] = streams.get('audio',{}).get('codec_name') == 'aac'
            except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError, KeyError) as exc:
                checks['real_video_frames'] = False
                checks['real_aac_audio'] = False
                checks['render_error'] = str(exc)[:250]
    passed = all(value is True for key,value in checks.items() if key != 'render_error')
    print(json.dumps({'MMMN': 'offline-windows-packaging-self-test',
                      'status': 'PASS' if passed else 'FAIL', 'checks': checks},
                     ensure_ascii=False, indent=2), flush=True)
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser(description='MMMN Offline Windows Video Studio')
    parser.add_argument('--self-test', action='store_true',
                        help='Verify packaged UI, media renderer and isolated storage')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    try:
        run(port=int(os.environ.get('MMMN_TRIAL_PORT', '8765')),
            open_browser=os.environ.get('MMMN_NO_BROWSER') != '1')
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        # Double-clicked Windows EXEs otherwise close their console instantly.
        # Show a useful message; NEVER delete project data to 'fix' startup.
        message = f'MMMN Video Studio could not open.\n\n{error}\n\nExisting projects and media were not removed.'
        print(message, file=sys.stderr, flush=True)
        if os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(None,message,'MMMN Video Studio',0x10)
            except (OSError,AttributeError):
                pass
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
