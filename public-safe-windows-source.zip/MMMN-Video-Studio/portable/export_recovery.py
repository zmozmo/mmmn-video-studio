"""Copy a VERIFIED offline MMMN snapshot to another drive, with staging/verification.

Never overwrite an existing backup. Destination can be USB/external SSD or another
local volume; never exports to Google Drive or uploads any content.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
from studio_server import Studio,root_dir


def export_verified_snapshot(root: Path, destination: Path, snapshot_id: str|None=None) -> Path:
    studio=Studio(Path(root),'offline-export')
    snapshots=studio.list_local_backups()
    if not snapshots:raise ValueError('No local snapshot yet: create a Full Backup in the Studio first')
    snapshot_id=snapshot_id or snapshots[0]['id']
    source=(studio.root/'snapshots'/snapshot_id).resolve()
    if not source.is_dir() or not any(x['id']==snapshot_id for x in snapshots):
        raise ValueError('Snapshot ID is not valid')
    studio.inspect_snapshot(source)  # FAIL CLOSED before any copying
    destination=Path(destination).expanduser().resolve()
    if not destination.is_dir() or destination.is_symlink():
        raise ValueError('Destination must be an existing local folder')
    if destination==studio.root or studio.root in destination.parents or destination in studio.root.parents:
        raise ValueError('Choose another independent drive/folder, not inside Studio data')
    if shutil.disk_usage(destination).free < sum(p.stat().st_size for p in source.rglob('*') if p.is_file())+16*1024*1024:
        raise ValueError('Not enough free space on destination drive')
    final=destination/'MMMN-Video-Studio-Recovery'/snapshot_id
    if final.exists():raise ValueError('Backup already exists at destination; refusing overwrite')
    final.parent.mkdir(parents=True,exist_ok=True)
    partial=final.parent/(snapshot_id+'.partial')
    if partial.exists():raise ValueError('A previous partial export exists; inspect it before retrying')
    try:
        shutil.copytree(source,partial,symlinks=False)
        studio.inspect_snapshot(partial)  # checks every media file SHA-256
        partial.rename(final)
        return final
    except BaseException:
        shutil.rmtree(partial,ignore_errors=True)
        raise


def main():
    parser=argparse.ArgumentParser(description='Offline MMMN recovery snapshot exporter')
    parser.add_argument('--destination',help='Existing folder on USB/other drive')
    parser.add_argument('--snapshot',help='Snapshot name; omit for newest')
    args=parser.parse_args()
    destination=args.destination
    if not destination:
        try:
            from tkinter import Tk,filedialog
            root=Tk();root.withdraw();root.attributes('-topmost',True)
            destination=filedialog.askdirectory(title='Choose USB / external drive recovery folder')
            root.destroy()
        except (ImportError,RuntimeError):
            destination=input('Enter an EXISTING USB/external folder path: ').strip().strip('"')
    if not destination:
        print('Cancelled; existing backup unchanged.');return 0
    try:
        target=export_verified_snapshot(root_dir(),Path(destination),args.snapshot)
    except (OSError,ValueError) as error:
        print('Backup export FAILED:',error);return 1
    print('Backup copy VERIFIED:',target)
    print('Store this on another drive. Original MMMN project files were not modified.')
    return 0

if __name__=='__main__':raise SystemExit(main())
