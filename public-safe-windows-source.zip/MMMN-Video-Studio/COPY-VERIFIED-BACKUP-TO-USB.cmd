@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 portable\export_recovery.py
) else (
  python portable\export_recovery.py
)
echo.
echo If verification failed, the original project and backup have NOT been deleted.
pause
endlocal
