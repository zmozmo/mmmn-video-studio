@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>&1
if %errorlevel%==0 (
  py -3 portable\diagnostics.py
) else (
  where python.exe >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Python 3 not installed. No data was modified.
    pause
    exit /b 1
  )
  python portable\diagnostics.py
)
if errorlevel 1 (
  echo.
  echo Trial health check found missing requirements. Review the messages above.
)
pause
endlocal
