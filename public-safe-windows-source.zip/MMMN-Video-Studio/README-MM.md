**Windows Release Lab R9 — installer အစစ်မဟုတ်သေးပါ။** အဓိကဖိုင် `WINDOWS-RELEASE-LAB-MM.md` ကိုဖတ်ပါ။ Windows CI actual Upgrade Test ပြီးမှ setup.exe ထုတ်ပါမယ်။

**Windows Trial R7 (Portable, not setup.exe)** — အရင်ဆုံး `WINDOWS-TRIAL-R7-READ-FIRST-MM.md` ကိုဖတ်ပါ။ Quick Preview/Full Quality, Export Progress, Cancel, local verified MP4 ပါရှိပြီး Windows Native Installer အစစ်ကို မစမ်းရသေးပါ။

**v0.14.0 SOURCE ONLY — setup.exe မဟုတ်သေးပါ။** Windows ကနေ Install → Upgrade လက်တွေ့ မစမ်းရသေးပါ။ `V0.14-RELEASE-AUDIT-MM.md` ကို အရင်ဖတ်ပါ။

# MMMN Video Studio 0.13.0 — Windows-first, Offline

**အခု Version v0.13 မှာ ပြင်ထားတာကို `V0.13-RELEASE-NOTES-MM.md` မှာ အရင်ဖတ်ပါ။ Windows Setup.exe မထုတ်သေးပါ။**

**Source only. Windows setup.exe မထုတ်ရသေးပါ။** Windows Release Status အသေးစိတ်ကို `V0.12-WINDOWS-RELEASE-STATUS-MM.md` မှာဖတ်ပါ။

## v0.11.0 Windows Recovery Foundation — Source only
**Setup.exe မထုတ်ရသေးပါ။** Streaming native media snapshot, SHA-256 verify, restore, Offline recovery tool, Windows FFmpeg packaging gate တို့ကို ထည့်ထားသည်။
**Windows Rust Compile/Installer/Install→Upgrade မစမ်းရသေးပါ။** အသေးစိတ် `V0.11-RELEASE-REVIEW-MM.md` ကို ဖတ်ပါ။

---

# MMMN Video Studio v0.10.0 — Windows Development Source (မြန်မာ)

**ဒီ ZIP ထဲမှာ Windows Setup.exe မပါပါ။** Windows App ကို Compile / Install / Update စမ်းသပ်ပြီး အသုံးပြုရန် လုံခြုံကြောင်း မအတည်ပြုရသေးပါ။

## v0.10.0 မှာ တကယ် Code ထည့်ထားတာ

- **Native streaming import:** File.slice ဖြင့် 512 KiB စီ ခွဲပြီး Tauri Rust command သို့ raw bytes ပို့၊ AppLocalData/media ထဲ temp file ရေး၊ တစ်ခုလုံးရောက်မှ fsync + rename လုပ်သည်။ 200 MiB browser limit မလိုတော့ပါ။ Windows Native Runtime ကို မစမ်းရသေး။
- **Native playback path:** AppLocalData/media ကိုသာ Tauri asset protocol scope ဖြင့် Media/Preview ဖတ်နိုင်အောင် ကန့်သတ်ထားသည်။
- **Legacy migration:** အဟောင်း IndexedDB ပုံ/အသံကို တွေ့လျှင် Native Folder သို့ ကူးနိုင်သည်။ မူရင်း IndexedDB ကို မဖျက်ပါ။
- **Native draft render:** App UI → Rust → FFmpeg → AppLocalData/exports ရှိ MP4; ရှိပြီးသား Narration Video အသံကို အသုံးပြု၍ PNG/JPEG/WebP နောက်ခံပုံများကို **hard cut** နည်းဖြင့် စီမည်။ `FFmpeg` ကို PATH မှာ သွင်းထားခြင်း သို့မဟုတ် bundling အမှန်တကယ်လုပ်ပြီးမှ လုပ်နိုင်မည်။ Crossfade/Ken Burns မပါသေး။
- **Offline-first, Drive input only:** Video, Import, Export, Backup ဘာကိုမျှ Google Drive သို့ Auto Upload မလုပ်ပါ။
- **Update identity unchanged:** com.mmmn.videostudio + NSIS currentUser + local AppData ပြောင်းမထားပါ။ Windows install/upgrade အစစ် စမ်းရဦးမည်။

## စမ်းသပ်ပြီးသား / မစမ်းရသေး

- Node.js core + native media bridge mock Tests PASS, Python renderer preflight Tests PASS.
- FFmpeg 4-second Technical Rendering PASS (picture changes at sec 1 vs 3, H.264/AAC).
- Tauri Rust Compiler မရှိသော Linux ပတ်ဝန်းကျင်ဖြစ်၍ Rust code **compile စစ်မရသေး**။
- Chromium GUI navigation ကို sandbox policy က Block ထားသောကြောင့် Browser End-to-End **မစမ်းရသေး**။
- Windows Setup.exe နှင့် upgrade test **မရှိသေး**။
- **Complete large-media ZIP backup** (512 MiB အထက်) မပြီးသေး။ Windows install testing မတိုင်မီ native backup + restore လိုအပ်သည်။

## Windows Installer မထုတ်မီ မဖြစ်မနေ

1. `package-lock.json` နှင့် `src-tauri/Cargo.lock` ကို network ကောင်းသည့် trusted build environment တွင် generate + commit လုပ်ပါ။
2. Windows 11 x64 MSVC Rust `cargo check`, Tauri Build၊ Runtime Video/Audio Import / Native Draft Render စမ်းပါ။
3. FFmpeg binary ကို License notices နှင့်တကွ Windows Installer ထဲ bundle ပြီး offline machine မှာ MP4 Export စမ်းပါ။
4. Complete native large-media Backup/Restore ကို သီးခြား drive/location တွင် စမ်းပါ။
5. Installer vA တင် → Chapter Video 1GB+ / Pictures Import → Manual Timeline Save → vB Setup.exe ထပ်တင် (uninstall မလုပ်) → Reopen / Data / Media / Render / Recovery စမ်းပါ။
6. Release Tests / SHA256 / Unsigned SmartScreen warning စစ်ပြီးမှ Setup.exe ဖြန့်ပါ။

အသေးစိတ် `RELEASE-GATES-MM.md` နှင့် `TEST-RESULTS-v0.10.txt` ကိုကြည့်ပါ။
