//! Full-media local snapshots. No network access, no browser ZIP and no user-selected paths.
//! All snapshots live in app local data so copying multi-GB files requires no RAM-sized buffer.
use std::collections::{BTreeMap, HashSet};
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};
use sha2::{Digest, Sha256};
use serde::{Deserialize, Serialize};
use tauri::Manager;

const CHUNK: usize = 1024 * 1024;
const MAX_FILES: usize = 10_000;

#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Entry { id: String, ext: String, bytes: u64, sha256: String }

#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Manifest {
    format: String,
    app_version: String,
    state_sha256: String,
    media: Vec<Entry>,
}

fn snapshots_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let path = super::storage_dir(app)?.join("snapshots");
    fs::create_dir_all(&path).map_err(|e| format!("Cannot open local snapshot directory: {e}"))?;
    Ok(path)
}
fn stamp() -> Result<u128, String> {
    SystemTime::now().duration_since(UNIX_EPOCH)
        .map(|v| v.as_millis()).map_err(|e| format!("System time: {e}"))
}
fn snapshot_path(app: &tauri::AppHandle, id: &str) -> Result<PathBuf, String> {
    let rest=id.strip_prefix("snapshot-").ok_or("Invalid snapshot identifier")?;
    let (milliseconds, pid)=rest.split_once('-').ok_or("Invalid snapshot identifier")?;
    if id.len()>75 || milliseconds.len()<10 || milliseconds.len()>20 || pid.is_empty() ||
       !milliseconds.bytes().all(|c|c.is_ascii_digit()) ||
       !pid.bytes().all(|c|c.is_ascii_digit()) {
        return Err("Invalid snapshot identifier".into());
    }
    Ok(snapshots_dir(app)?.join(id))
}
fn sha256_file(path: &Path) -> Result<(u64, String), String> {
    if !fs::symlink_metadata(path).map_err(|e| format!("Missing file: {e}"))?.file_type().is_file() {
        return Err("Snapshot contains a non-regular file".into());
    }
    let mut file = File::open(path).map_err(|e| format!("Open file: {e}"))?;
    let mut hasher = Sha256::new();
    let mut buffer = [0u8; CHUNK];
    let mut size = 0u64;
    loop {
        let n = file.read(&mut buffer).map_err(|e| format!("Read file: {e}"))?;
        if n == 0 { break; }
        hasher.update(&buffer[..n]);
        size += n as u64;
    }
    Ok((size, format!("{:x}", hasher.finalize())))
}
fn copy_hash(source: &Path, target: &Path) -> Result<(u64, String), String> {
    if !fs::symlink_metadata(source).map_err(|e| format!("Missing media: {e}"))?.file_type().is_file() {
        return Err("Media must be a regular file".into());
    }
    let mut src = File::open(source).map_err(|e| format!("Cannot read source media: {e}"))?;
    let mut dst = OpenOptions::new().write(true).create_new(true).open(target)
        .map_err(|e| format!("Cannot create destination: {e}"))?;
    let mut hasher = Sha256::new();
    let mut buffer = [0u8; CHUNK];
    let mut size = 0u64;
    loop {
        let n = src.read(&mut buffer).map_err(|e| format!("Source media read failed: {e}"))?;
        if n == 0 { break; }
        dst.write_all(&buffer[..n]).map_err(|e| format!("Destination disk full or write failed: {e}"))?;
        hasher.update(&buffer[..n]);
        size += n as u64;
    }
    dst.sync_all().map_err(|e| format!("Cannot flush copied media: {e}"))?;
    Ok((size, format!("{:x}", hasher.finalize())))
}
fn expected_media(project: &serde_json::Value) -> Result<BTreeMap<String,String>,String> {
    let assets = project["assets"].as_array().ok_or("Missing project assets")?;
    if assets.len() > MAX_FILES { return Err("Too many project media files".into()); }
    let mut items = BTreeMap::new();
    for asset in assets {
        let id = asset["id"].as_str().ok_or("Asset missing ID")?;
        if asset["nativeStored"] != true && !(asset["localStored"] == true && asset["bundledUrl"].is_null()) {
            continue; // Bundled references are shipped with the app, not user-imported media.
        }
        super::check_media_id(id)?;
        let name = asset["name"].as_str().ok_or("Asset missing media filename")?;
        let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
        super::check_ext(&ext)?;
        if items.insert(id.to_string(), ext).is_some() { return Err("Duplicate media ID in project".into()); }
    }
    Ok(items)
}
fn project_from_file(path: &Path) -> Result<(Vec<u8>,serde_json::Value),String> {
    if !fs::symlink_metadata(path).map_err(|e|format!("Project file missing: {e}"))?.file_type().is_file() {
        return Err("Project metadata must be a regular file".into());
    }
    let bytes = fs::read(path).map_err(|e| format!("Project metadata missing: {e}"))?;
    if bytes.len() > super::MAX_STATE_BYTES { return Err("Project metadata too large".into()); }
    let contents = std::str::from_utf8(&bytes).map_err(|e| format!("Project text invalid: {e}"))?;
    super::valid_state(contents)?;
    let obj = serde_json::from_slice(&bytes).map_err(|e| format!("Project JSON: {e}"))?;
    Ok((bytes,obj))
}
fn digest(bytes: &[u8]) -> String { format!("{:x}",Sha256::digest(bytes)) }
fn manifest_file(path: &Path) -> Result<Manifest,String> {
    let bytes = fs::read(path.join("manifest.json")).map_err(|e| format!("Snapshot manifest missing: {e}"))?;
    if bytes.len() > 5_000_000 {return Err("Oversized snapshot manifest".into());}
    let manifest: Manifest = serde_json::from_slice(&bytes).map_err(|e| format!("Invalid snapshot manifest: {e}"))?;
    if manifest.format != "mmmn-local-snapshot-v1" || manifest.media.len() > MAX_FILES {
        return Err("Unknown or oversized snapshot format".into());
    }
    Ok(manifest)
}
fn inspect_snapshot(path: &Path) -> Result<(Manifest,serde_json::Value,u64),String> {
    if !fs::symlink_metadata(path).map_err(|e|format!("Snapshot missing: {e}"))?.file_type().is_dir() {
        return Err("Snapshot is not a directory".into());
    }
    let manifest = manifest_file(path)?;
    let (state, project) = project_from_file(&path.join("project-state.json"))?;
    if digest(&state) != manifest.state_sha256 { return Err("Snapshot project checksum mismatch".into()); }
    let expected = expected_media(&project)?;
    if expected.len() != manifest.media.len() { return Err("Snapshot media list is incomplete".into()); }
    let mut seen = HashSet::new();
    let mut total=0u64;
    for entry in &manifest.media {
        super::check_media_id(&entry.id)?;
        super::check_ext(&entry.ext)?;
        if expected.get(&entry.id) != Some(&entry.ext) || !seen.insert(entry.id.as_str()) {
            return Err(format!("Snapshot has unexpected or duplicate media: {}",entry.id));
        }
        let (length,hash) = sha256_file(&path.join("media").join(format!("{}.{}",entry.id,entry.ext)))?;
        if length==0 {return Err(format!("Empty media in backup: {}",entry.id));}
        if length != entry.bytes || hash != entry.sha256 { return Err(format!("Checksum failure for media {}",entry.id)); }
        total = total.checked_add(length).ok_or("Snapshot size overflow")?;
    }
    Ok((manifest,project,total))
}

fn create_full_local_backup_inner(app: tauri::AppHandle) -> Result<serde_json::Value,String> {
    let state_path = super::storage_dir(&app)?.join(super::STATE_FILE);
    let (state,project)=project_from_file(&state_path)?;
    let expected=expected_media(&project)?;
    let id=format!("snapshot-{}-{}",stamp()?,std::process::id());
    let dest=snapshot_path(&app,&id)?;
    let partial=dest.with_extension("partial");
    fs::create_dir(&partial).map_err(|e|format!("Cannot prepare backup: {e}"))?;
    let run=(||->Result<(usize,u64),String>{
        fs::create_dir(partial.join("media")).map_err(|e|format!("Cannot create backup media folder: {e}"))?;
        let mut entries=Vec::new();
        let mut total=0u64;
        for (media_id,ext) in expected {
            let filename=format!("{media_id}.{ext}");
            let src=super::media_dir(&app)?.join(&filename);
            let (bytes,sha256)=copy_hash(&src,&partial.join("media").join(&filename))?;
            if bytes==0 {return Err(format!("Media file empty: {filename}"));}
            total=total.checked_add(bytes).ok_or("Backup size overflow")?;
            entries.push(Entry{id:media_id,ext,bytes,sha256});
        }
        let manifest=Manifest{format:"mmmn-local-snapshot-v1".into(),app_version:app.package_info().version.to_string(),state_sha256:digest(&state),media:entries};
        let mut project_file=OpenOptions::new().write(true).create_new(true).open(partial.join("project-state.json")).map_err(|e|e.to_string())?;
        project_file.write_all(&state).map_err(|e|e.to_string())?;
        project_file.sync_all().map_err(|e|e.to_string())?;
        let mut manifest_out=OpenOptions::new().write(true).create_new(true).open(partial.join("manifest.json")).map_err(|e|e.to_string())?;
        manifest_out.write_all(&serde_json::to_vec_pretty(&manifest).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
        manifest_out.sync_all().map_err(|e|e.to_string())?;
        // Full check before publishing a completed backup.
        inspect_snapshot(&partial)?;
        fs::rename(&partial,&dest).map_err(|e|format!("Cannot finish backup atomically: {e}"))?;
        Ok((manifest.media.len(),total))
    })();
    match run {
        Ok((files,bytes))=>Ok(serde_json::json!({"id":id,"path":dest.to_string_lossy(),"files":files,"bytes":bytes,"verified":true})),
        Err(error)=>{let _=fs::remove_dir_all(&partial);Err(format!("Backup failed; original data unchanged. {error}"))}
    }
}

fn list_local_backups_inner(app: tauri::AppHandle) -> Result<Vec<serde_json::Value>,String> {
    let mut rows=Vec::new();
    for item in fs::read_dir(snapshots_dir(&app)?).map_err(|e|e.to_string())? {
        let entry=item.map_err(|e|e.to_string())?;
        let id=entry.file_name().to_string_lossy().to_string();
        if !id.starts_with("snapshot-") || id.ends_with(".partial") { continue; }
        if snapshot_path(&app,&id).is_err() { continue; }
        rows.push(serde_json::json!({"id":id,"path":entry.path().to_string_lossy()}));
    }
    rows.sort_by(|a,b|b["id"].as_str().cmp(&a["id"].as_str()));
    Ok(rows)
}

fn verify_local_backup_inner(app: tauri::AppHandle, id: String) -> Result<serde_json::Value,String> {
    let path=snapshot_path(&app,&id)?;
    let (manifest,_,bytes)=inspect_snapshot(&path)?;
    Ok(serde_json::json!({"id":id,"verified":true,"files":manifest.media.len(),"bytes":bytes,"appVersion":manifest.app_version}))
}

fn rewrite_ids(v: &mut serde_json::Value, mapping: &BTreeMap<String,String>) {
    match v {
        serde_json::Value::Object(obj)=>for (key,item) in obj.iter_mut(){
            if ["id","assetId","videoAssetId","audioAssetId"].contains(&key.as_str()) {
                if let Some(id)=item.as_str(){if let Some(new)=mapping.get(id){*item=serde_json::Value::String(new.clone());continue;}}
            }
            rewrite_ids(item,mapping);
        },
        serde_json::Value::Array(arr)=>for item in arr {rewrite_ids(item,mapping);},
        _=>{}
    }
}

fn restore_local_backup_inner(app: tauri::AppHandle, id: String) -> Result<serde_json::Value,String> {
    let source=snapshot_path(&app,&id)?;
    let (manifest,mut state,_) = inspect_snapshot(&source)?;
    // Extra safety: snapshot current project BEFORE changing any live media or metadata.
    let before=create_full_local_backup_inner(app.clone())?;
    let prefix=format!("restore-{}-",stamp()?);
    let mut new_files=Vec::new();
    let mut committing=false;
    let result=(||->Result<String,String>{
        let mut mapping=BTreeMap::new();
        for (i,asset) in manifest.media.iter().enumerate() {
            let newid=format!("{}{}",prefix,i);
            super::check_media_id(&newid)?;
            let name=format!("{newid}.{}",asset.ext);
            let out=super::media_dir(&app)?.join(name);
            new_files.push(out.clone()); // Include a partially written copy in rollback cleanup.
            let (size,hash)=copy_hash(&source.join("media").join(format!("{}.{}",asset.id,asset.ext)),&out)?;
            if size!=asset.bytes || hash!=asset.sha256{return Err(format!("Media changed during restore: {}",asset.id));}
            mapping.insert(asset.id.clone(),newid);
        }
        rewrite_ids(&mut state,&mapping);
        let text=serde_json::to_string(&state).map_err(|e|e.to_string())?;
        super::valid_state(&text)?;
        committing=true;
        super::save_project_state(app.clone(),text.clone())?;
        Ok(text)
    })();
    match result {
        Ok(text)=>Ok(serde_json::json!({"restored":true,"media":manifest.media.len(),"beforeSnapshot":before["id"],"project":text})),
        Err(error)=>{
            if !committing {for file in new_files {let _=fs::remove_file(file);}}
            // If save_project_state returned an error after writing the state, keep copied media.
            // Orphan files consume disk space; deleting referenced media would lose user data.
            Err(format!("Restore stopped; existing project was not deliberately deleted. If the save phase started, media copies were retained for safety. {error}"))
        }
    }
}

// Multi-GB file work must never block the UI thread.
#[tauri::command]
pub async fn create_full_local_backup(app:tauri::AppHandle)->Result<serde_json::Value,String>{
    tauri::async_runtime::spawn_blocking(move||create_full_local_backup_inner(app)).await.map_err(|e|e.to_string())?
}
#[tauri::command]
pub async fn list_local_backups(app:tauri::AppHandle)->Result<Vec<serde_json::Value>,String>{
    tauri::async_runtime::spawn_blocking(move||list_local_backups_inner(app)).await.map_err(|e|e.to_string())?
}
#[tauri::command]
pub async fn verify_local_backup(app:tauri::AppHandle,id:String)->Result<serde_json::Value,String>{
    tauri::async_runtime::spawn_blocking(move||verify_local_backup_inner(app,id)).await.map_err(|e|e.to_string())?
}
#[tauri::command]
pub async fn restore_local_backup(app:tauri::AppHandle,id:String)->Result<serde_json::Value,String>{
    tauri::async_runtime::spawn_blocking(move||restore_local_backup_inner(app,id)).await.map_err(|e|e.to_string())?
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn crypto_hash_matches_known_sha256() {
        assert_eq!(digest(b"abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    }
    #[test]
    fn restore_changes_media_ids_without_touching_myanmar_text() {
        let mut state=serde_json::json!({"title":"ငှက်အော်ကျွန်း","assets":[{"id":"video-abc123","name":"a.mp4"}],
          "chapters":[{"title":"အခန်း (၁)","videoAssetId":"video-abc123","scenes":[{"assetId":"video-abc123","text":"ဇာတ်လမ်း"}]}]});
        let mut mapping=BTreeMap::new();
        mapping.insert("video-abc123".into(),"restore-123-0".into());
        rewrite_ids(&mut state,&mapping);
        assert_eq!(state["chapters"][0]["videoAssetId"],"restore-123-0");
        assert_eq!(state["chapters"][0]["scenes"][0]["assetId"],"restore-123-0");
        assert_eq!(state["title"],"ငှက်အော်ကျွန်း");
        assert_eq!(state["chapters"][0]["scenes"][0]["text"],"ဇာတ်လမ်း");
    }
}

#[cfg(test)]
mod streaming_tests {
    use super::*;
    #[test]
    fn checksum_streamed_copy_round_trip_and_corruption_detectable(){
        let parent=std::env::temp_dir().join(format!("mmmn-stream-{}-{}",std::process::id(),stamp().unwrap()));
        fs::create_dir(&parent).unwrap();
        let from=parent.join("from.bin");let to=parent.join("to.bin");
        let source=vec![0x35u8; 2*CHUNK+197];
        fs::write(&from,&source).unwrap();
        let (size,hash)=copy_hash(&from,&to).unwrap();
        assert_eq!(size,source.len() as u64);
        assert_eq!(sha256_file(&to).unwrap(),(size,hash));
        let mut changed=source;changed[10]=0x44;
        fs::write(&to,&changed).unwrap();
        assert_ne!(sha256_file(&to).unwrap().1,hash);
        fs::remove_dir_all(parent).unwrap();
    }
}
