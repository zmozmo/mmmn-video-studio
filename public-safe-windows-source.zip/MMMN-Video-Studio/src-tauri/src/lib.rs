use std::fs;
use std::path::{Path, PathBuf};
use tauri::Manager;
use sha2::{Digest, Sha256};
use std::io::Read;
mod snapshots;

const STATE_FILE: &str = "project-state.json";
const BACKUP_FILE: &str = "project-state.previous.json";
const PREUPGRADE_FILE: &str = "project-state.preupgrade.json";
const VERSION_FILE: &str = "last-saved-version.txt";
const MAX_STATE_BYTES: usize = 16 * 1024 * 1024;

fn storage_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let dir = app.path().app_local_data_dir().map_err(|e| format!("App data directory: {e}"))?;
    fs::create_dir_all(&dir).map_err(|e| format!("Cannot create local data directory: {e}"))?;
    Ok(dir)
}

fn valid_state(contents: &str) -> Result<(), String> {
    if contents.len() > MAX_STATE_BYTES {
        return Err("Project metadata exceeds 16 MiB. Keep media files separate.".into());
    }
    let json: serde_json::Value = serde_json::from_str(contents).map_err(|e| format!("Project JSON invalid: {e}"))?;
    if !json.get("chapters").is_some_and(|v| v.is_array()) || !json.get("assets").is_some_and(|v| v.is_array()) {
        return Err("Project must have chapters and assets arrays".into());
    }
    Ok(())
}

fn read_valid_state(path: &Path) -> Result<String, String> {
    let text = fs::read_to_string(path).map_err(|e| format!("Cannot read state: {e}"))?;
    valid_state(&text)?;
    Ok(text)
}

#[tauri::command]
fn load_project_state(app: tauri::AppHandle) -> Result<Option<String>, String> {
    let dir = storage_dir(&app)?;
    let state = dir.join(STATE_FILE);
    let backup = dir.join(BACKUP_FILE);
    let older = dir.join("project-state.older.json");
    let preupgrade = dir.join(PREUPGRADE_FILE);
    for candidate in [&state, &backup, &older, &preupgrade] {
        if candidate.exists() {
            if let Ok(text) = read_valid_state(candidate) { return Ok(Some(text)); }
        }
    }
    if [&state, &backup, &older, &preupgrade].iter().any(|path|path.exists()) {
        return Err("All existing project recovery copies are invalid. Files were not overwritten.".into());
    }
    Ok(None)
}

#[tauri::command]
fn save_project_state(app: tauri::AppHandle, json: String) -> Result<(), String> {
    valid_state(&json)?;
    let dir = storage_dir(&app)?;
    let dest = dir.join(STATE_FILE);
    let bak = dir.join(BACKUP_FILE);
    let tmp = dir.join("project-state.pending.json");
    {
        use std::io::Write;
        let mut pending = fs::File::create(&tmp).map_err(|e| format!("Cannot create pending project: {e}"))?;
        pending.write_all(json.as_bytes()).map_err(|e| format!("Cannot write pending project: {e}"))?;
        pending.sync_all().map_err(|e| format!("Cannot flush pending project: {e}"))?;
    }
    // A damaged main state can be recovered, but the damaged bytes are kept for inspection.
    if dest.exists() && read_valid_state(&dest).is_err() {
        if !bak.exists() || read_valid_state(&bak).is_err() {
            return Err("Current project is damaged and no valid recovery exists; refusing to overwrite.".into());
        }
        let stamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|e| format!("Cannot timestamp damaged project: {e}"))?.as_millis();
        fs::rename(&dest, dir.join(format!("project-state.corrupt-{stamp}.json")))
            .map_err(|e| format!("Cannot preserve damaged project: {e}"))?;
        fs::copy(&bak, &dest).map_err(|e| format!("Cannot restore last-good project: {e}"))?;
    }
    // Never replace the last known-good backup with an invalid existing project.
    if dest.exists() {
        read_valid_state(&dest)?;
        // A version change creates an extra durable snapshot before rewriting project metadata.
        // Only app-owned files under the app data dir are touched (never Drive or source files).
        let current_version = app.package_info().version.to_string();
        let previous_version = fs::read_to_string(dir.join(VERSION_FILE)).unwrap_or_default();
        if previous_version.trim() != current_version {
            fs::copy(&dest, dir.join(PREUPGRADE_FILE)).map_err(|e| format!("Cannot create pre-upgrade snapshot: {e}"))?;
        }
        // Keep the old backup until the new one is durable. On Windows, renaming
        // onto an existing destination is not portable; rotate to a separate file.
        let next_bak = dir.join("project-state.next-backup.json");
        if next_bak.exists() { fs::remove_file(&next_bak).map_err(|e| format!("Cannot clear stale backup staging: {e}"))?; }
        fs::copy(&dest, &next_bak).map_err(|e| format!("Cannot stage new backup: {e}"))?;
        read_valid_state(&next_bak)?;
        // Preserve a third last-good copy until the next successful save.
        let older = dir.join("project-state.older.json");
        if older.exists() { fs::remove_file(&older).map_err(|e| format!("Cannot rotate older backup: {e}"))?; }
        if bak.exists() { fs::rename(&bak, &older).map_err(|e| format!("Cannot retain older backup: {e}"))?; }
        fs::rename(&next_bak, &bak).map_err(|e| format!("Cannot activate new backup: {e}"))?;
        // The main file is valid and has a durable new backup. Remove it only
        // when ready to finalize the validated pending copy.
        fs::remove_file(&dest).map_err(|e| format!("Cannot release old project before atomic replace: {e}"))?;
    }
    fs::rename(&tmp, &dest).map_err(|e| format!("Cannot finalize project; backup remains available: {e}"))?;
    fs::write(dir.join(VERSION_FILE), app.package_info().version.to_string()).map_err(|e| format!("Saved project but could not record version: {e}"))?;
    Ok(())
}

#[tauri::command]
fn project_storage_info(app: tauri::AppHandle) -> Result<serde_json::Value, String> {
    let dir = storage_dir(&app)?;
    Ok(serde_json::json!({
        "path": dir.to_string_lossy(),
        "projectFile": STATE_FILE,
        "hasProject": dir.join(STATE_FILE).is_file(),
        "hasRecovery": dir.join(BACKUP_FILE).is_file(),
        "hasPreupgradeBackup": dir.join(PREUPGRADE_FILE).is_file(),
        "storage": "local-device-only"
    }))
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![load_project_state, save_project_state, project_storage_info, begin_media_import, import_media_chunk, finalize_media_import, abort_media_import, get_media_info, verify_native_media, render_chapter_command, snapshots::create_full_local_backup, snapshots::list_local_backups, snapshots::verify_local_backup, snapshots::restore_local_backup])
        .run(tauri::generate_context!())
        .expect("error while running MMMN Video Studio");
}

// v0.10.0: chunked native media import: source files never leave the user's device.
const MAX_MEDIA_CHUNK: usize = 1_048_576;
const ALLOWED_EXTS: &[&str] = &["png", "jpg", "jpeg", "webp", "gif", "mp4", "m4v", "mov", "webm", "mp3", "m4a", "wav", "ogg", "aac"];

fn check_media_id(id: &str) -> Result<(), String> {
    if id.len() < 6 || id.len() > 90 || !id.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-' || c == b'_') {
        return Err("Invalid media identifier".into());
    }
    Ok(())
}
fn check_ext(ext: &str) -> Result<(), String> {
    if !ALLOWED_EXTS.contains(&ext) { return Err("Unsupported media format".into()); }
    Ok(())
}
fn media_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let dir = storage_dir(app)?.join("media");
    fs::create_dir_all(&dir).map_err(|e| format!("Cannot create media folder: {e}"))?;
    Ok(dir)
}
fn import_dir(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    let dir = storage_dir(app)?.join("imports");
    fs::create_dir_all(&dir).map_err(|e| format!("Cannot create import folder: {e}"))?;
    Ok(dir)
}
fn import_part(app: &tauri::AppHandle, id: &str) -> Result<PathBuf, String> {
    check_media_id(id)?;
    Ok(import_dir(app)?.join(format!("{id}.partial")))
}
fn import_meta(app: &tauri::AppHandle, id: &str) -> Result<PathBuf, String> {
    check_media_id(id)?;
    Ok(import_dir(app)?.join(format!("{id}.json")))
}
fn read_import_meta(app: &tauri::AppHandle, id: &str) -> Result<(String, u64), String> {
    let meta: serde_json::Value = serde_json::from_slice(&fs::read(import_meta(app,id)?).map_err(|e| format!("Import metadata: {e}"))?)
        .map_err(|e| format!("Invalid import metadata: {e}"))?;
    let ext = meta["ext"].as_str().ok_or("Invalid media extension metadata")?.to_string();
    check_ext(&ext)?;
    let total = meta["total"].as_u64().ok_or("Invalid import size metadata")?;
    Ok((ext,total))
}
#[tauri::command]
fn begin_media_import(app: tauri::AppHandle, id: String, ext: String, total: u64) -> Result<(), String> {
    use std::io::Write;
    check_media_id(&id)?;
    check_ext(&ext)?;
    if total == 0 || total > 100 * 1024 * 1024 * 1024 { return Err("Media file size must be 1B–100GB".into()); }
    if media_dir(&app)?.join(format!("{id}.{ext}")).exists() { return Err("Media ID already exists; use a new import ID".into()); }
    let part = import_part(&app,&id)?;
    let metadata = import_meta(&app,&id)?;
    let mut file = fs::OpenOptions::new().write(true).create_new(true).open(&part)
       .map_err(|e| format!("Import already in progress or not writable: {e}"))?;
    let json = serde_json::json!({"ext": ext, "total": total}).to_string();
    if let Err(error) = (|| -> std::io::Result<()> {
        let mut meta_file = fs::OpenOptions::new().write(true).create_new(true).open(&metadata)?;
        meta_file.write_all(json.as_bytes())?;
        meta_file.sync_all()?;
        file.flush()?;
        Ok(())
    })() { let _=fs::remove_file(&part); return Err(format!("Cannot prepare import metadata: {error}")); }
    Ok(())
}
fn chunk_hash_matches(bytes: &[u8], expected: &str) -> bool {
    expected.len()==64 && expected.bytes().all(|b|b.is_ascii_hexdigit()) &&
        format!("{:x}",Sha256::digest(bytes)).eq_ignore_ascii_case(expected)
}

#[cfg(test)]
mod media_chunk_integrity_tests {
    use super::*;
    #[test]
    fn rejects_corrupt_chunk_before_writing() {
        assert!(chunk_hash_matches(b"abc", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
        assert!(!chunk_hash_matches(b"abd", "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
        assert!(!chunk_hash_matches(b"abc", "invalid"));
    }
}

#[tauri::command]
fn import_media_chunk(app: tauri::AppHandle, request: tauri::ipc::Request) -> Result<u64,String> {
    use std::io::Write;
    let head = request.headers();
    let id = head.get("x-media-id").and_then(|v|v.to_str().ok()).ok_or("Missing media ID")?;
    check_media_id(id)?;
    let offset: u64 = head.get("x-media-offset").and_then(|v|v.to_str().ok()).ok_or("Missing offset")?
        .parse().map_err(|_|"Invalid media offset")?;
    let bytes = match request.body() {
       tauri::ipc::InvokeBody::Raw(bytes) => bytes.as_slice(),
       _ => return Err("Raw binary import chunk expected".into())
    };
    if bytes.is_empty() || bytes.len() > MAX_MEDIA_CHUNK { return Err("Chunk must be 1B–1MiB".into()); }
    let expected_chunk_hash=head.get("x-media-sha256")
        .and_then(|v|v.to_str().ok()).ok_or("Missing media chunk checksum")?;
    if !chunk_hash_matches(bytes, expected_chunk_hash) {
        return Err("Media chunk checksum mismatch; import was not written".into());
    }
    let (_, total) = read_import_meta(&app,id)?;
    if offset > total || (bytes.len() as u64) > total - offset { return Err("Chunk exceeds expected total size".into()); }
    let mut file = fs::OpenOptions::new().append(true).open(import_part(&app,id)?)
        .map_err(|e| format!("Cannot reopen import: {e}"))?;
    let written = file.metadata().map_err(|e|format!("Cannot inspect partial import: {e}"))?.len();
    if written != offset { return Err(format!("Out-of-order chunk; next expected offset: {written}")); }
    file.write_all(bytes).map_err(|e|format!("Media disk write failed: {e}"))?;
    Ok(offset + bytes.len() as u64)
}
#[tauri::command]
fn finalize_media_import(app: tauri::AppHandle, id: String) -> Result<serde_json::Value,String> {
    check_media_id(&id)?;
    let (ext,total)=read_import_meta(&app,&id)?;
    let part=import_part(&app,&id)?;
    let final_file=media_dir(&app)?.join(format!("{id}.{ext}"));
    if final_file.exists(){return Err("Destination media already exists; refusing to overwrite".into());}
    let file=fs::OpenOptions::new().read(true).write(true).open(&part).map_err(|e|format!("Partial file: {e}"))?;
    let actual=file.metadata().map_err(|e|format!("Partial size: {e}"))?.len();
    if actual != total { return Err(format!("Incomplete media: {actual}/{total} bytes. Original was not changed.")); }
    file.sync_all().map_err(|e|format!("Cannot flush media to disk: {e}"))?;
    drop(file);
    // Checksum evidence verifies the fully written on-disk file without buffering the
    // whole recording in RAM; useful when importing multi-GB narration videos.
    let mut reader=fs::File::open(&part).map_err(|e|format!("Cannot verify import: {e}"))?;
    let mut hasher=Sha256::new();
    let mut block=[0u8; 1024 * 1024];
    loop {
        let n=reader.read(&mut block).map_err(|e|format!("Cannot checksum imported video: {e}"))?;
        if n==0 {break;}
        hasher.update(&block[..n]);
    }
    drop(reader);
    let checksum=format!("{:x}",hasher.finalize());
    fs::rename(&part,&final_file).map_err(|e|format!("Cannot finalize media: {e}"))?;
    let _ = fs::remove_file(import_meta(&app,&id)?);
    Ok(serde_json::json!({"path":final_file.to_string_lossy(),"size":total,"id":id,"ext":ext,"sha256":checksum}))
}
#[tauri::command]
fn abort_media_import(app: tauri::AppHandle, id: String) -> Result<(),String> {
    check_media_id(&id)?;
    let _=fs::remove_file(import_part(&app,&id)?);
    let _=fs::remove_file(import_meta(&app,&id)?);
    Ok(())
}
// Files are checked against the original import checksum before export or upgrade.
// This work is streamed and dispatched to a blocking worker so UI remains responsive.
fn verify_media_file_inner(app: &tauri::AppHandle, id: String, ext: String, expected_sha256: String) -> Result<serde_json::Value, String> {
    check_media_id(&id)?;
    check_ext(&ext)?;
    if expected_sha256.len()!=64 || !expected_sha256.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err("Expected media SHA256 must have 64 hexadecimal characters".into());
    }
    let path=media_dir(app)?.join(format!("{id}.{ext}"));
    if !fs::symlink_metadata(&path).map_err(|e|format!("Missing media: {e}"))?.file_type().is_file(){
        return Err("Media must be a regular file".into());
    }
    let mut file=fs::File::open(&path).map_err(|e|format!("Cannot open media: {e}"))?;
    let mut hasher=Sha256::new();
    let mut size=0u64;
    let mut block=[0u8; 1024*1024];
    loop {
        let n=file.read(&mut block).map_err(|e|format!("Cannot read media: {e}"))?;
        if n==0 {break;}
        hasher.update(&block[..n]);
        size+=n as u64;
    }
    let actual=format!("{:x}",hasher.finalize());
    if !actual.eq_ignore_ascii_case(&expected_sha256) {
        return Err(format!("Media SHA256 mismatch: {id}. Restore from a verified backup; original metadata was not changed."));
    }
    Ok(serde_json::json!({"id":id,"ext":ext,"size":size,"sha256":actual,"verified":true,"path":path.to_string_lossy()}))
}
#[tauri::command]
async fn verify_native_media(app: tauri::AppHandle, id: String, ext: String, expected_sha256: String) -> Result<serde_json::Value, String> {
    tauri::async_runtime::spawn_blocking(move||verify_media_file_inner(&app,id,ext,expected_sha256))
        .await.map_err(|e|format!("Media verification worker: {e}"))?
}

#[tauri::command]
fn get_media_info(app: tauri::AppHandle, id: String, ext: String) -> Result<Option<serde_json::Value>,String> {
    check_media_id(&id)?;
    check_ext(&ext)?;
    let file = media_dir(&app)?.join(format!("{id}.{ext}"));
    match fs::metadata(&file){
        Ok(meta) if meta.is_file() => Ok(Some(serde_json::json!({"path":file.to_string_lossy(),"size":meta.len()}))),
        Ok(_) => Err("Expected media file; encountered directory".into()),
        Err(e) if e.kind()==std::io::ErrorKind::NotFound => Ok(None),
        Err(e) => Err(format!("Cannot inspect media: {e}"))
    }
}

// A deliberately local-only draft renderer. FFmpeg must be installed or explicitly bundled.
// Scene changes are hard cuts in this native path; cinematic dissolves are a later gate.
#[derive(serde::Deserialize)]
#[serde(rename_all="camelCase")]
struct RenderScene { asset_id: String, ext: String, duration: f64 }

fn ffmpeg_location(app: &tauri::AppHandle) -> Result<PathBuf, String> {
    // Installer config maps resources/bin/ffmpeg.exe to $RESOURCE/bin/ffmpeg.exe.
    // Do not rely on a global PATH ffmpeg: a completed offline Windows install must
    // render without an extra external application or network access.
    let binary = if cfg!(windows) { "ffmpeg.exe" } else { "ffmpeg" };
    if let Ok(root) = app.path().resource_dir() {
        let supplied = root.join("bin").join(binary);
        if supplied.is_file() { return Ok(supplied); }
    }
    // Development/test-only override. Never silently use an unknown PATH executable.
    if cfg!(debug_assertions) {
        if let Ok(custom) = std::env::var("MMMN_FFMPEG") {
            if Path::new(&custom).is_file() { return Ok(PathBuf::from(custom)); }
        }
    }
    Err("Bundled offline FFmpeg executable is missing. Render was cancelled; no project data was changed.".into())
}

fn render_chapter_inner(
    app: &tauri::AppHandle, chapter_number: u32, source_video_id: String,
    source_video_ext: String, scenes: Vec<RenderScene>, preset: String, recorded_seconds: f64
) -> Result<String,String> {
    use std::io::Write;
    if chapter_number == 0 || chapter_number > 1000 { return Err("Invalid chapter number".into()); }
    check_media_id(&source_video_id)?;
    if !["mp4","mov","m4v","webm","mp3","m4a","wav","ogg","aac"].contains(&source_video_ext.as_str()) { return Err("Narration must be video or audio: MP4/MOV/WebM/MP3/M4A/WAV/OGG/AAC".into()); }
    let source=media_dir(app)?.join(format!("{source_video_id}.{source_video_ext}"));
    if !source.is_file() { return Err("Original narrator recording is missing from native storage".into()); }
    if scenes.is_empty() || scenes.len() > 1000 { return Err("Chapter needs 1–1000 image scenes".into()); }
    let (w,h)=match preset.as_str() {
        "youtube"=>(1920,1080), "tiktok"=>(1080,1920),
        "facebook"=>(1080,1350), "square"=>(1080,1080),
        _=>return Err("Unknown render preset".into())
    };
    // Input-stills FFconcat is unsafe here: a mixed PNG/JPEG timeline can
    // produce an MP4 with only a single decodable frame. Render one H.264
    // segment per scene, then losslessly concatenate segments and add narration.
    let media=media_dir(app)?;
    let mut total=0.0;
    let mut valid=Vec::with_capacity(scenes.len());
    for scene in &scenes {
        check_media_id(&scene.asset_id)?;
        if !["png","jpg","jpeg","webp"].contains(&scene.ext.as_str()) {
            return Err("Scene asset must be PNG/JPEG/WebP".into());
        }
        if !scene.duration.is_finite() || scene.duration < 0.25 || scene.duration > 3600.0 {
            return Err("Scene duration out of safe range".into());
        }
        total += scene.duration;
        if total > 43200.0 { return Err("Chapter longer than 12 hours".into()); }
        let image=media.join(format!("{}.{}",scene.asset_id,scene.ext));
        if !image.is_file() || image.is_symlink() {
            return Err(format!("Missing or unsafe scene image {}",scene.asset_id));
        }
        valid.push((image,total));
    }
    if !recorded_seconds.is_finite() || recorded_seconds < 0.5 || recorded_seconds > 43200.0 {
        return Err("Missing or invalid source recording duration".into());
    }
    if (total-recorded_seconds).abs()>0.5 {
        return Err(format!("Timeline duration ({total:.2}s) differs from narration ({recorded_seconds:.2}s)."));
    }
    let output_dir=storage_dir(app)?.join("exports");
    fs::create_dir_all(&output_dir).map_err(|e|format!("Cannot create export directory: {e}"))?;
    let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
        .map_err(|e|format!("System clock: {e}"))?.as_nanos();
    let label=format!("chapter-{chapter_number}-{now}");
    let stage=output_dir.join(format!(".render-pending-{label}"));
    fs::create_dir(&stage).map_err(|e|format!("Cannot reserve render folder: {e}"))?;
    let result=(|| -> Result<String,String> {
        let ffmpeg=ffmpeg_location(app)?;
        let mut list=String::from("ffconcat version 1.0\n");
        let mut previous_frames=0_u64;
        for (i,(image,until_seconds)) in valid.iter().enumerate() {
            let target_frames=(*until_seconds*30.0).round() as u64;
            let frames=target_frames.checked_sub(previous_frames)
                .filter(|v|*v>0).ok_or_else(||"Scene too short to render".to_owned())?;
            previous_frames=target_frames;
            let segment_name=format!("scene-{i:05}.mp4");
            let segment=stage.join(&segment_name);
            let rendered=std::process::Command::new(&ffmpeg)
                .args(["-nostdin","-hide_banner","-loglevel","error","-y","-loop","1","-framerate","30","-i"])
                .arg(image)
                .arg("-vf").arg(format!("scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1,format=yuv420p"))
                .args(["-frames:v",&frames.to_string(),"-an","-c:v","libx264","-preset","veryfast","-crf","23","-pix_fmt","yuv420p","-r","30"])
                .arg(&segment)
                .output().map_err(|e|format!("Cannot launch segment FFmpeg: {e}"))?;
            if !rendered.status.success() || fs::metadata(&segment).map(|m|m.len()).unwrap_or(0)<256 {
                return Err(format!("Scene {} render failed: {}",i+1,String::from_utf8_lossy(&rendered.stderr).chars().take(900).collect::<String>()));
            }
            list.push_str(&format!("file '{segment_name}'\n"));
        }
        let playlist=stage.join("segments.ffconcat");
        fs::write(&playlist,list).map_err(|e|format!("Cannot write segment playlist: {e}"))?;
        let pending=stage.join("export.partial.mp4");
        let muxed=std::process::Command::new(&ffmpeg)
            .args(["-nostdin","-hide_banner","-loglevel","error","-y","-f","concat","-safe","0","-i"])
            .arg(&playlist)
            .arg("-i").arg(&source)
            .args(["-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-b:a","160k","-t",&format!("{total:.6}"),"-movflags","+faststart"])
            .arg(&pending).output().map_err(|e|format!("Cannot launch mux FFmpeg: {e}"))?;
        if !muxed.status.success() || fs::metadata(&pending).map(|m|m.len()).unwrap_or(0)<1024 {
            return Err(format!("Audio/video mux failed: {}",String::from_utf8_lossy(&muxed.stderr).chars().take(900).collect::<String>()));
        }
        let destination=output_dir.join(format!("{label}.mp4"));
        if destination.exists() { return Err("Render filename collision".into()); }
        fs::rename(&pending,&destination).map_err(|e|format!("Cannot finalize MP4: {e}"))?;
        Ok(destination.to_string_lossy().into_owned())
    })();
    let _=fs::remove_dir_all(&stage);
    result
}
#[tauri::command]
async fn render_chapter_command(
   app: tauri::AppHandle, chapter_number: u32, source_video_id: String,
   source_video_ext: String, scenes: Vec<RenderScene>, preset: String, recorded_seconds: f64
)->Result<String,String>{
   tauri::async_runtime::spawn_blocking(move || render_chapter_inner(&app,chapter_number,source_video_id,source_video_ext,scenes,preset,recorded_seconds))
       .await.map_err(|e|format!("Render thread: {e}"))?
}
