#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main() { mmmn_video_studio_lib::run() }
