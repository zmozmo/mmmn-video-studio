@echo off
set "OUT=%LOCALAPPDATA%\MMMN-Video-Studio-Trial\exports"
if not exist "%OUT%" mkdir "%OUT%"
start "" explorer.exe "%OUT%"
