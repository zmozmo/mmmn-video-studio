@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\check-windows-build-prerequisites.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
echo Windows prerequisites report: WINDOWS-PREREQUISITE-REPORT.txt
echo This check does not install software or change user data.
pause
exit /b %RESULT%
