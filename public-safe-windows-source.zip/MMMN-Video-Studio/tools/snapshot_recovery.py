#!/usr/bin/env python3
"""MMMN v1 native snapshot checker/recovery (offline, stdlib only).

Verify: python tools/snapshot_recovery.py verify /path/to/snapshot-ID
Recover into a NEW folder: python tools/snapshot_recovery.py recover /path/to/snapshot-ID /path/to/new-folder
No network or mutation of the input snapshot is performed.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
from pathlib import Path

MAX_MANIFEST_BYTES = 5_000_000
MAX_STATE_BYTES = 16 * 1024 * 1024
SAFE_NAME = re.compile(r'^[A-Za-z0-9_-]{6,90}$')
ALLOWED_EXT = frozenset('png jpg jpeg webp gif mp4 m4v mov webm mp3 m4a wav ogg aac'.split())


def sha256(path):
    h = hashlib.sha256()
    total = 0
    with path.open('rb') as src:
        while chunk := src.read(1024 * 1024):
            h.update(chunk)
            total += len(chunk)
    return total, h.hexdigest()


def verify(snapshot):
    snapshot = Path(snapshot)
    if not snapshot.is_dir() or snapshot.is_symlink():
        raise ValueError('Snapshot folder missing or symbolic link')
    manifest_path = snapshot / 'manifest.json'
    project_path = snapshot / 'project-state.json'
    for file_path in (manifest_path, project_path):
        if not file_path.is_file() or file_path.is_symlink():
            raise ValueError(f'Missing or unsafe file: {file_path.name}')
    if manifest_path.stat().st_size > MAX_MANIFEST_BYTES:
        raise ValueError('Manifest too large')
    if project_path.stat().st_size > MAX_STATE_BYTES:
        raise ValueError('Project metadata too large')
    manifest = json.loads(manifest_path.read_text('utf-8'))
    raw = project_path.read_bytes()
    project = json.loads(raw)
    if manifest.get('format') != 'mmmn-local-snapshot-v1':
        raise ValueError('Unknown snapshot format')
    if hashlib.sha256(raw).hexdigest() != manifest['stateSha256']:
        raise ValueError('Project checksum mismatch')
    if not isinstance(project.get('chapters'), list) or not isinstance(project.get('assets'), list):
        raise ValueError('Invalid project metadata')
    declared = {}
    for asset in project['assets']:
        if asset.get('nativeStored') is True or (asset.get('localStored') is True and not asset.get('bundledUrl')):
            id_ = asset['id']
            ext = asset['name'].rsplit('.', 1)[-1].lower()
            if not SAFE_NAME.fullmatch(id_) or ext not in ALLOWED_EXT or id_ in declared:
                raise ValueError('Invalid or duplicate project media ID')
            declared[id_] = ext
    entries = manifest['media']
    if len(entries) != len(declared) or len(entries) > 10000:
        raise ValueError('Missing or extra media in backup manifest')
    counted, total = set(), 0
    for item in entries:
        id_, ext = item['id'], item['ext']
        if declared.get(id_) != ext or id_ in counted:
            raise ValueError('Unexpected or duplicate backup media')
        counted.add(id_)
        source = snapshot / 'media' / (id_ + '.' + ext)
        if not source.is_file() or source.is_symlink():
            raise ValueError('Media missing or unsafe')
        length, digest = sha256(source)
        if length != item['bytes'] or digest != item['sha256']:
            raise ValueError('Corrupt media: ' + id_)
        total += length
    return {'snapshot': str(snapshot), 'media': len(entries), 'bytes': total, 'version': manifest['appVersion']}


def recover(snapshot, output):
    info = verify(snapshot)
    snapshot, output = Path(snapshot), Path(output)
    if output.exists():
        raise FileExistsError('Output already exists, refusing to overwrite: ' + str(output))
    # Only write to a new folder outside original snapshot; stage then atomic rename.
    if snapshot.resolve() == output.resolve() or snapshot.resolve() in output.resolve().parents:
        raise ValueError('Recovery destination cannot be inside the snapshot')
    partial = output.with_name(output.name + '.partial')
    if partial.exists():
        raise FileExistsError('Partial recovery already exists; no files removed')
    partial.mkdir(parents=True)
    try:
        (partial / 'media').mkdir()
        shutil.copy2(snapshot / 'project-state.json', partial / 'project-state.json')
        shutil.copy2(snapshot / 'manifest.json', partial / 'manifest.json')
        manifest = json.loads((snapshot / 'manifest.json').read_text('utf-8'))
        for item in manifest['media']:
            name = item['id'] + '.' + item['ext']
            with (snapshot / 'media' / name).open('rb') as src, (partial / 'media' / name).open('xb') as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
        verify(partial)
        os.rename(partial, output)
        return dict(info, recovered_to=str(output))
    except Exception:
        # Keep any partial copy for inspection; original snapshot is always untouched.
        raise


def main():
    parser = argparse.ArgumentParser(description='Offline MMMN local snapshot verifier/recovery')
    sub = parser.add_subparsers(dest='mode', required=True)
    a = sub.add_parser('verify');a.add_argument('snapshot')
    b = sub.add_parser('recover');b.add_argument('snapshot');b.add_argument('output')
    args = parser.parse_args()
    result = verify(args.snapshot) if args.mode == 'verify' else recover(args.snapshot, args.output)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
