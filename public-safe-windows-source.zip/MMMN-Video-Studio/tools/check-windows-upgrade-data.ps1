# Manual Windows release QA only. Read-only verification: never deletes/uninstalls/updates files.
# Usage: powershell -File tools\check-windows-upgrade-data.ps1 -Mode Before -AppDataDir "C:\...\AppData\Local\..."
# Usage: powershell -File tools\check-windows-upgrade-data.ps1 -Mode After  -AppDataDir "C:\...\AppData\Local\..."
param(
  [Parameter(Mandatory=$true)][ValidateSet('Before','After')][string]$Mode,
  [Parameter(Mandatory=$true)][string]$AppDataDir,
  [string]$EvidenceDir = (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'MMMN-Upgrade-Audit')
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath $AppDataDir).Path
if (!(Test-Path -LiteralPath (Join-Path $root 'project-state.json') -PathType Leaf)) {
  throw 'Refusing audit: project-state.json is missing. Pick the storage folder shown in the app.'
}
$root=[System.IO.Path]::GetFullPath($root)
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null
$baseline=Join-Path $EvidenceDir 'before-upgrade.json'
function Get-Entries {
  $files=Get-ChildItem -LiteralPath $root -File -Recurse | Where-Object {
    # Exports, snapshots and in-progress imports are not overwritten by the app installer.
    # Audit the live project and imported media. Anything else is out-of-scope here.
    $relative=$_.FullName.Substring($root.Length).TrimStart('\','/') -replace '\\','/'
    ($relative -eq 'project-state.json') -or ($relative -match '^media/[^/]+$')
  }
  $rows=@()
  foreach ($f in $files) {
    $relative=$f.FullName.Substring($root.Length).TrimStart('\','/') -replace '\\','/'
    $rows+=@{relative=$relative;bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash}
  }
  return @($rows | Sort-Object relative)
}
if ($Mode -eq 'Before') {
  $entries=@(Get-Entries)
  [pscustomobject]@{format='mmmn-upgrade-proof-v1';root=$root;files=$entries;date=(Get-Date).ToString('o')} |
    ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $baseline -Encoding utf8
  Write-Host "Before-upgrade hashes saved outside AppData: $baseline ($($entries.Count) files)"
} else {
  if (!(Test-Path -LiteralPath $baseline -PathType Leaf)) { throw 'No before-upgrade baseline found.' }
  $expected=Get-Content -LiteralPath $baseline -Raw | ConvertFrom-Json
  if ($expected.format -ne 'mmmn-upgrade-proof-v1' -or $expected.root -ne $root) {
    throw 'Upgrade baseline was made for a different AppData folder.'
  }
  $actual=@{}; foreach($r in @(Get-Entries)){$actual[$r.relative]=$r}
  $errors=@()
  foreach ($old in $expected.files) {
    if (!$actual.ContainsKey($old.relative)) {$errors+="MISSING: $($old.relative)";continue}
    if ($old.bytes -ne $actual[$old.relative].bytes -or $old.sha256 -ne $actual[$old.relative].sha256){
      $errors+="CHANGED: $($old.relative)"
    }
  }
  if ($errors.Count) {$errors|ForEach-Object{Write-Error $_};throw 'UPGRADE DATA AUDIT FAIL. Do not delete original data; investigate or restore backup.'}
  Write-Host "UPGRADE DATA AUDIT PASS: $(@($expected.files).Count) pre-existing files retained with identical SHA256."
}
