"""MMMN Offline Studio: user-data-safe Windows trial install / in-place updater.

Run from the unpacked *source* folder, not from the installed program directory.
The program folder is %LOCALAPPDATA%/Programs/MMMN Video Studio Trial and is
purposefully distinct from the future NSIS production app directory. The user
project is always %LOCALAPPDATA%/MMMN-Video-Studio-Trial and is never migrated,
removed, replaced, or archived by this installer.

Uses Python stdlib only. Does not access the network or execute downloaded code.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import uuid

PROGRAM_NAME = 'MMMN Video Studio Trial'
DATA_NAME = 'MMMN-Video-Studio-Trial'
# Explicit allowlist: never ship test data, untrusted source artifacts or secrets.
PROGRAM_DIRS = ('web', 'renderer', 'portable')
PROGRAM_FILES = (
    'TRIAL-REVISION.txt', 'RUN-WINDOWS-TRIAL.cmd',
    'CHECK-WINDOWS-TRIAL.cmd', 'OPEN-EXPORTED-VIDEOS.cmd',
    'OPEN-PROJECT-AND-BACKUP-FOLDER.cmd',
)
REQUIRED = (
    'web/index.html', 'web/app.js', 'web/core.mjs',
    'web/resources/starter-project.json', 'renderer/render.py',
    'portable/studio_server.py', 'portable/launcher.py',
    'TRIAL-REVISION.txt', 'RUN-WINDOWS-TRIAL.cmd',
)
PROTECTED_NAMES = ('project-state.json', 'media', 'snapshots', 'exports')
VERSION_RE = re.compile(r'[a-zA-Z0-9._-]{1,80}\Z')
MANIFEST = 'INSTALL-MANIFEST.json'


class InstallError(Exception):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def files_in(root: Path):
    """Reject links (could escape the source root), skip bytecode/cache files."""
    for folder in PROGRAM_DIRS:
        entry = root / folder
        if not entry.is_dir() or entry.is_symlink():
            raise InstallError(f'Source folder not found or unsafe: {folder}')
        for path in sorted(entry.rglob('*')):
            if path.is_symlink():
                raise InstallError(f'Symlink forbidden in program package: {path}')
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                yield path.relative_to(root)
    for name in PROGRAM_FILES:
        entry = root / name
        if entry.is_file():
            if entry.is_symlink():
                raise InstallError(f'Symlink forbidden: {name}')
            yield Path(name)


def validate_source(root: Path):
    if not root.is_dir():
        raise InstallError(f'Source folder not found: {root}')
    for name in REQUIRED:
        entry = root / name
        if not entry.is_file() or entry.stat().st_size == 0 or entry.is_symlink():
            raise InstallError(f'Missing required program file: {name}')
    marker = (root / 'TRIAL-REVISION.txt').read_text(encoding='utf-8').strip()
    if not VERSION_RE.fullmatch(marker):
        raise InstallError('Unsafe or missing revision marker')
    if not list(files_in(root)):
        raise InstallError('Empty installation payload')
    return marker


def manifest_for(root: Path, revision: str) -> dict:
    manifest = {'application': PROGRAM_NAME, 'revision': revision, 'format': 1,
                'created_utc': datetime.now(timezone.utc).isoformat(), 'files': {}}
    for rel in files_in(root):
        item = root / rel
        manifest['files'][rel.as_posix()] = {
            'size': item.stat().st_size, 'sha256': sha256_file(item)
        }
    return manifest


def verify_payload(root: Path, manifest: dict):
    for relative, meta in manifest['files'].items():
        rel = Path(relative)
        if rel.is_absolute() or '..' in rel.parts:
            raise InstallError('Unsafe payload manifest entry')
        path = root / rel
        if not path.is_file() or path.stat().st_size != meta['size'] or sha256_file(path) != meta['sha256']:
            raise InstallError(f'Incomplete or corrupt installation payload: {relative}')
    for name in REQUIRED:
        if not (root / name).is_file():
            raise InstallError(f'Incomplete installation: {name}')


def install_paths() -> tuple[Path, Path]:
    if os.name != 'nt':
        raise InstallError('One-click installation is intended for Windows 11/10')
    localappdata = os.environ.get('LOCALAPPDATA')
    if not localappdata:
        raise InstallError('LOCALAPPDATA is missing')
    local = Path(localappdata).resolve()
    return local / 'Programs' / PROGRAM_NAME, local / DATA_NAME


@contextmanager
def updater_lock(parent: Path):
    """Lock the updater across processes; never unlink a locked inode."""
    parent.mkdir(parents=True, exist_ok=True)
    lockpath = parent / '.mmmn-trial-updater.lock'
    with lockpath.open('a+b') as stream:
        if stream.seek(0, os.SEEK_END) == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            try:
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as exc:
                raise InstallError('An MMMN update is already running') from exc
            try:
                yield
            finally:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            try:
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as exc:
                raise InstallError('An MMMN update is already running') from exc
            try:
                yield
            finally:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


@contextmanager
def check_studio_closed(data_dir: Path):
    """Use exactly the same per-data-folder lock as studio_server.py."""
    import importlib.util
    server_file = Path(__file__).resolve().parent.parent / 'portable' / 'studio_server.py'
    spec = importlib.util.spec_from_file_location('mmmn_updater_studio_server', server_file)
    if spec is None or spec.loader is None:
        raise InstallError('Cannot load studio locking code')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    try:
        with module.one_running_studio(data_dir):
            yield
    except RuntimeError as exc:
        raise InstallError('Close MMMN Video Studio before installing an update; your files were not changed.') from exc


def prepare_stage(source: Path, stage: Path, revision: str, previous: Path | None = None):
    stage.mkdir(parents=True, exist_ok=False)
    for rel in files_in(source):
        output = stage / rel
        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / rel, output)
    # Preserve manually installed FFmpeg tools across source-package updates.
    # Only explicit filenames are carried; do not copy old application code.
    if previous and previous.is_dir():
        for tool in ('ffmpeg.exe', 'ffprobe.exe'):
            old = previous / 'portable' / 'bin' / tool
            new = stage / 'portable' / 'bin' / tool
            if old.is_file() and not old.is_symlink() and not new.exists():
                new.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(old, new)
    manifest = manifest_for(stage, revision)
    # Manifest must cover the optional carried-over FFmpeg binaries too.
    for tool in ('ffmpeg.exe', 'ffprobe.exe'):
        rel = Path('portable/bin') / tool
        item = stage / rel
        if item.is_file() and rel.as_posix() not in manifest['files']:
            manifest['files'][rel.as_posix()] = {'size': item.stat().st_size,
                                               'sha256': sha256_file(item)}
    (stage / MANIFEST).write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
    verify_payload(stage, manifest)
    return manifest


def shortcut(destination: Path) -> str | None:
    """Best-effort Windows Start Menu link; failure never rolls back valid files."""
    if os.name != 'nt':
        return None
    appdata = os.environ.get('APPDATA')
    if not appdata:
        return 'APPDATA missing; Start Menu shortcut was not created'
    menu = Path(appdata) / 'Microsoft' / 'Windows' / 'Start Menu' / 'Programs'
    menu.mkdir(parents=True, exist_ok=True)
    link = menu / 'MMMN Video Studio Trial.lnk'
    target = destination / 'RUN-WINDOWS-TRIAL.cmd'
    env = dict(os.environ, MMMN_SHORTCUT_TARGET=str(target),
               MMMN_SHORTCUT_DEST=str(link), MMMN_SHORTCUT_WORKDIR=str(destination))
    powershell = shutil.which('powershell.exe')
    if not powershell:
        return 'PowerShell unavailable; launch the installed RUN-WINDOWS-TRIAL.cmd directly'
    script = ('$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:MMMN_SHORTCUT_DEST); '
              '$s.TargetPath=$env:MMMN_SHORTCUT_TARGET; '
              '$s.WorkingDirectory=$env:MMMN_SHORTCUT_WORKDIR; '
              '$s.Description="Offline MMMN Video Studio Trial"; $s.Save()')
    try:
        result = subprocess.run([powershell, '-NoProfile', '-NonInteractive', '-Command', script],
                                capture_output=True, text=True, timeout=15, env=env)
        if result.returncode:
            return 'Start Menu shortcut could not be created: ' + result.stderr[:200]
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 'Start Menu shortcut could not be created: ' + str(exc)[:200]
    return None


def install(source: Path, destination: Path, data_dir: Path, *, staging_hook=None):
    """Atomic program-folder upgrade; data directory is immutable to the updater.

    If installation fails at any point, the old program folder is restored.
    Previous version remains beside the program directory for manual rollback.
    The caller holds the updater lock plus the studio data lock.
    """
    source, destination, data_dir = source.resolve(), destination.resolve(), data_dir.resolve()
    if destination == data_dir or destination in data_dir.parents or data_dir in destination.parents:
        raise InstallError('Program folder and user-data folder must be separate')
    if destination == source or source in destination.parents or destination in source.parents:
        raise InstallError('Run the updater from a separate unpacked ZIP, not from the installed program folder')
    if any(part in ('web', 'portable', 'renderer') for part in destination.parts[-2:]):
        raise InstallError('Unsafe program installation target')
    revision = validate_source(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    previous = destination.with_name(destination.name + '.previous')
    # If power failed after an old program was renamed out of the way, restore
    # the last verified program before attempting any new installation.
    if not destination.exists() and previous.is_dir():
        old_manifest_path = previous / MANIFEST
        if not old_manifest_path.is_file():
            raise InstallError('Interrupted upgrade found an unverified previous install; manual review required')
        old_manifest = json.loads(old_manifest_path.read_text(encoding='utf-8'))
        verify_payload(previous, old_manifest)
        previous.rename(destination)
    stage = destination.with_name(destination.name + '.pending-' + uuid.uuid4().hex[:12])
    old_archive = None
    old_was_renamed = False
    previous_was_archived = False
    try:
        manifest = prepare_stage(source, stage, revision, destination if destination.exists() else None)
        if staging_hook:
            staging_hook(stage)
        verify_payload(stage, manifest)
        # Do not replace program files if destination is clearly not ours.
        if destination.exists() and not (destination / MANIFEST).is_file():
            raise InstallError('Existing folder has no MMMN install manifest. Refusing to overwrite unknown files.')
        if previous.exists():
            old_archive = destination.with_name(destination.name + '.older-' + uuid.uuid4().hex[:8])
            previous.rename(old_archive)
            previous_was_archived = True
        if destination.exists():
            destination.rename(previous)
            old_was_renamed = True
        try:
            stage.rename(destination)
            verify_payload(destination, manifest)
        except Exception:
            if destination.exists():
                # This is a staging folder populated ONLY by this updater.
                shutil.rmtree(destination)
            if old_was_renamed and previous.is_dir():
                previous.rename(destination)
            if previous_was_archived and old_archive is not None:
                old_archive.rename(previous)
            raise
        # Successful upgrade: preserve latest previous program and optional older.
        return {'status': 'PASS', 'revision': revision,
                'installed_to': str(destination), 'user_data_untouched': str(data_dir),
                'previous_program': str(previous) if previous.is_dir() else None,
                'file_count': len(manifest['files'])}
    except Exception:
        # Preserve original install if rename hasn't started / failed.
        if old_was_renamed and not destination.exists() and previous.is_dir():
            previous.rename(destination)
        if previous_was_archived and old_archive is not None and old_archive.exists() and not previous.exists():
            old_archive.rename(previous)
        raise
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def rollback(destination: Path, data_dir: Path):
    destination, data_dir = destination.resolve(), data_dir.resolve()
    previous = destination.with_name(destination.name + '.previous')
    if not previous.is_dir() or not (previous / MANIFEST).is_file():
        raise InstallError('No previous installed version is available for rollback')
    previous_manifest = json.loads((previous / MANIFEST).read_text(encoding='utf-8'))
    verify_payload(previous, previous_manifest)
    broken = destination.with_name(destination.name + '.rollback-saved-' + uuid.uuid4().hex[:8])
    if destination.is_dir():
        destination.rename(broken)
    try:
        previous.rename(destination)
    except Exception:
        if broken.is_dir():
            broken.rename(destination)
        raise
    return {'status': 'PASS', 'restored_revision': previous_manifest['revision'],
            'installed_to': str(destination), 'newer_program_saved': str(broken) if broken.is_dir() else None,
            'user_data_untouched': str(data_dir)}


def verify_installed(destination: Path, data_dir: Path):
    if not destination.is_dir():
        raise InstallError('MMMN Windows Trial is not installed in this user account')
    file = destination / MANIFEST
    if not file.is_file():
        raise InstallError('Installed application manifest is missing')
    manifest = json.loads(file.read_text(encoding='utf-8'))
    if manifest.get('application') != PROGRAM_NAME or not VERSION_RE.fullmatch(str(manifest.get('revision', ''))):
        raise InstallError('Invalid installed application identity')
    verify_payload(destination, manifest)
    return {'status': 'PASS', 'revision': manifest['revision'],
            'verified_program_files': len(manifest['files']),
            'installed_to': str(destination),
            'user_data_folder': str(data_dir),
            'user_data_was_not_accessed': True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rollback', action='store_true')
    parser.add_argument('--verify-installed', action='store_true')
    args = parser.parse_args()
    if os.name != 'nt':
        print('This installer must be started on Windows 10/11.', file=sys.stderr)
        return 1
    source = Path(__file__).resolve().parent.parent
    try:
        dest, data = install_paths()
        with updater_lock(dest.parent):
            if args.verify_installed:
                result = verify_installed(dest, data)
            else:
                with check_studio_closed(data):
                    result = rollback(dest, data) if args.rollback else install(source, dest, data)
        note = None if args.verify_installed else shortcut(dest)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if note:
            print('NOTE:', note)
        print('The original manuscript, recordings, pictures, projects and backups were NOT changed.')
        print('Open MMMN Video Studio Trial from your Start Menu or the installed RUN-WINDOWS-TRIAL.cmd.')
        return 0
    except (InstallError, OSError, ValueError, KeyError) as exc:
        print('MMMN UPDATE STOPPED SAFELY:', str(exc), file=sys.stderr)
        print('Your project and media were not removed.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
