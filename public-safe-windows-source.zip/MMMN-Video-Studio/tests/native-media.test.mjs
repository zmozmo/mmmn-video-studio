import test from 'node:test';
import assert from 'node:assert/strict';
import {makeNativeMedia,extensionFor,NATIVE_CHUNK_BYTES} from '../web/native-media.mjs';
function mockNative(){
 const buf=[],meta={}; let aborted=0;
 const invoke=async(name,payload,opts)=>{
  if(name==='begin_media_import'){if(meta.id)throw Error('collision');Object.assign(meta,payload);return null;}
  if(name==='import_media_chunk'){
   const offset=Number(opts.headers['x-media-offset']);
   if(opts.headers['x-media-id']!==meta.id)throw Error('wrong id');
   if(offset!==buf.reduce((n,x)=>n+x.length,0))throw Error('bad offset');
   buf.push(payload);return offset+payload.length;
  }
  if(name==='finalize_media_import'){
   assert.equal(buf.reduce((n,x)=>n+x.length,0),meta.total);return {path:`C:/LocalAppData/media/${meta.id}.${meta.ext}`,size:meta.total,id:meta.id,ext:meta.ext,sha256:"a".repeat(64)};
  }
  if(name==='get_media_info')return {path:`C:/LocalAppData/media/${payload.id}.${payload.ext}`,size:100};
  if(name==='abort_media_import'){aborted++;return null;}
  throw Error('Unknown command '+name);
 };
 return {tauri:{core:{invoke,convertFileSrc:path=>`asset://${path}`}},meta,buf,get aborted(){return aborted;}};
}
test('extension validation excludes executable and unsupported types',()=>{
 assert.equal(extensionFor('chapter.MOV','video/quicktime'),'mov');
 assert.equal(extensionFor('photo','image/jpeg'),'jpg');
 assert.throws(()=>extensionFor('run.exe','application/octet-stream'),/Unsupported/);
});
test('2.3 MiB File is imported through bounded ordered chunks and finalized once',async()=>{
 const mock=mockNative(),media=makeNativeMedia(mock.tauri);
 const file=new Blob([new Uint8Array(2*NATIVE_CHUNK_BYTES+123)],{type:'video/mp4'});
 const progress=[];
 const result=await media.store('video-uuid-abcdef',file,'recording.mp4',(n,total)=>progress.push([n,total]));
 assert.equal(result.size,file.size);assert.equal(mock.buf.length,3);
 assert.ok(mock.buf.every(x=>x.byteLength<=NATIVE_CHUNK_BYTES));
 assert.deepEqual(progress.at(-1),[file.size,file.size]);
 assert.equal(mock.aborted,0);
});
test('disk-write failure aborts partial import and never pretends storage succeeded',async()=>{
 const mock=mockNative(),base=mock.tauri.core.invoke;
 mock.tauri.core.invoke=async (name,...args)=>name==='import_media_chunk'?Promise.reject(Error('disk full')):base(name,...args);
 const media=makeNativeMedia(mock.tauri);
 await assert.rejects(media.store('video-uuid-abc123',new Blob([new Uint8Array(10)],{type:'video/mp4'}),'read.mp4'),/disk full/);
 assert.equal(mock.aborted,1);
});
test('native media paths are converted to asset URLs',async()=>{
 const media=makeNativeMedia(mockNative().tauri);
 assert.equal(media.url('C:/LocalAppData/media/file.png'),'asset://C:/LocalAppData/media/file.png');
 assert.deepEqual(await media.info('asset-123456','image.png','image/png'),{path:'C:/LocalAppData/media/asset-123456.png',size:100});
});
test('browser preview keeps native-only commands disabled',()=>{
 assert.equal(makeNativeMedia(undefined).available,false);
});
