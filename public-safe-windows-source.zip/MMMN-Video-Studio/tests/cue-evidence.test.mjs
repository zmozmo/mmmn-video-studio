import test from 'node:test';
import assert from 'node:assert/strict';
import {buildNarrationCueMap, proposeNarrationBoundaries, cueEvidenceCSV} from '../web/core.mjs';
const scenes=[
 {id:'s1',text:'ရန်ကုန်မြို့ နံနက်ခင်းမှာ ကားလမ်းပေါ် လူတွေ လမ်းလျှောက်နေကြသည်။',start:0,duration:10,alignment:'estimated'},
 {id:'s2',text:'လက်ဖက်ရည်ဆိုင်အတွင်း လက်ဖက်ရည်သောက်နေကြသည်။',start:10,duration:10,alignment:'estimated'},
 {id:'s3',text:'လှေငယ်ဖြင့် ပင်လယ်ခရီးထွက်ပြီး ဂူဝင်ပေါက်ကို တွေ့ကြသည်။',start:20,duration:10,alignment:'estimated'},
];
const cues=[
 {start:0.25,end:2.4,text:'ရန်ကုန်မြို့ နံနက်ခင်းမှာ'},
 {start:4,end:6,text:'ကားလမ်းပေါ် လူတွေ လမ်းလျှောက်နေကြသည်။'},
 {start:11,end:14,text:'လက်ဖက်ရည်ဆိုင်အတွင်း လက်ဖက်ရည်သောက်နေကြသည်။'},
 {start:23,end:27,text:'လှေငယ်ဖြင့် ပင်လယ်ခရီးထွက်ပြီး ဂူဝင်ပေါက်ကို တွေ့ကြသည်။'},
];
test('chronological text finds story-specific tea shop and boat evidence',()=>{
 const m=buildNarrationCueMap(scenes,cues);
 assert.equal(m.matched,4);assert.equal(m.exact,4);assert.equal(m.unmatched,0);
 assert.deepEqual(m.evidence.map(e=>e.first),[.25,11,23]);
 assert.deepEqual(m.evidence.map(e=>e.cueCount),[2,1,1]);
});
test('proposed SRT boundaries follow recording and retain exact chapter duration',()=>{
 const r=proposeNarrationBoundaries(scenes,cues,30);
 assert.equal(r.proposed,2);
 assert.ok(Math.abs(r.scenes[1].start-11)<.001);
 assert.ok(Math.abs(r.scenes[2].start-23)<.001);
 assert.ok(Math.abs(r.scenes.reduce((n,s)=>n+s.duration,0)-30)<.002);
 assert.equal(r.scenes[1].alignment,'srt-proposed');
});
test('manual-locked boundaries cannot be silently overridden',()=>{
 const protectedScenes=scenes.map(s=>({...s}));
 protectedScenes[1].start=9;protectedScenes[1].alignment='manual-locked';
 protectedScenes[0].duration=9;protectedScenes[1].duration=11;
 const r=proposeNarrationBoundaries(protectedScenes,cues,30);
 assert.equal(r.scenes[1].start,9);
 assert.equal(r.scenes[1].alignment,'manual-locked');
 assert.equal(r.scenes[2].start,23);
});
test('unrelated subtitles are rejected, not pretended to match',()=>{
 const bad=[{start:1,end:2,text:'abcdefghijklmnopqrstuvwxyz abcdefghij'}];
 const r=proposeNarrationBoundaries(scenes,bad,30);
 assert.equal(r.matched,0);assert.equal(r.proposed,0);
 assert.deepEqual(r.scenes.map(x=>x.start),scenes.map(x=>x.start));
});
test('subtitle evidence report quotes Burmese dialogue and commas correctly',()=>{
 const map=buildNarrationCueMap(scenes,cues);
 const csv=cueEvidenceCSV({number:1,scenes},map);
 assert.ok(csv.startsWith('\uFEFF'));
 assert.match(csv,/လက်ဖက်ရည်ဆိုင်အတွင်း/);
 assert.match(csv,/Review required/);
});
test('corrupt manual anchor returns warning, no changes',()=>{
 const s=scenes.map(x=>({...x}));s[1].alignment='manual-locked';s[1].start=29.9;
 const r=proposeNarrationBoundaries(s,cues,30);
 assert.ok(r.error);
 assert.equal(r.scenes[1].start,29.9);
});
test('zero cues and zero scenes do not crash',()=>{
 assert.equal(buildNarrationCueMap([],cues).matched,0);
 assert.equal(proposeNarrationBoundaries([],[],0).proposed,0);
});
