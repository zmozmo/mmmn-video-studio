import {test} from 'node:test';
import {strict as assert} from 'node:assert';
import {imageCreationBrief} from '../web/visual-brief.mjs';
const basic={title:'ငှက်အော်ကျွန်း',visualRequirements:[
  {id:'BI-001',chapter:1,description:'ရန်ကုန်လက်ဖက်ရည်ဆိုင်',promptGuide:'1971 Myanmar tea shop',status:'not-created'},
  {id:'BI-002',chapter:1,description:'ဟောင်းနွမ်းသောမြေပုံ',status:'not-created'},
  {id:'BI-003',chapter:2,description:'ဂူ',status:'local-ready'}],assets:[{type:'image/png',name:'BI-002.png'}]};
test('brief only includes missing unique chapter picture IDs',()=>{
 const result=imageCreationBrief(basic,1);
 assert.equal(result.total,2);assert.equal(result.missing,1);
 assert.match(result.text,/BI-001.png/);
 assert.doesNotMatch(result.text,/### BI-002.png/);
 assert.doesNotMatch(result.text,/### BI-003.png/);
});
test('all chapter brief does not require local-ready artwork',()=>{
 const result=imageCreationBrief(basic);
 assert.equal(result.total,3);assert.equal(result.missing,1);
 assert.match(result.text,/Offline Image Creation Brief/);
 assert.match(result.text,/1971 Myanmar tea shop/);
});
test('cannot create prompt pack from missing plan',()=>{
 assert.throws(()=>imageCreationBrief({}),/missing/);
});
