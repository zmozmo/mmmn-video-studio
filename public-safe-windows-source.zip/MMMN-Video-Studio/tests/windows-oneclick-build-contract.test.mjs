import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = path => readFileSync(new URL('../' + path, import.meta.url), 'utf8');

test('Windows user can launch an offline portable executable build from one CMD file', () => {
  const cmd = read('BUILD-WINDOWS-PORTABLE-EXE.cmd');
  const ps = read('scripts/build-portable-windows.ps1');
  assert.match(cmd, /powershell\.exe .*build-portable-windows\.ps1/i);
  assert.match(ps, /pyinstaller/i);
  assert.match(ps, /--onedir/);
  assert.match(ps, /--self-test/);
  assert.match(ps, /windows-portable-output/i);
});

test('Local builder isolates its dependencies, tests before release, and never creates setup.exe', () => {
  const ps=read('scripts/build-portable-windows.ps1');
  assert.match(ps, /-m','venv'/);
  assert.match(ps, /Run all JavaScript regression tests/);
  assert.match(ps, /Run Python and end-to-end local backend tests/);
  assert.match(ps, /--add-data','portable\/bin;portable\/bin'/);
  assert.doesNotMatch(ps, /makensis/i);
  assert.doesNotMatch(ps, /Remove-Item\s+.*LOCALAPPDATA/i);
});

test('Windows CI validates actual bundled exe and will not publish partial build', () => {
  const wf=read('.github/workflows/windows-portable-exe-manual.yml');
  assert.match(wf, /runs-on: windows-latest/);
  assert.match(wf, /choco install ffmpeg/);
  assert.match(wf, /--self-test/);
  assert.match(wf, /Invoke-WebRequest/);
  assert.match(wf, /actions\/upload-artifact@v4/);
  assert.match(wf, /if-no-files-found: error/);
});

test('Windows installer preserves user data and contains upgrade identity', () => {
  const nsi=read('windows-installer/MMMN-Video-Studio.nsi');
  assert.match(nsi, /InstallDir "\$LOCALAPPDATA\\Programs\\MMMN Video Studio"/);
  assert.match(nsi, /WriteRegStr HKCU "\$\{UNINSTALL_KEY\}" "DisplayVersion"/);
  assert.doesNotMatch(nsi, /RMDir \/r "\$LOCALAPPDATA\\MMMN-Video-Studio-Trial"/);
  assert.match(nsi, /RequestExecutionLevel user/);
});
