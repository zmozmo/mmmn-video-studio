"""Optional Chromium UI smoke test WITHOUT browser network or user data.

We deliberately do not call this a Windows installed-app test. It exercises the
actual UI JavaScript using a generated module bundle, an in-memory native bridge
and a disposable about:blank Chromium page. Google Drive is never contacted.

Run (in a dev environment with Playwright + Chromium):
  python tests/offline_ui_inmemory_smoke.py
"""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]

PRELUDE = '''
const memory={};
Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem(k){return memory[k]??null},setItem(k,v){memory[k]=String(v)},removeItem(k){delete memory[k]}}});
const fakeDB={createObjectStore(){},transaction(){return {objectStore(){return {get(){return {result:null}},put(){return {}}}}}}};
Object.defineProperty(window,'indexedDB',{configurable:true,value:{open(){const req={result:fakeDB};queueMicrotask(()=>req.onsuccess?.());return req;}}});
window.__MMMN_TRIAL__=true;
window.__TAURI__={core:{convertFileSrc(path){return path},async invoke(command,args){
 if(command==='load_project_state')return null;
 if(command==='project_storage_info')return {path:'IN-MEMORY-SMOKE-TEST',hasProject:false};
 if(command==='save_project_state')return null;
 if(command==='list_local_exports')return [];
 if(command==='current_render_job')return null;
 if(command==='render_cache_info')return {files:2,bytes:3145728,maxBytes:2147483648};
 if(command==='clear_render_cache')return {removedCacheFiles:4,originalMediaPreserved:true};
 if(command==='list_local_backups')return [];
 throw Error('Unmocked native call: '+command);
 }}};
window.alert=()=>{};window.confirm=()=>true;
'''

def run():
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as e:
        raise RuntimeError('Playwright not installed. This optional UI test was NOT run.') from e
    if not shutil.which('node'):
        raise RuntimeError('Node.js required to bundle UI for in-memory browser testing')
    html=(ROOT/'web'/'index.html').read_text(encoding='utf-8')
    html=html.replace('<script type="module" src="app.js"></script>','')
    project=json.loads((ROOT/'web'/'resources'/'starter-project.json').read_text(encoding='utf-8'))
    prelude=PRELUDE+"window.fetch=async function(uri) {if(uri==='resources/starter-project.json')return {ok:true,json:async()=>("+json.dumps(project,ensure_ascii=False)+")};throw Error('Unexpected network request '+uri);};"
    with tempfile.TemporaryDirectory(prefix='mmmn-ui-no-network-') as work:
        dest=Path(work)/'ui-bundle.js'
        subprocess.run(['node',str(ROOT/'scripts/bundle-ui-for-test.mjs'),str(dest)],check=True,capture_output=True)
        with sync_playwright() as p:
            path=Path(os.getenv('MMMN_UI_CHROMIUM','/usr/bin/chromium'))
            options={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
            if path.is_file():options['executable_path']=str(path)
            browser=p.chromium.launch(**options)
            page=browser.new_page(viewport={'width':1300,'height':850})
            page.set_default_timeout(5000)
            errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            try:
                page.set_content(html,wait_until='domcontentloaded')
                page.add_style_tag(content=(ROOT/'web'/'style.css').read_text(encoding='utf-8'))
                page.add_script_tag(content=prelude)
                page.add_script_tag(content=dest.read_text(encoding='utf-8'))
                page.get_by_role('heading',name='Project Dashboard').wait_for()
                assert page.locator('[data-select-chapter]').count()==22, 'Starter book should have 22 chapter controls'
                page.locator('[data-tab="timeline"]').first.click()
                assert 'Narration Timeline' in page.locator('body').inner_text()
                page.locator('[data-tab="export"]').first.click()
                assert page.locator('[data-action="render-native-current"]').count()==1
                page.locator('[data-tab="updates"]').first.click()
                assert page.get_by_text('Offline Render Cache').count()==1
                page.locator('[data-action="refresh-render-cache"]').click()
                assert page.get_by_text('3 MiB / 2 files').count()==1
                page.locator('[data-action="clear-render-cache"]').click()
                assert 'Cleared 4 temporary cache files' in page.locator('body').inner_text()
                if errors: raise AssertionError('Browser JavaScript errors: '+str(errors))
                output=os.environ.get('MMMN_UI_SCREENSHOT')
                if output:page.screenshot(path=output,full_page=False)
                print('PASS: in-memory Chromium UI, 22 chapters, Timeline, Export, Updates, cache check/clear, no JS errors')
                print('Scope: UI logic only; NOT installed Windows EXE, no real browser network or media import')
            finally:browser.close()

if __name__=='__main__':
    try:run()
    except Exception as e:
        print('OFFLINE UI SMOKE FAIL:',e,file=sys.stderr)
        raise SystemExit(1)
