import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {makeNativeMedia} from '../web/native-media.mjs';
test('verification checks native SHA256 and never uploads file',async()=>{
 const calls=[];const tauri={core:{convertFileSrc:v=>v,invoke:async(cmd,args)=>{calls.push([cmd,args]);return {verified:true};}}};
 const receipt=await makeNativeMedia(tauri).verify('vid-999999','recording.mp4','video/mp4','a'.repeat(64));
 assert.equal(receipt.verified,true);
 assert.deepEqual(calls,[['verify_native_media',{id:'vid-999999',ext:'mp4',expectedSha256:'a'.repeat(64)}]]);
});
test('file integrity checks happen in a worker and compare to immutable imported checksum',()=>{
 const rust=fs.readFileSync('src-tauri/src/lib.rs','utf8');
 const ui=fs.readFileSync('web/app.js','utf8');
 assert.match(rust,/async fn verify_native_media/);
 assert.match(rust,/verify_media_file_inner\(&app,id,ext,expected_sha256\)/);
 assert.match(rust,/Media SHA256 mismatch/);
 assert.match(ui,/asset\.sha256\)await nativeMedia\.verify/);
});
