"""Linux/Mac regression for installer witness logic; real Windows NSIS upgrade is CI-only."""
from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

SOURCE=Path(__file__).resolve().parent.parent

class InstallerWitnessContractTest(unittest.TestCase):
    @unittest.skipUnless(os.name=='posix' and shutil.which('ffmpeg') and shutil.which('ffprobe'),
                         'Requires POSIX shim and FFmpeg test dependencies')
    def test_saved_project_media_restore_and_render_witness(self):
        with tempfile.TemporaryDirectory(prefix='mmmn-upgrade-witness-') as temp:
            root=Path(temp)
            deployed=root/'version-source'
            (deployed/'portable/bin').mkdir(parents=True)
            (deployed/'src-tauri/icons').mkdir(parents=True)
            shutil.copy(SOURCE/'portable/studio_server.py',deployed/'portable/studio_server.py')
            shutil.copy(SOURCE/'src-tauri/icons/32x32.png',deployed/'src-tauri/icons/32x32.png')
            (deployed/'web').symlink_to(SOURCE/'web',target_is_directory=True)
            (deployed/'renderer').symlink_to(SOURCE/'renderer',target_is_directory=True)
            (deployed/'portable/bin/ffmpeg.exe').symlink_to(shutil.which('ffmpeg'))
            (deployed/'portable/bin/ffprobe.exe').symlink_to(shutil.which('ffprobe'))
            # windows_installer_probe.py gets fixture PNG from its own source root;
            # the temporary executable mimics exactly where a PyInstaller EXE lives.
            exe=root/'installed/MMMN-Video-Studio.exe'
            exe.parent.mkdir()
            (exe.parent/'_internal/portable/bin').mkdir(parents=True)
            (exe.parent/'_internal/portable/bin/ffmpeg.exe').symlink_to(shutil.which('ffmpeg'))
            (exe.parent/'_internal/portable/bin/ffprobe.exe').symlink_to(shutil.which('ffprobe'))
            exe.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{deployed / "portable/studio_server.py"}" --no-browser\n')
            exe.chmod(0o755)
            data=root/'isolated-data'
            probe=SOURCE/'tests/windows_installer_probe.py'
            for phase,revision in [('before','installer-lab-base'),('after','installer-lab-upgrade')]:
                (deployed/'TRIAL-REVISION.txt').write_text(revision)
                run=subprocess.run([sys.executable,str(probe),phase,'--exe',str(exe),'--data-dir',str(data)],
                                   capture_output=True,text=True,timeout=75)
                self.assertEqual(run.returncode,0,run.stdout+'\n'+run.stderr)
            self.assertTrue(list((data/'MMMN-Video-Studio-Trial'/'preupgrade-metadata').glob('*.json')))
            self.assertTrue(list((data/'MMMN-Video-Studio-Trial'/'exports').glob('chapter-*.mp4')))

if __name__=='__main__':unittest.main()
