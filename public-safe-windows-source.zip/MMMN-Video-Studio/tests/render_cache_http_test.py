"""Real local HTTP tests for the optional cache-management UI bridge."""
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request,urlopen
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('studio_cache_http',ROOT/'portable'/'studio_server.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class CacheHttpTests(unittest.TestCase):
 def test_token_protection_and_cache_endpoints(self):
  with tempfile.TemporaryDirectory() as folder:
   s=mod.Studio(Path(folder),'token-value')
   server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(s))
   thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
   base=f'http://127.0.0.1:{server.server_address[1]}'
   def post(command,token=None):
    headers={'Content-Type':'application/json'}
    if token:headers['X-MM-Token']=token
    req=Request(base+'/__api/'+command,b'{}',headers,'POST')
    with urlopen(req,timeout=4) as response:
     return json.loads(response.read())['result']
   try:
    with self.assertRaises(HTTPError) as unauthorized:
     post('render_cache_info')
    self.assertEqual(unauthorized.exception.code,403)
    self.assertEqual(post('render_cache_info','token-value')['files'],0)
    key='d'*64;cache=s.root/'render-cache'
    (cache/f'scene-{key}.mp4').write_bytes(b'not a real scene')
    (cache/f'scene-{key}.json').write_text('{}')
    s._active_render_job='render-in-progress'
    with self.assertRaises(HTTPError) as blocked:
     post('clear_render_cache','token-value')
    self.assertEqual(blocked.exception.code,400)
    self.assertTrue((cache/f'scene-{key}.mp4').exists())
    s._active_render_job=None
    result=post('clear_render_cache','token-value')
    self.assertEqual(result['removedCacheFiles'],2)
    self.assertTrue(result['originalMediaPreserved'])
    self.assertEqual(post('render_cache_info','token-value')['files'],0)
   finally:
    server.shutdown();server.server_close();thread.join(timeout=5)

if __name__=='__main__':unittest.main()
