import test from 'node:test';
import assert from 'node:assert/strict';
import {applyPauseTimingPlan} from '../web/core.mjs';
const chapter={id:'ch1',number:1,recordedSeconds:12,scenes:[
 {id:'s1',text:'ရန်ကုန် လမ်းမ',start:0,duration:4,alignment:'estimated'},
 {id:'s2',text:'လက်ဖက်ရည်ဆိုင်',start:4,duration:4,alignment:'estimated'},
 {id:'s3',text:'ခရီးထွက်',start:8,duration:4,alignment:'estimated'}
]};
const plan={schema:'mmmn.pause-timing.v1',humanReviewRequired:true,chapterId:'ch1',chapterNumber:1,duration:12,pauseCount:2,
 scenes:[
 {sceneId:'s1',index:0,start:0,end:4.3,status:'start'},
 {sceneId:'s2',index:1,start:4.3,end:8.6,status:'pause-proposed',note:'near pause'},
 {sceneId:'s3',index:2,start:8.6,end:12,status:'length-estimated',note:'length'}
 ]};
test('import pause plan without altering original, frame length and proposed status',()=>{
 const r=applyPauseTimingPlan(chapter,plan);
 assert.equal(r.scenes[1].start,4.3);
 assert.equal(r.scenes[1].alignment,'pause-proposed');
 assert.equal(r.scenes[2].timingNeedsReview,true);
 assert.equal(r.proposed,1);
 assert.ok(Math.abs(r.scenes.reduce((n,x)=>n+x.duration,0)-12)<1e-6);
 assert.equal(chapter.scenes[1].start,4);
});
test('reject incorrect chapter, stale scene count and fake approved plan',()=>{
 assert.throws(()=>applyPauseTimingPlan(chapter,{...plan,chapterNumber:2}),/Wrong chapter/);
 assert.throws(()=>applyPauseTimingPlan(chapter,{...plan,scenes:plan.scenes.slice(0,2)}),/Shot count differs/);
 assert.throws(()=>applyPauseTimingPlan(chapter,{...plan,humanReviewRequired:false}),/human review/);
});
test('reject wrong media duration and corrupted timeline gaps',()=>{
 assert.throws(()=>applyPauseTimingPlan(chapter,{...plan,duration:30}),/duration differs/);
 const bad=structuredClone(plan);bad.scenes[1].start=4.9;
 assert.throws(()=>applyPauseTimingPlan(chapter,bad),/gap or overlap/);
});
test('manual lock and SRT boundary are never overridden',()=>{
 const locked=structuredClone(chapter);locked.scenes[1].alignment='manual-locked';
 assert.throws(()=>applyPauseTimingPlan(locked,plan),/manual lock/);
 const srt=structuredClone(chapter);srt.scenes[1].alignment='srt-proposed';
 assert.throws(()=>applyPauseTimingPlan(srt,plan),/SRT evidence/);
});
test('approved manual timing can be retained if plan agrees',()=>{
 const locked=structuredClone(chapter);locked.scenes[1].alignment='manual-locked';locked.scenes[1].start=4.3;
 const r=applyPauseTimingPlan(locked,plan);
 assert.equal(r.scenes[1].alignment,'manual-locked');
});
import {reconcileRecordingDuration} from '../web/core.mjs';
test('new narrator recording preserves previously approved boundaries',()=>{
 const c=structuredClone(chapter);c.scenes[1].alignment='manual-locked';
 const r=reconcileRecordingDuration(c,15);
 assert.equal(r.rebalanced,false);assert.equal(r.needsReview,true);
 assert.equal(r.scenes[1].start,4);
});
test('estimated-only timeline rebalances to new narration length',()=>{
 const c=structuredClone(chapter);
 const r=reconcileRecordingDuration(c,15);
 assert.equal(r.rebalanced,true);
 assert.ok(Math.abs(r.scenes.reduce((n,s)=>n+s.duration,0)-15)<.01);
});
test('unchanged narration length preserves timings and review status',()=>{
 const r=reconcileRecordingDuration(chapter,12);
 assert.equal(r.rebalanced,false);assert.equal(r.needsReview,false);
});
