import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

test('native streaming media import hashes each raw chunk before disk append',()=>{
 const rust=fs.readFileSync('src-tauri/src/lib.rs','utf8');
 const js=fs.readFileSync('web/native-media.mjs','utf8');
 assert.match(js,/chunkSha256\(chunk\)/);
 assert.match(js,/'x-media-sha256':checksum/);
 assert.match(rust,/chunk_hash_matches\(bytes, expected_chunk_hash\)/);
 assert.ok(rust.indexOf('chunk_hash_matches(bytes, expected_chunk_hash)')<rust.indexOf('file.write_all(bytes)'));
});
test('Windows upgrade retains valid staged/older local project copies',()=>{
 const rust=fs.readFileSync('src-tauri/src/lib.rs','utf8');
 assert.match(rust,/project-state.older.json/);
 assert.match(rust,/pending.sync_all\(\)/);
 assert.match(rust,/read_valid_state\(&next_bak\)/);
 assert.ok(rust.indexOf('read_valid_state(&next_bak)')<rust.indexOf('fs::remove_file(&dest)'));
});
