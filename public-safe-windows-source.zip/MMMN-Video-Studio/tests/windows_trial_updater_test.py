"""Real filesystem tests of the offline, non-destructive Windows trial updater."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
SCRIPT = ROOT / 'tools' / 'windows_trial_updater.py'
spec = importlib.util.spec_from_file_location('mmmn_trial_update', SCRIPT)
updater = importlib.util.module_from_spec(spec)
spec.loader.exec_module(updater)


class WindowsTrialUpdaterTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='mmmn-install-safe-')
        base = Path(self.temp.name)
        self.source = base / 'extracted-new-zip'
        self.target = base / 'LocalAppData' / 'Programs' / 'MMMN Video Studio Trial'
        self.data = base / 'LocalAppData' / 'MMMN-Video-Studio-Trial'
        self.data.mkdir(parents=True)
        self.private_bytes = {
            'project-state.json': b'{"chapters":[],"assets":[],"title":"\xe1\x80\x84\xe1\x80\xbe\xe1\x80\x80\xe1\x80\xba\xe1\x80\xa1\xe1\x80;b"}',
            'media/narration-123.mp4': b'\x00VERY IMPORTANT PRIVATE USER NARRATION\x00',
            'snapshots/backup-001.zip': b'BACKUP MUST SURVIVE',
            'exports/chapter-001.mp4': b'EXPORTED FILE MUST SURVIVE',
        }
        for rel, raw in self.private_bytes.items():
            p = self.data / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(raw)
        self.make_source('first')

    def tearDown(self):
        self.temp.cleanup()

    def make_source(self, revision):
        self.source.mkdir(parents=True, exist_ok=True)
        contents = {
            'web/index.html': f'<html>{revision}</html>',
            'web/app.js': 'console.log(1)',
            'web/core.mjs': 'export const ok = true',
            'web/resources/starter-project.json': '{"chapters":[],"assets":[]}',
            'renderer/render.py': '# safe renderer',
            'portable/studio_server.py': '# studio',
            'portable/launcher.py': '# launcher',
            'portable/bin/README-FFMPEG.txt': 'Use own trusted binary',
            'TRIAL-REVISION.txt': revision,
            'RUN-WINDOWS-TRIAL.cmd': 'echo Windows Offline Trial',
            'CHECK-WINDOWS-TRIAL.cmd': 'echo ok',
        }
        for rel, value in contents.items():
            file = self.source / rel
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(value, encoding='utf-8')

    def assert_data_unchanged(self):
        for rel, expected in self.private_bytes.items():
            self.assertEqual((self.data / rel).read_bytes(), expected, rel)

    def test_first_install_and_update_preserve_every_private_file(self):
        first = updater.install(self.source, self.target, self.data)
        self.assertEqual(first['revision'], 'first')
        self.assertTrue((self.target / 'web/index.html').is_file())
        self.assert_data_unchanged()
        self.make_source('second')
        second = updater.install(self.source, self.target, self.data)
        self.assertEqual(second['revision'], 'second')
        self.assertIn('second', (self.target / 'web/index.html').read_text())
        self.assertIn('first', (self.target.with_name(self.target.name + '.previous') / 'web/index.html').read_text())
        self.assert_data_unchanged()
        manifest = json.loads((self.target / updater.MANIFEST).read_text())
        updater.verify_payload(self.target, manifest)

    def test_verify_installed_detects_program_corruption_without_touching_data(self):
        updater.install(self.source, self.target, self.data)
        result = updater.verify_installed(self.target, self.data)
        self.assertEqual(result['verified_program_files'], len(json.loads((self.target / updater.MANIFEST).read_text())['files']))
        (self.target / 'web/app.js').write_text('tampered!')
        with self.assertRaises(updater.InstallError):
            updater.verify_installed(self.target, self.data)
        self.assert_data_unchanged()

    def test_manual_rollback_recovers_old_program_without_touching_data(self):
        updater.install(self.source, self.target, self.data)
        self.make_source('second')
        updater.install(self.source, self.target, self.data)
        result = updater.rollback(self.target, self.data)
        self.assertEqual(result['restored_revision'], 'first')
        self.assertIn('first', (self.target / 'web/index.html').read_text())
        self.assert_data_unchanged()

    def test_recovers_interrupted_update_before_installing(self):
        updater.install(self.source, self.target, self.data)
        previous = self.target.with_name(self.target.name + '.previous')
        self.target.rename(previous)  # simulate power loss at cutover
        self.make_source('second')
        result = updater.install(self.source, self.target, self.data)
        self.assertEqual(result['revision'], 'second')
        self.assertIn('second', (self.target / 'web/index.html').read_text())
        self.assertIn('first', (previous / 'web/index.html').read_text())
        self.assert_data_unchanged()

    def test_interrupted_update_with_bad_previous_stops_without_deleting(self):
        updater.install(self.source, self.target, self.data)
        previous = self.target.with_name(self.target.name + '.previous')
        self.target.rename(previous)
        (previous / 'web/app.js').write_text('CORRUPTED')
        self.make_source('second')
        with self.assertRaises(updater.InstallError):
            updater.install(self.source, self.target, self.data)
        self.assertTrue(previous.exists())
        self.assertFalse(self.target.exists())
        self.assert_data_unchanged()

    def test_corrupt_stage_fails_before_replacing_installed_application(self):
        updater.install(self.source, self.target, self.data)
        self.make_source('second')
        def sabotage(stage):
            (stage / 'web/app.js').write_text('DAMAGED', encoding='utf-8')
        with self.assertRaises(updater.InstallError):
            updater.install(self.source, self.target, self.data, staging_hook=sabotage)
        self.assertIn('first', (self.target / 'web/index.html').read_text())
        self.assert_data_unchanged()
        self.assertFalse(list(self.target.parent.glob('*.pending-*')))

    def test_unrelated_folder_must_never_be_overwritten(self):
        self.target.mkdir(parents=True)
        other = self.target / 'a-personal-document.txt'
        other.write_text('PERSONAL')
        with self.assertRaisesRegex(updater.InstallError, 'no MMMN install manifest'):
            updater.install(self.source, self.target, self.data)
        self.assertEqual(other.read_text(), 'PERSONAL')
        self.assert_data_unchanged()

    def test_existing_trusted_ffmpeg_tool_survives_update(self):
        updater.install(self.source, self.target, self.data)
        binary = self.target / 'portable/bin/ffmpeg.exe'
        binary.write_bytes(b'FAKE FIXTURE TO TEST PERSISTENCE')
        probe = self.target / 'portable/bin/ffprobe.exe'
        probe.write_bytes(b'FAKE PROBE FIXTURE')
        self.make_source('second')
        updater.install(self.source, self.target, self.data)
        self.assertEqual(binary.read_bytes(), b'FAKE FIXTURE TO TEST PERSISTENCE')
        self.assertEqual(probe.read_bytes(), b'FAKE PROBE FIXTURE')
        self.assert_data_unchanged()

    def test_symlink_path_is_rejected_before_install(self):
        updater.install(self.source, self.target, self.data)
        outside = Path(self.temp.name) / 'external.txt'
        outside.write_text('DONT TOUCH')
        link = self.source / 'web' / 'sneaky.txt'
        try:
            link.symlink_to(outside)
        except (OSError, NotImplementedError):
            self.skipTest('Symlink not supported')
        with self.assertRaisesRegex(updater.InstallError, 'Symlink'):
            updater.install(self.source, self.target, self.data)
        self.assertEqual(outside.read_text(), 'DONT TOUCH')
        self.assert_data_unchanged()

    def test_reject_program_folder_nested_inside_project_data(self):
        with self.assertRaisesRegex(updater.InstallError, 'must be separate'):
            updater.install(self.source, self.data / 'my-program', self.data)
        self.assert_data_unchanged()

    def test_missing_source_does_not_touch_previous_install(self):
        updater.install(self.source, self.target, self.data)
        (self.source / 'web/index.html').unlink()
        with self.assertRaises(updater.InstallError):
            updater.install(self.source, self.target, self.data)
        self.assertIn('first', (self.target / 'web/index.html').read_text())
        self.assert_data_unchanged()

    def test_updater_lock_prevents_two_installs(self):
        with updater.updater_lock(self.target.parent):
            with self.assertRaisesRegex(updater.InstallError, 'already running'):
                with updater.updater_lock(self.target.parent):
                    pass
        self.assert_data_unchanged()

    def test_install_lock_rejects_open_project(self):
        # The test calls the application's exact data lock on the active tree.
        with updater.check_studio_closed(self.data):
            with self.assertRaises(updater.InstallError):
                with updater.check_studio_closed(self.data):
                    pass
        self.assert_data_unchanged()

    def test_roll_back_without_previous_fails_safely(self):
        updater.install(self.source, self.target, self.data)
        with self.assertRaises(updater.InstallError):
            updater.rollback(self.target, self.data)
        self.assert_data_unchanged()

    def test_manifest_digest_detects_corruption(self):
        updater.install(self.source, self.target, self.data)
        manifest = json.loads((self.target / updater.MANIFEST).read_text())
        (self.target / 'web/app.js').write_text('garbled')
        with self.assertRaisesRegex(updater.InstallError, 'corrupt'):
            updater.verify_payload(self.target, manifest)
        self.assert_data_unchanged()


if __name__ == '__main__':
    unittest.main()
