import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const conf = JSON.parse(fs.readFileSync('src-tauri/installer.conf.json','utf8'));
const src = fs.readFileSync('src-tauri/src/lib.rs','utf8');
const pipeline = fs.readFileSync('.github/workflows/windows-preinstaller-audit.yml','utf8');
test('Windows FFmpeg resources map to actual native lookup directory',()=>{
 assert.equal(conf.bundle.resources['resources/bin/ffmpeg.exe'],'bin/ffmpeg.exe');
 assert.ok(src.includes('root.join("bin").join(binary)'));
});
test('Native Windows releases cannot silently use FFmpeg from PATH',()=>{
 assert.match(src,/if cfg!\(debug_assertions\)/);
 assert.match(src,/Bundled offline FFmpeg executable is missing/);
 assert.doesNotMatch(src,/binary\.into\(\)/);
});
test('Offline executable hash, codec and smoke test must precede packaging',()=>{
 const checker=fs.readFileSync('scripts/verify-bundled-ffmpeg.ps1','utf8');
 assert.match(checker,/Get-FileHash/);assert.match(checker,/libx264/);
 assert.match(checker,/sine=frequency=440/);
 const cmd=fs.readFileSync('build-windows.cmd','utf8');
 assert.ok(cmd.indexOf('verify-bundled-ffmpeg.ps1')<cmd.indexOf('call npm.cmd ci'));
});
test('Windows audit runs Rust compile without unresolvable npm ci lock gate',()=>{
 assert.match(pipeline,/cargo generate-lockfile/);
 assert.match(pipeline,/cargo check --locked/);
 assert.match(pipeline,/cargo test --locked/);
 assert.match(pipeline,/npm\.cmd install --package-lock-only/);
 assert.match(pipeline,/npm\.cmd ci/);
 assert.match(pipeline,/tauri:build -- --no-bundle/);
 assert.doesNotMatch(pipeline,/--bundles nsis/);
});
