"""Real loopback tests: reliable large-media seek and interrupted-export resume.

Uses synthetic bytes in disposable local directories. No cloud or user files.
"""
from __future__ import annotations
import importlib.util
from http.server import ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('mmmn_stream_test',ROOT/'portable/studio_server.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class PartialFileTests(unittest.TestCase):
    def test_range_parser_including_suffix_and_unbounded(self):
        self.assertIsNone(mod.single_byte_range(None, 100))
        self.assertEqual(mod.single_byte_range('bytes=0-', 100),(0,99))
        self.assertEqual(mod.single_byte_range('bytes=3-7', 100),(3,7))
        self.assertEqual(mod.single_byte_range('bytes=98-9999', 100),(98,99))
        self.assertEqual(mod.single_byte_range('bytes=-4', 100),(96,99))
        self.assertEqual(mod.single_byte_range('bytes=-999', 100),(0,99))
        for broken in ('bytes=999-', 'bytes=2-1', 'bytes=-0',
                       'bytes=1-2,3-4', 'kilobytes=0-4', 'bytes=-', 'bytes=x-y'):
            with self.subTest(broken=broken), self.assertRaises(ValueError):
                mod.single_byte_range(broken, 100)

    def test_resumable_download_and_video_seek_preserve_file(self):
        with tempfile.TemporaryDirectory(prefix='mmmn-stream-') as folder:
            studio=mod.Studio(Path(folder),'temporary-token')
            payload=bytes(range(256))*4000  # 1,024,000 distinct data bytes
            export_name='chapter-1-12345678.mp4'
            export_file=studio.root/'exports'/export_name
            media_file=studio.media('media-file-123','mp4')
            export_file.write_bytes(payload)
            media_file.write_bytes(payload)
            server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(studio))
            worker=threading.Thread(target=server.serve_forever,daemon=True)
            worker.start()
            base=f'http://127.0.0.1:{server.server_port}'
            try:
                paths=[f'/__exports/{export_name}?token=temporary-token', studio.url('media-file-123','mp4')]
                for path in paths:
                    with self.subTest(path=path):
                        with urlopen(Request(base+path,method='HEAD')) as head:
                            self.assertEqual(head.status,200)
                            self.assertEqual(head.headers['Content-Length'],'1024000')
                            self.assertEqual(head.read(),b'')
                        with urlopen(Request(base+path,headers={'Range':'bytes=1-9'},method='HEAD')) as head:
                            self.assertEqual(head.status,206)
                            self.assertEqual(head.headers['Content-Range'],'bytes 1-9/1024000')
                            self.assertEqual(head.read(),b'')
                        with urlopen(base+path) as response:
                            self.assertEqual(response.status,200)
                            self.assertEqual(response.headers['Accept-Ranges'],'bytes')
                            self.assertEqual(response.read(),payload)
                        part_one=Request(base+path,headers={'Range':'bytes=0-599999'})
                        part_two=Request(base+path,headers={'Range':'bytes=600000-'})
                        with urlopen(part_one) as r:
                            self.assertEqual(r.status,206)
                            self.assertEqual(r.headers['Content-Range'],'bytes 0-599999/1024000')
                            first=r.read()
                        with urlopen(part_two) as r:
                            self.assertEqual(r.status,206)
                            second=r.read()
                        self.assertEqual(first+second,payload)
                        with urlopen(Request(base+path,headers={'Range':'bytes=-12'})) as r:
                            self.assertEqual(r.read(),payload[-12:])
                        for invalid in ('bytes=2048000-', 'bytes=2-1', 'bytes=0-2,5-8'):
                            with self.assertRaises(HTTPError) as error:
                                urlopen(Request(base+path,headers={'Range':invalid}))
                            self.assertEqual(error.exception.code,416)
                            self.assertEqual(error.exception.headers['Content-Range'],'bytes */1024000')
                self.assertEqual(export_file.read_bytes(),payload)
                self.assertEqual(media_file.read_bytes(),payload)
                with self.assertRaises(HTTPError) as denied:
                    urlopen(base+f'/__exports/{export_name}')
                self.assertEqual(denied.exception.code,403)
            finally:
                server.shutdown()
                server.server_close()
                worker.join(timeout=5)

if __name__=='__main__':
    unittest.main()
