"""Smoke source mode must use isolated temp paths, NEVER a real project."""
import os
import shutil
import subprocess
import sys
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parent.parent
class FullPortableSmokeTest(unittest.TestCase):
    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'requires local FFmpeg')
    def test_real_local_end_to_end_without_user_data(self):
        proc=subprocess.run([sys.executable,str(ROOT/'tests/windows_portable_exe_smoke.py'),
                             '--python-source'],cwd=ROOT,capture_output=True,text=True,timeout=180)
        self.assertEqual(proc.returncode,0,proc.stdout+'\n'+proc.stderr)
        self.assertIn('"status": "PASS"',proc.stdout)
        self.assertIn('real 60-frame H.264/AAC MP4 with verified character-scene change',proc.stdout)
    def test_windows_portable_and_installer_ci_are_gated_by_real_exe(self):
        portable=(ROOT/'.github/workflows/windows-portable-exe-manual.yml').read_text()
        installer=(ROOT/'.github/workflows/windows-installer-upgrade-lab.yml').read_text()
        local=(ROOT/'scripts/build-portable-windows.ps1').read_text()
        self.assertLess(portable.index('windows_portable_exe_smoke.py'),portable.index('actions/upload-artifact@v4'))
        self.assertLess(installer.index('windows_portable_exe_smoke.py'),installer.index('actions/upload-artifact@v4'))
        self.assertIn('windows_portable_exe_smoke.py',local)

if __name__=='__main__':unittest.main()
