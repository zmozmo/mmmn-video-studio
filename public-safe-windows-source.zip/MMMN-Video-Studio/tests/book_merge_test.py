"""Full-book MP4 integration. Chapter exports are never altered/deleted."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import unittest

S=Path(__file__).resolve().parents[1]/'portable'/'studio_server.py'
spec=importlib.util.spec_from_file_location('studio_server_r8',S)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg/FFprobe required')
class BookMergeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=mod.Studio(Path(self.temp.name),'test-token')
        self.parts=[]
        for chapter,color in [(1,'red'),(2,'blue')]:
            dest=self.studio.root/'exports'/f'chapter-{chapter}-1234567890abcdef.mp4'
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-y',
                 '-f','lavfi','-i',f'color=c={color}:s=160x90:r=30',
                 '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
                 '-t','1','-c:v','libx264','-pix_fmt','yuv420p',
                 '-c:a','aac','-b:a','96k','-shortest',str(dest)]
            subprocess.run(cmd,check=True,capture_output=True)
            self.parts.append(dest)
        self.before=[self.studio.checksum(p) for p in self.parts]

    def tearDown(self):self.temp.cleanup()

    def test_full_book_merge_preserves_chapters_and_verifies_all_frames(self):
        events=[]
        output=self.studio._book_join([p.name for p in self.parts],_progress=lambda phase,n,total:events.append((phase,n,total)))
        out=Path(output)
        self.assertTrue(out.is_file())
        self.assertRegex(out.name,r'^book-[a-f0-9]{16}\.mp4$')
        self.assertEqual(self.before,[self.studio.checksum(p) for p in self.parts])
        info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames',
            '-show_entries','stream=codec_type,codec_name,nb_read_frames:format=duration',
            '-of','json',str(out)]))
        tracks={x['codec_type']:x for x in info['streams']}
        self.assertEqual(int(tracks['video']['nb_read_frames']),60)
        self.assertAlmostEqual(float(info['format']['duration']),2,delta=.15)
        self.assertIn(out.name,[x['name'] for x in self.studio.list_local_exports()])
        self.assertEqual(events[-1][1],4)
        self.assertEqual(len(list((self.studio.root/'exports').glob('book-merge-*'))),0)

    def test_duplicate_reverse_and_path_traversal_blocked(self):
        chapter1=self.parts[0].name
        for bad in ([chapter1,chapter1], [self.parts[1].name,chapter1],
                    ['../project-state.json',self.parts[1].name],
                    ['book-0000000000000000.mp4',self.parts[1].name]):
            with self.subTest(bad=bad),self.assertRaises(ValueError):
                self.studio._book_join(bad)
        self.assertEqual(self.before,[self.studio.checksum(p) for p in self.parts])

    def test_http_book_merge_and_download_needs_local_token(self):
        from http.server import ThreadingHTTPServer
        from urllib.request import Request,urlopen
        from urllib.error import HTTPError
        import threading
        server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        base=f'http://127.0.0.1:{server.server_address[1]}'
        try:
            payload=json.dumps({'filenames':[p.name for p in self.parts]}).encode()
            with self.assertRaises(HTTPError) as err:
                urlopen(Request(base+'/__api/start_book_merge_job',payload,
                                {'Content-Type':'application/json'},'POST'))
            self.assertEqual(err.exception.code,403)
            req=Request(base+'/__api/start_book_merge_job',payload,
                        {'X-MM-Token':'test-token','Content-Type':'application/json'},'POST')
            result=json.loads(urlopen(req).read())['result']
            self.assertIn(result['status'],('queued','running','complete'))
            for _ in range(100):
                status=self.studio.get_render_job_status(id=result['id'])
                if status['status'] in ('complete','failed','cancelled'):break
                time.sleep(.1)
            self.assertEqual(status['status'],'complete',status.get('error'))
            name=Path(status['output']).name
            with self.assertRaises(HTTPError) as err:
                urlopen(base+'/__exports/'+name)
            self.assertEqual(err.exception.code,403)
            with urlopen(base+'/__exports/'+name+'?token=test-token') as response:
                self.assertEqual(response.status,200)
                self.assertIn(b'ftyp',response.read(80))
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)

    def test_incompatible_resolution_fails_before_writing_output(self):
        bad=self.parts[1]
        subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
           '-f','lavfi','-i','color=c=yellow:s=320x180:r=30',
           '-f','lavfi','-i','sine=frequency=400:sample_rate=44100',
           '-t','1','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',
           str(bad.with_suffix('.new.mp4'))],check=True,capture_output=True)
        bad.with_suffix('.new.mp4').replace(bad)
        with self.assertRaisesRegex(ValueError,'same resolution'):
            self.studio._book_join([p.name for p in self.parts])
        self.assertFalse(list((self.studio.root/'exports').glob('book-*.mp4')))

    def test_background_job_completion_and_cancel_without_changing_project(self):
        job=self.studio.start_book_merge_job(filenames=[p.name for p in self.parts])
        self.assertEqual(job['status'] in ('queued','running','complete'),True)
        for _ in range(100):
            status=self.studio.get_render_job_status(id=job['id'])
            if status['status'] in ('complete','failed','cancelled'):break
            time.sleep(.1)
        self.assertEqual(status['status'],'complete',status.get('error'))
        self.assertTrue(Path(status['output']).is_file())
        self.assertIsNone(self.studio.current_render_job())

if __name__=='__main__':unittest.main()
