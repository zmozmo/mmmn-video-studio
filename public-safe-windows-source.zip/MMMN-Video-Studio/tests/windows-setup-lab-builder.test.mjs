import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('lab builder checks real exe, GUI and offline rendering before NSIS',()=>{
  const s=fs.readFileSync('scripts/build-windows-setup-lab.ps1','utf8');
  for(const term of ['windows_portable_exe_smoke.py','windows_edge_ui_smoke.py','--self-test','run-python-tests.py','Get-FileHash','MMMN-Video-Studio.nsi'])assert.ok(s.includes(term),term);
  assert.ok(s.indexOf('windows_edge_ui_smoke.py')<s.indexOf('MMMN-Video-Studio.nsi'));
  assert.ok(s.includes('UNSIGNED LAB INSTALLER ONLY'));
});
test('production gate still blocks unproven Windows release',()=>{
  const s=fs.readFileSync('build-windows.cmd','utf8');
  assert.ok(s.includes('verify:installer-ready'));
  const c=fs.readFileSync('scripts/preinstall-status.mjs','utf8');
  assert.ok(c.includes("['Windows installer setup.exe built + hash verified',false]"));
});
