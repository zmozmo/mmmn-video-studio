"""Audio-only narration MUST export as video on Windows; no camera/face required."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('mmmn_audio_only', ROOT / 'portable' / 'studio_server.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class AudioOnlyNarrationTests(unittest.TestCase):
    def test_ui_can_choose_audio_only_source(self):
        js = (ROOT / 'web' / 'app.js').read_text(encoding='utf-8')
        preflight = (ROOT / 'web' / 'native-render-preflight.mjs').read_text(encoding='utf-8')
        self.assertIn('c.audioAssetId=id;c.videoAssetId=null', js)
        self.assertIn('AUDIO_FORMATS', preflight)
        self.assertIn('sourceVideoId:source.id', preflight)
        self.assertIn('sourceVideoId:recording.id', js)

    def test_disallowed_audio_extension_rejected_before_io(self):
        with tempfile.TemporaryDirectory() as folder:
            studio = mod.Studio(Path(folder), 'token')
            with self.assertRaisesRegex(ValueError, 'extension not supported'):
                studio.render_chapter_command(chapterNumber=1, sourceVideoId='my-audio-123',
                  sourceVideoExt='exe', scenes=[{'assetId':'image-123456','ext':'png','duration':1}],
                  recordedSeconds=1, preset='square')

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'Local FFmpeg required')
    def test_real_audio_only_wav_and_mp3_render_h264_aac_and_preserve_source(self):
        with tempfile.TemporaryDirectory(prefix='mmmn-no-camera-') as folder:
            studio=mod.Studio(Path(folder),'token')
            studio.RENDER_DIMENSIONS={'square':(192,192)}
            pics=[studio.media('narration-photo-1','png'),studio.media('narration-photo-2','png')]
            for image,color in zip(pics,['red','blue']):
                subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                    '-i',f'color=c={color}:s=150x100:r=1','-frames:v','1',str(image)],check=True,timeout=30)
            scene_data=[{'assetId':'narration-photo-1','ext':'png','duration':1,'motion':'still'},
                        {'assetId':'narration-photo-2','ext':'png','duration':1,'motion':'still'}]
            for ext,codec in [('wav','pcm_s16le'),('mp3','libmp3lame')]:
                with self.subTest(ext=ext):
                    source=studio.media('narration-audio-1',ext)
                    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                        '-i','sine=frequency=550:sample_rate=44100','-t','2',
                        '-c:a',codec,str(source)],check=True,timeout=30)
                    source_sha=studio.checksum(source)[1]
                    output=Path(studio.render_chapter_command(chapterNumber=1,
                        sourceVideoId='narration-audio-1',sourceVideoExt=ext,scenes=scene_data,
                        preset='square',recordedSeconds=2,transitionMode='dissolve',quality='preview'))
                    streams=json.loads(subprocess.check_output(['ffprobe','-v','error',
                        '-count_frames','-show_entries','stream=codec_type,codec_name,nb_read_frames',
                        '-of','json',str(output)],timeout=40))['streams']
                    track={s['codec_type']:s for s in streams}
                    self.assertEqual(track['video']['codec_name'],'h264')
                    self.assertEqual(track['audio']['codec_name'],'aac')
                    self.assertEqual(int(track['video']['nb_read_frames']),60)
                    self.assertEqual(studio.checksum(source)[1],source_sha)
                    self.assertGreater(output.stat().st_size, 1500)

    @unittest.skipUnless(shutil.which('ffmpeg'), 'Local FFmpeg required')
    def test_audio_only_pause_analysis_keeps_manual_timing(self):
        with tempfile.TemporaryDirectory() as folder:
            studio=mod.Studio(Path(folder),'token')
            source=studio.media('narration-audio','wav')
            subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi',
                '-i','anullsrc=r=44100:cl=mono','-t','2',str(source)],check=True,timeout=30)
            result=studio.analyze_narration_pauses(chapterNumber=1,chapterId='chapter-1',
                sourceVideoId='narration-audio',sourceVideoExt='wav',recordedSeconds=2,
                scenes=[{'id':'scene-1','text':'Hello','start':0},
                        {'id':'scene-2','text':'World','start':1,'alignment':'manual-locked'}])
            self.assertTrue(result['humanReviewRequired'])
            self.assertEqual(result['scenes'][1]['start'],1)

if __name__=='__main__':unittest.main()
