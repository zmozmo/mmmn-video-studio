import test from 'node:test';
import assert from 'node:assert/strict';
import {planNativeRender} from '../web/native-render-preflight.mjs';
const video={id:'video-000001',name:'source.mp4',type:'video/mp4'};
const images=[{id:'image-000001',name:'BI-001.png'},{id:'image-000002',name:'BI-002.jpg'}];
const assets=[video,...images];
const chapter=()=>({number:1,videoAssetId:video.id,recordedSeconds:10,scenes:[{assetId:images[0].id,duration:4},{assetId:images[1].id,duration:6}]});
const found=async()=>({size:50000});
test('valid offline renderer request preserves original media IDs and durations',async()=>{
 const request=await planNativeRender(chapter(),assets,found);
 assert.equal(request.recordedSeconds,10);assert.equal(request.scenes[1].duration,6);
 assert.equal(request.sourceVideoExt,'mp4');assert.equal(request.preset,'youtube');
});
test('offline-native preflight blocks missing narrator media',async()=>{
 await assert.rejects(planNativeRender(chapter(),assets,async x=>x.id!==video.id),/narrator recording is missing/i);
});
test('offline-native preflight blocks missing scene pictures',async()=>{
 await assert.rejects(planNativeRender(chapter(),assets,async x=>x.id!==images[1].id),/picture is missing/i);
});
test('offline-native preflight blocks wrong narration timeline duration',async()=>{
 const c=chapter();c.recordedSeconds=11;
 await assert.rejects(planNativeRender(c,assets,found),/does not match/i);
});
test('offline-native preflight tolerates small subsecond rounding error',async()=>{
 const c=chapter();c.recordedSeconds=10.25;await planNativeRender(c,assets,found);
});
test('offline-native preflight blocks invalid negative scene times',async()=>{
 const c=chapter();c.scenes[0].duration=-1;
 await assert.rejects(planNativeRender(c,assets,found),/Scene 1 duration/);
});
test('offline-native preflight accepts audio-only MP3/WAV/M4A/OGG/AAC narration',async()=>{
 for(const ext of ['mp3','wav','m4a','ogg','aac']){
  const audio={id:'audio-000001',name:`narrator.${ext}`,type:'audio/'+ext};
  const c={...chapter(),videoAssetId:null,audioAssetId:audio.id};
  const req=await planNativeRender(c,[audio,...images],found);
  assert.equal(req.sourceVideoId,audio.id); assert.equal(req.sourceVideoExt,ext);
 }
});
test('audio-only preflight fails closed when narration missing or unsafe',async()=>{
 const audio={id:'audio-000001',name:'narration.mp3',type:'audio/mpeg'};
 const c={...chapter(),videoAssetId:null,audioAssetId:audio.id};
 await assert.rejects(planNativeRender(c,[audio,...images],async x=>x.id!==audio.id),/narrator recording is missing/i);
 await assert.rejects(planNativeRender(c,[{...audio,name:'script.bat'},...images],found),/supported narrator video or audio/i);
});
test('legacy video projects retain video as narrator when both IDs remain',async()=>{
 const audio={id:'audio-000001',name:'narration.wav'};
 const c={...chapter(),audioAssetId:audio.id};
 const req=await planNativeRender(c,[...assets,audio],found);
 assert.equal(req.sourceVideoId,video.id);
});
test('offline-native preflight blocks unsupported pictures',async()=>{
 const a=[video,{...images[0],name:'malware.exe'},images[1]];
 await assert.rejects(planNativeRender(chapter(),a,found),/Scene 1 needs/);
});
test('offline-native preflight validates platform and chapter',async()=>{
 await assert.rejects(planNativeRender(chapter(),assets,found,'other'),/Unsupported render/);
 const c=chapter();c.number=0;
 await assert.rejects(planNativeRender(c,assets,found),/Chapter number/);
});
test('offline-native preflight refuses empty or excessive scenes',async()=>{
 const c=chapter();c.scenes=[];
 await assert.rejects(planNativeRender(c,assets,found),/between 1 and 1000/);
});
