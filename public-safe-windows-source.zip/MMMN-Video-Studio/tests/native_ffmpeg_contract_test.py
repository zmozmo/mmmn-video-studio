"""CPU-only independent regression fixture for Rust render_chapter's FFmpeg argument contract.
This does NOT certify the Rust/Tauri UI or Windows installer; it verifies input-list,
narration audio mapping, H.264/AAC, timestamps and scene changes with real FFmpeg.
"""
import json
import math
import shutil
import subprocess
import tempfile
import unittest
import wave
import struct
import zlib
from pathlib import Path


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'FFmpeg/FFprobe unavailable')
def png_image(path, rgb, width=320, height=180):
    def chunk(tag, data):
        return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
    pixels=(b'\x00'+bytes(rgb)*width)*height
    content=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,2,0,0,0))
    content+=chunk(b'IDAT',zlib.compress(pixels,6))+chunk(b'IEND',b'')
    path.write_bytes(content)


class NativeFFmpegContract(unittest.TestCase):
    def test_rust_and_portable_native_use_segment_first_frame_accurate_export(self):
        from pathlib import Path
        root = Path(__file__).resolve().parents[1]
        native = (root/'src-tauri'/'src'/'lib.rs').read_text('utf-8')
        trial = (root/'portable'/'studio_server.py').read_text('utf-8')
        for source in (native,trial):
            self.assertIn('previous_frames',source)
            self.assertIn('frames:v',source)
            self.assertIn('segments.ffconcat',source)
            self.assertIn('libx264',source)
            self.assertIn('1:a:0',source)
        self.assertNotIn('final_image=',native)

if __name__ == '__main__': unittest.main()
