"""External-drive recovery has to be complete before offering a user copy."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

base=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('studio_server',base/'portable/studio_server.py')
server=importlib.util.module_from_spec(spec)
import sys
sys.modules['studio_server']=server
spec.loader.exec_module(server)
spec2=importlib.util.spec_from_file_location('export_recovery',base/'portable/export_recovery.py')
export=importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(export)

class RecoveryExportTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'studio'
  self.usb=Path(self.tmp.name)/'usb'
  self.usb.mkdir()
  self.studio=server.Studio(self.root,'test')
  mid='scene-123456'
  self.studio.media(mid,'png').write_bytes(b'png data for test')
  self.project={'title':'ငှက်အော်ကျွန်း','chapters':[{'number':1,'scenes':[{'assetId':mid}]}],
                'assets':[{'id':mid,'name':'BI-001.png','nativeStored':True}]}
  self.studio.save_project_state(json=json.dumps(self.project,ensure_ascii=False))
  self.sid=self.studio.create_full_local_backup()['id']

 def test_offline_verified_copy_and_no_overwrite(self):
  copied=export.export_verified_snapshot(self.root,self.usb,self.sid)
  self.assertTrue(copied.is_dir())
  self.assertEqual(self.studio.inspect_snapshot(copied)[1]['title'],'ငှက်အော်ကျွန်း')
  with self.assertRaisesRegex(ValueError,'already exists'):
   export.export_verified_snapshot(self.root,self.usb,self.sid)

 def test_bad_media_refuses_export_and_no_partial_left(self):
  (self.root/'snapshots'/self.sid/'media'/'scene-123456.png').write_bytes(b'corrupted')
  with self.assertRaisesRegex(ValueError,'checksum'):
   export.export_verified_snapshot(self.root,self.usb,self.sid)
  self.assertFalse((self.usb/'MMMN-Video-Studio-Recovery'/self.sid).exists())

 def test_never_copy_inside_studio_data(self):
  with self.assertRaisesRegex(ValueError,'another independent'):
   export.export_verified_snapshot(self.root,self.root/'snapshots',self.sid)

 def test_recovery_to_empty_project_is_possible_after_loss(self):
  # Simulate fresh AppData folder after hardware migration, without an existing project.
  fresh=server.Studio(Path(self.tmp.name)/'fresh','test')
  (fresh.root/'snapshots'/self.sid).parent.mkdir(exist_ok=True)
  import shutil
  shutil.copytree(self.root/'snapshots'/self.sid,fresh.root/'snapshots'/self.sid)
  result=fresh.restore_local_backup(id=self.sid)
  self.assertIsNone(result['beforeSnapshot'])
  self.assertEqual(json.loads(fresh.load_project_state())['title'],'ငှက်အော်ကျွန်း')
  self.assertEqual(len(json.loads(result['project'])['assets']),1)

 def test_unique_snapshot_ids_even_fast_repeated_clicks(self):
  another=self.studio.create_full_local_backup()['id']
  self.assertNotEqual(self.sid,another)
  self.assertTrue(self.studio.verify_local_backup(id=another)['verified'])

if __name__=='__main__':unittest.main()
