"""Prevent Windows-release regressions that source-only tests used to miss."""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

class WindowsBuildGUIContract(unittest.TestCase):
    def test_every_windows_workflow_uses_shell_independent_node_discovery(self):
        for p in sorted((ROOT/'.github/workflows').glob('*.yml')):
            content=p.read_text(encoding='utf-8')
            self.assertNotIn('node --test tests/*.test.mjs', content, p.name)

    def test_portable_and_installer_require_real_browser_smoke(self):
        for filename in ('windows-portable-exe-manual.yml', 'windows-installer-upgrade-lab.yml'):
            content=(ROOT/'.github/workflows'/filename).read_text(encoding='utf-8')
            self.assertIn('tests/windows_edge_ui_smoke.py --exe', content)
            self.assertIn('if ($LASTEXITCODE -ne 0)', content)
        smoke=(ROOT/'tests/windows_edge_ui_smoke.py').read_text(encoding='utf-8')
        for important in ('--headless=new','--dump-dom','class="shell"','MMMN_TRIAL_DATA_DIR'):
            self.assertIn(important, smoke)

    def test_win_builder_runs_real_exe_smoke_before_output(self):
        content=(ROOT/'scripts/build-portable-windows.ps1').read_text(encoding='utf-8')
        self.assertLess(content.index('tests\\windows_portable_exe_smoke.py'), content.index('tests\\windows_edge_ui_smoke.py'))
        self.assertLess(content.index('tests\\windows_edge_ui_smoke.py'), content.index('WINDOWS-PORTABLE-OUTPUT'))

if __name__ == '__main__': unittest.main()
