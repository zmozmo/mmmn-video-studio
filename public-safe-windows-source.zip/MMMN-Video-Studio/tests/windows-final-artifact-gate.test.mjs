import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const workflow=fs.readFileSync('.github/workflows/windows-installer-upgrade-lab.yml','utf8');
const promoter=fs.readFileSync('scripts/promote_windows_release_candidate.py','utf8');

test('Windows build installs A then upgrades to EXACT 0.14.0 candidate without separate rebuild',()=>{
  assert.match(workflow,/\/DAPP_VERSION=0\.14\.0-lab-a/);
  assert.match(workflow,/\/DAPP_VERSION=0\.14\.0'/);
  assert.match(workflow,/\$display -ne '0\.14\.0'/);
  assert.match(workflow,/python scripts\/promote_windows_release_candidate\.py --folder build-lab --version 0\.14\.0/);
  assert.match(promoter,/shutil\.copyfile\(installer, staging\)/);
});
test('Release promotion is AFTER actual install, upgrade, H.264/AAC and uninstall evidence',()=>{
  const install=workflow.indexOf('Actually install A');
  const upgrade=workflow.indexOf('Compile second release');
  const video=workflow.indexOf('PROVE recovery, unchanged project/media hashes');
  const uninstall=workflow.indexOf('Uninstall upgraded app');
  const verifier=workflow.indexOf('Independently verify installation');
  const promote=workflow.indexOf('Promote the exact tested installer bytes');
  const upload=workflow.indexOf('Upload the exact tested Windows setup.exe');
  assert.ok([install,upgrade,video,uninstall,verifier,promote,upload].every(v=>v>0));
  assert.ok(install<upgrade&&upgrade<video&&video<uninstall&&uninstall<verifier&&verifier<promote&&promote<upload);
  assert.match(workflow.slice(upload),/if: success\(\)/);
});
test('Windows verified installer publication is fail-closed and clearly unsigned',()=>{
  assert.match(workflow,/MMMN-WINDOWS-SETUP-0\.14\.0-UNSIGNED-VERIFIED/);
  assert.match(workflow,/MMMN-Video-Studio-Setup-0\.14\.0\.exe\.sha256/);
  assert.match(promoter,/verify\(folder\)/);
  assert.match(promoter,/result_hash != checksum/);
  assert.match(promoter,/'signed': False/);
});
