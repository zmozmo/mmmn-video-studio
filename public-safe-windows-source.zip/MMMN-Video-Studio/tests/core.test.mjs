import test from 'node:test';import assert from 'node:assert/strict';
import {estimateSeconds,makeScenes,rebalanceScenes,splitChapters,projectStats,timecode} from '../web/core.mjs';
import {makeZip,readZip} from '../web/zip.mjs';
test('Myanmar chapter parsing',()=>{const a=splitChapters('စာအုပ်\nအခန်း (၁) — တစ်\nဇာတ်လမ်း\nအခန်း (၂) — နှစ်\nအဆုံး');assert.equal(a.length,2);assert.equal(a[1].text,'အဆုံး');});
test('scene timing follows narration length',()=>{let c={id:'ch1',text:'မင်္ဂလာပါ။ '.repeat(75)};c.scenes=makeScenes(c,{charsPerMinute:300,secondsPerShot:20});assert.ok(c.scenes.length>1);let b=rebalanceScenes(c,91);assert.ok(Math.abs(b.reduce((a,s)=>a+s.duration,0)-91)<.005);});
test('metadata counts and timecode',()=>{assert.equal(timecode(3672),'01:01:12');assert.ok(estimateSeconds('အမေ')>0);assert.equal(projectStats({chapters:[],assets:[]}).chapters,0);});
test('ZIP store roundtrip with Myanmar unicode and CRC',async()=>{const blob=await makeZip([{name:'project.json',data:'{"a":1}'},{name:'assets/ငှက်အော်ကျွန်း.txt',data:'မင်္ဂလာပါ'}]);let x=await readZip(blob);assert.equal(new TextDecoder().decode(x.get('assets/ငှက်အော်ကျွန်း.txt')),'မင်္ဂလာပါ');});

import {parseSRT,alignScenesToCues,retimeBoundary} from '../web/core.mjs';

test('SRT parses standard timestamps including Burmese Unicode',()=>{
  const cues=parseSRT('1\n00:00:01,200 --> 00:00:03,400\nလက်ဖက်ရည်ဆိုင် ထိုင်ကြသည်။\n\n2\n00:00:04,000 --> 00:00:05,500\nပင်လယ်ခရီး စတင်သည်။');
  assert.equal(cues.length,2);
  assert.equal(cues[0].start,1.2);
  assert.equal(cues[1].end,5.5);
});

test('SRT matching preserves chronological timeline and labels uncertain timing',()=>{
  const scenes=[
    {text:'လက်ဖက်ရည်ဆိုင် ထိုင်ကြသည်။ လက်ဖက်ရည်သောက်ကြသည်။',duration:5,start:0},
    {text:'ပင်လယ်ခရီး စတင်သည်။ လှေပေါ်တက်ကြသည်။',duration:5,start:5},
    {text:'ဂူထဲ ဝင်လာကြသည်။',duration:5,start:10}
  ];
  const cues=parseSRT('1\n00:00:00,000 --> 00:00:02,000\nလက်ဖက်ရည်ဆိုင် ထိုင်ကြသည်။\n\n2\n00:00:05,000 --> 00:00:07,000\nပင်လယ်ခရီး စတင်သည်။');
  const r=alignScenesToCues(scenes,cues,15);
  assert.equal(r.aligned,2);
  assert.equal(r.unmatched,1);
  assert.equal(r.scenes[1].start,5);
  assert.equal(r.scenes[2].alignment,'estimated');
  assert.ok(Math.abs(r.scenes.reduce((x,s)=>x+s.duration,0)-15)<0.01);
});

test('Manual boundary adjust preserves total duration',()=>{
  const before=[{start:0,duration:4},{start:4,duration:6}];
  const after=retimeBoundary(before,1,.5);
  assert.equal(after[0].duration,4.5);
  assert.equal(after[1].duration,5.5);
  assert.equal(after[1].start,4.5);
  assert.equal(before[0].duration,4);
});

import {splitSceneAt,mergeSceneWithNext,setSceneDurationKeepingTotal,missingSceneImages,sceneGapsCSV} from '../web/core.mjs';
test('Scene splitting at narrator playhead preserves order, text, and total duration',()=>{
  const before=[{id:'a',text:'လက်ဖက်ရည်ဆိုင်မှာ ထိုင်ကြသည်။ လှေပေါ်ကို ထွက်ခဲ့ကြသည်။',start:0,duration:12,assetId:'pic1'},{id:'b',text:'ဂူအဝင်',start:12,duration:9}];
  const after=splitSceneAt(before,0,5);
  assert.equal(after.length,3);
  assert.equal(after[0].duration,5);
  assert.equal(after[1].duration,7);
  assert.equal(after[2].start,12);
  assert.notEqual(after[0].id,after[1].id);
  assert.equal(after[1].assetId,'pic1');
  assert.equal((after[0].text+after[1].text).replace(/\s+/g,''),before[0].text.replace(/\s+/g,''));
  assert.equal(before.length,2);
});
test('Merge keeps narration length and reports manual review',()=>{
  const src=[{id:'a',text:'ပထမ။',start:0,duration:4},{id:'b',text:'ဒုတိယ။',start:4,duration:5},{id:'c',text:'တတိယ',start:9,duration:7}];
  const after=mergeSceneWithNext(src,0);
  assert.equal(after.length,2);assert.equal(after[0].duration,9);assert.equal(after[1].start,9);
  assert.match(after[0].text,/ဒုတိယ/);assert.equal(after[0].alignment,'manual-review');
});
test('Manual shot duration keeps total time, including clamping',()=>{
 const src=[{start:0,duration:8},{start:8,duration:4},{start:12,duration:3}];
 const a=setSceneDurationKeepingTotal(src,0,11.5);
 assert.equal(a[0].duration,11.5);assert.equal(a[1].duration,.5);
 assert.equal(a[2].start,12);
 const b=setSceneDurationKeepingTotal(src,2,9);
 assert.deepEqual(b,src);
});
test('Missing visual report only mentions unassigned shots; CSV safe for commas and quotes',()=>{
 const p={assets:[{id:'i',type:'image/png'}],chapters:[{number:1,scenes:[{id:'a',start:0,assetId:'i'},{id:'b',start:8,imageRequirementId:'BI-002',imageRequirementText:'ဆိုင်, ဧည့်သည် "နှစ်ဦး"'}]},{number:2,scenes:[{id:'c',start:0}]}]};
 const r=missingSceneImages(p,0);assert.equal(r.length,1);
 assert.equal(r[0].requirement,'BI-002');
 const csv=sceneGapsCSV(r);assert.match(csv,/"ဆိုင်, ဧည့်သည် ""နှစ်ဦး"""/);
 assert.equal(missingSceneImages(p).length,2);
});
test('Narration-video import counts towards completed narration chapters',()=>{
 assert.equal(projectStats({chapters:[{text:'',videoAssetId:'rec.mp4'}],assets:[]}).audioChapters,1);
});

import {visualTextScore,suggestVisualMatches,setSceneVisualConfirmation,setBoundaryAtTime,visualProposalsCSV} from '../web/core.mjs';
test('Burmese story pictures: Yangon vs tea shop vs cave proposals',()=>{
 const req=[
  {id:'BI-001',order:1,description:'၁၉၇၁ ရန်ကုန်မြို့ မနက်ခင်း လမ်းမကြီး ဆိုက်ကား စက်ဘီး'},
  {id:'BI-002',order:2,description:'ရှေးခေတ် လက်ဖက်ရည်ဆိုင်မှာ လူတွေ လက်ဖက်ရည် သောက်ကြသည်'},
  {id:'BI-003',order:3,description:'ပင်လယ်ကမ်း ကျောက်ဂူအဝင် ရေပြင်'}];
 const before=[
  {id:'s1',text:'၁၉၇၁ ရန်ကုန်မြို့ နံနက်ခင်း။ ဆိုက်ကား စက်ဘီးများ ဖြတ်သန်းကြသည်။',start:0,duration:7},
  {id:'s2',text:'လက်ဖက်ရည်ဆိုင်မှာ လူတွေ လက်ဖက်ရည် သောက်ကြသည်။',start:7,duration:8},
  {id:'s3',text:'ပင်လယ်ကမ်း ကျောက်ဂူအဝင် နားကို ရောက်လာကြသည်။',start:15,duration:7}];
 const out=suggestVisualMatches(before,req);
 assert.deepEqual(out.scenes.map(s=>s.imageRequirementId),['BI-001','BI-002','BI-003']);
 assert.equal(out.proposed,3);
 assert.ok(visualTextScore(before[1].text,req[1].description)>.35);
 assert.equal(before[0].imageRequirementId,undefined);
 assert.equal(out.scenes[0].imageMatchStatus,'suggested-review');
});
test('Human confirmations survive repeated suggestions and do not get overwritten',()=>{
 const req=[{id:'BI-001',order:1,description:'ပင်လယ် လှေ ရေပြင်'}, {id:'BI-002',order:2,description:'လက်ဖက်ရည်ဆိုင် ထိုင်နေကြသည်'}];
 const original=[{id:'1',text:'ပင်လယ် လှေ ရေပြင်',assetId:'local-1',imageRequirementId:'BI-002',imageMatchStatus:'manual-confirmed',start:0,duration:5}];
 const result=suggestVisualMatches(original,req);
 assert.equal(result.locked,1);assert.equal(result.scenes[0].imageRequirementId,'BI-002');
 assert.equal(result.scenes[0].assetId,'local-1');
 assert.equal(setSceneVisualConfirmation(result.scenes,0,false)[0].imageMatchStatus,'suggested-review');
});
test('Mark Start Here accurately moves a boundary but keeps original video runtime',()=>{
 const before=[{start:0,duration:4},{start:4,duration:7},{start:11,duration:9}];
 const after=setBoundaryAtTime(before,1,5.75);
 assert.equal(after[1].start,5.75);assert.equal(after[0].duration,5.75);assert.equal(after[1].duration,5.25);
 assert.ok(Math.abs(after.reduce((a,s)=>a+s.duration,0)-20)<.00001);
 assert.deepEqual(setBoundaryAtTime(before,0,2),before);
 assert.deepEqual(before,[{start:0,duration:4},{start:4,duration:7},{start:11,duration:9}]);
});
test('Video story-match report is local CSV and quotes multiline Burmese text safely',()=>{
 const result=visualProposalsCSV({number:2},[{start:1,duration:2,id:'a',imageRequirementId:'BI-007',imageMatchScore:.6,imageMatchStatus:'suggested-review',text:'ဆိုင်, "လူ နှစ်ဦး"'}]);
 assert.match(result,/BI-007/);assert.match(result,/'?suggested-review/);assert.match(result,/"ဆိုင်, ""လူ နှစ်ဦး"""/);
});
import {splitAtVisualChanges} from '../web/core.mjs';
test('Visual-change split creates separate tea-shop picture within a street paragraph',()=>{
 const source=[{id:'ch1-s1',text:'၁၉၇၁ ရန်ကုန်မြို့မှာ ဆိုက်ကား စက်ဘီးများ သွားလာနေသည်။ လက်ဖက်ရည်ဆိုင်များက လက်ဖက်ရည်ဖျော်သံများ ကြားရသည်။',start:0,duration:16,motion:'zoom',assetId:null}];
 const req=[{id:'BI-001',order:1,description:'၁၉၇၁ ရန်ကုန်မြို့ ဆိုက်ကား စက်ဘီး လမ်းမ'},{id:'BI-002',order:2,description:'ရှေးခေတ်လက်ဖက်ရည်ဆိုင်နှင့် လမ်းဘေးဈေးသည်များ'}];
 const r=splitAtVisualChanges(source,req);
 assert.equal(r.scenes.length,2);
 assert.equal(r.scenes[0].imageRequirementId,'BI-001');
 assert.equal(r.scenes[1].imageRequirementId,'BI-002');
 assert.ok(r.scenes[1].text.startsWith('လက်ဖက်ရည်ဆိုင်'));
 assert.ok(Math.abs(r.scenes.reduce((a,x)=>a+x.duration,0)-16)<.001);
});
test('Visual-change splitter never rewrites a human-confirmed scene',()=>{
 const scene={id:'1',text:'၁၉၇၁ ရန်ကုန်မြို့ စက်ဘီး။ လက်ဖက်ရည်ဆိုင်မှာ ထိုင်ကြသည်။',duration:10,start:0,assetId:'approved',imageMatchStatus:'manual-confirmed'};
 const r=splitAtVisualChanges([scene],[{id:'BI-1',order:1,description:'၁၉၇၁ ရန်ကုန်မြို့'},{id:'BI-2',order:2,description:'လက်ဖက်ရည်ဆိုင်'}]);
 assert.equal(r.added,0);assert.deepEqual(r.scenes,[scene]);
});

import {formatSRT,subtitleDiagnostics,sceneReviewIssues,sceneReviewCSV} from '../web/core.mjs';
test('Edited Myanmar SRT roundtrips timestamps including milliseconds',()=>{
 const cues=[{start:0,end:1.123,text:'မင်္ဂလာပါ။'},{start:65.25,end:67.75,text:'လက်ဖက်ရည်ဆိုင်မှာ ထိုင်ကြသည်။'}];
 const s=formatSRT(cues);
 assert.match(s,/00:01:05,250 --> 00:01:07,750/);
 assert.deepEqual(parseSRT(s),cues);
});
test('Malformed overlapping subtitles are flagged before save',()=>{
 const result=subtitleDiagnostics([{start:1,end:5,text:'a'},{start:4,end:7,text:'b'},{start:9,end:15,text:'c'}],12);
 assert.equal(result.count,3);
 assert.equal(result.warnings.length,2);
 assert.match(result.warnings[0],/overlaps/);
 assert.match(result.warnings[1],/beyond/);
});
test('Manual-locked visual boundary is preserved when SRT proposes a conflicting boundary',()=>{
 const scenes=[
  {id:'a',start:0,duration:4,text:'လက်ဖက်ရည်ဆိုင် ထိုင်ကြသည်။'},
  {id:'b',start:4,duration:8,text:'ပင်လယ်ခရီး စတင်သည်။',alignment:'manual-locked'},
  {id:'c',start:12,duration:8,text:'ကျောက်ဂူအတွင်း ဝင်သွားကြသည်။'}
 ];
 const edited=setBoundaryAtTime(scenes,1,7);
 assert.equal(edited[1].start,7);
 assert.equal(edited[1].alignment,'manual-locked');
 const cues=[{start:0,end:2,text:'လက်ဖက်ရည်ဆိုင် ထိုင်ကြသည်။'},
  {start:3,end:5,text:'ပင်လယ်ခရီး စတင်သည်။'},
  {start:14,end:16,text:'ကျောက်ဂူအတွင်း ဝင်သွားကြသည်။'}];
 const r=alignScenesToCues(edited,cues,20);
 assert.equal(r.scenes[1].start,7);
 assert.equal(r.scenes[1].alignment,'manual-locked');
 assert.ok(Math.abs(r.scenes.reduce((sum,s)=>sum+s.duration,0)-20)<.005);
 assert.equal(r.scenes.length,3);
});
test('Review Queue reports missing images and uncertain times independently',()=>{
 const c={number:3,scenes:[{id:'one',start:0,assetId:'img',alignment:'manual-locked',imageMatchStatus:'manual-confirmed'},
  {id:'two',start:7,assetId:'img',alignment:'estimated',imageMatchStatus:'suggested-review'},
  {id:'three',start:15,assetId:null,imageRequirementId:'BI-100',alignment:'srt-matched'}]};
 const p={assets:[{id:'img',type:'image/png'}]};
 const q=sceneReviewIssues(c,p);
 assert.equal(q.length,2);
 assert.deepEqual(q[0].kinds,['picture-unconfirmed','timing-estimated']);
 assert.deepEqual(q[1].kinds,['missing-picture']);
 assert.match(sceneReviewCSV(c,p),/BI-100/);
});
test('Visual splitter added count never accumulates quadratically across input shots',()=>{
 const req=[{id:'A',order:1,description:'၁၉၇၁ ရန်ကုန်မြို့ စက်ဘီး သွားလာသည်'},
  {id:'B',order:2,description:'လက်ဖက်ရည်ဆိုင် လက်ဖက်ရည် ထိုင်ကြသည်'}];
 const paragraph='၁၉၇၁ ရန်ကုန်မြို့ စက်ဘီး သွားလာသည်။ လက်ဖက်ရည်ဆိုင် လက်ဖက်ရည် ထိုင်ကြသည်။';
 const src=[0,1,2].map(i=>({id:'s'+i,text:paragraph,start:i*12,duration:12}));
 const r=splitAtVisualChanges(src,req);
 assert.equal(r.added,r.scenes.length-src.length);
 assert.equal(r.added,3);
});
