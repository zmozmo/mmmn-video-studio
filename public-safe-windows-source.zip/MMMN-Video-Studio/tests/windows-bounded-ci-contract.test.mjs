import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const workflows = [
  '.github/workflows/windows-installer-upgrade-lab.yml',
  '.github/workflows/windows-portable-exe-manual.yml',
  '.github/workflows/portable-windows-trial-test.yml',
];
for (const path of workflows) {
  test(`Windows CI uses bounded Python tests in ${path}`, () => {
    const workflow = fs.readFileSync(path, 'utf8');
    assert.match(workflow, /scripts\/run-python-tests\.py --timeout 180 --report /);
    assert.doesNotMatch(workflow, /python -m unittest discover/);
  });
}
test('Local Windows portable build also emits bounded Python test report', () => {
  const script = fs.readFileSync('scripts/build-portable-windows.ps1', 'utf8');
  assert.match(script, /run-python-tests\.py','--timeout','180','--report'/);
});
