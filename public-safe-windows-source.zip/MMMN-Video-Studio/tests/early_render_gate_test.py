import importlib.util
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
spec=importlib.util.spec_from_file_location('trial_render',Path(__file__).resolve().parent.parent/'portable/studio_server.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg suite missing')
class RenderPreflightTests(unittest.TestCase):
 def test_silent_narrator_video_fails_before_creating_scene_segments(self):
  with tempfile.TemporaryDirectory() as d:
   studio=mod.Studio(Path(d),'token')
   silent=studio.media('silent-video','mp4')
   subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=black:s=160x90:r=10',
    '-t','1.0','-c:v','libx264',str(silent)],check=True)
   picture=studio.media('picture-100','png')
   subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=yellow:s=100x70:r=1',
    '-frames:v','1',str(picture)],check=True)
   with self.assertRaisesRegex(ValueError,'no audio track'):
    studio.render_chapter_command(1,'silent-video','mp4',[
     {'assetId':'picture-100','ext':'png','duration':1}], 'square',1)
   self.assertFalse(list((studio.root/'exports').glob('*.mp4')))
