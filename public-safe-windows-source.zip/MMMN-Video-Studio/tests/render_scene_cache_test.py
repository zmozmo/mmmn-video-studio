"""Real media regression: interrupted / repeated exports reuse only proven source frames."""
import importlib.util
from pathlib import Path
import hashlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('studio_scene_cache',ROOT/'portable'/'studio_server.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class RenderSceneCacheTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=mod.Studio(Path(self.temp.name),'cache-test')
        self.studio.RENDER_DIMENSIONS={'square':(160,160)}
    def tearDown(self):self.temp.cleanup()

    def test_clear_rejects_live_export_and_never_touches_source_media(self):
        source=self.studio.media('sample-image','png')
        source.write_bytes(b'Fake original image contents stay exactly as they were')
        initial=hashlib.sha256(source.read_bytes()).hexdigest()
        cache=self.studio.root/'render-cache'
        key='b'*64
        (cache/f'scene-{key}.mp4').write_bytes(b'TEMPORARY FRAMES')
        (cache/f'scene-{key}.json').write_text('{}')
        (cache/'UNRELATED-USER-PHOTO.jpg').write_bytes(b'untouched')
        self.studio._active_render_job='render-fake'
        with self.assertRaisesRegex(ValueError,'export is running'):
            self.studio.clear_render_cache()
        self.studio._active_render_job=None
        out=self.studio.clear_render_cache()
        self.assertEqual(out['removedCacheFiles'],2)
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),initial)
        self.assertEqual((cache/'UNRELATED-USER-PHOTO.jpg').read_bytes(),b'untouched')
        self.assertEqual(self.studio.render_cache_info()['files'],0)

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg required')
    def test_second_render_reuses_frames_and_tampering_invalidates_cache(self):
        img=self.studio.media('image-cache','png')
        source=self.studio.media('video-cache','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=blue:s=180x110:r=1','-frames:v','1',str(img)],check=True)
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=black:s=120x80:r=15','-f','lavfi','-i',
            'sine=frequency=330:sample_rate=44100','-t','1',
            '-c:v','libx264','-c:a','aac',str(source)],check=True)
        image_sha=hashlib.sha256(img.read_bytes()).hexdigest()
        video_sha=hashlib.sha256(source.read_bytes()).hexdigest()
        req=dict(chapterNumber=1,sourceVideoId='video-cache',sourceVideoExt='mp4',
                 recordedSeconds=1,scenes=[{'assetId':'image-cache','ext':'png','duration':1,'motion':'still'}],
                 preset='square',quality='preview',transitionMode='cut')
        progress=[]
        first=Path(self.studio.render_chapter_command(**req,_progress=lambda phase,c,t:progress.append(phase)))
        self.assertIn('Encoding scene 1/1',progress)
        self.assertEqual(self.studio.render_cache_info()['files'],1)
        progress=[]
        second=Path(self.studio.render_chapter_command(**req,_progress=lambda phase,c,t:progress.append(phase)))
        self.assertIn('Reusing encoded scene 1/1',progress)
        self.assertTrue(second.exists())
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),video_sha)
        self.assertEqual(hashlib.sha256(img.read_bytes()).hexdigest(),image_sha)
        caches=list((self.studio.root/'render-cache').glob('scene-*.mp4'))
        self.assertEqual(len(caches),1)
        caches[0].write_bytes(b'CORRUPTED BY A FAULTY DISK')
        progress=[]
        third=Path(self.studio.render_chapter_command(**req,_progress=lambda phase,c,t:progress.append(phase)))
        self.assertIn('Encoding scene 1/1',progress)
        self.assertNotIn('Reusing encoded scene 1/1',progress)
        self.assertTrue(third.stat().st_size>500)
        self.assertEqual(self.studio.render_cache_info()['files'],1)
        self.assertEqual(hashlib.sha256(img.read_bytes()).hexdigest(),image_sha)
        self.assertEqual(self.studio.clear_render_cache()['originalMediaPreserved'],True)
        self.assertTrue(first.is_file() and second.is_file() and third.is_file())

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg required')
    def test_multi_scene_dissolve_reuses_both_encoded_scenes(self):
        names=['image-red12','image-blue12']
        for name,color in zip(names,['red','blue']):
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                f'color=c={color}:s=180x110:r=1','-frames:v','1',str(self.studio.media(name,'png'))],check=True)
        narrator=self.studio.media('narrator-12','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=black:s=100x80:r=15','-f','lavfi','-i',
            'sine=frequency=400:sample_rate=44100','-t','2','-c:v','libx264',
            '-c:a','aac',str(narrator)],check=True)
        req=dict(chapterNumber=2,sourceVideoId='narrator-12',sourceVideoExt='mp4',
            recordedSeconds=2,scenes=[{'assetId':name,'ext':'png','duration':1,'motion':'still'} for name in names],
            preset='square',quality='preview',transitionMode='dissolve')
        first_phases=[]
        first=Path(self.studio.render_chapter_command(**req,_progress=lambda p,c,t:first_phases.append(p)))
        self.assertEqual(len([p for p in first_phases if p.startswith('Encoding scene')]),2)
        self.assertEqual(self.studio.render_cache_info()['files'],2)
        second_phases=[]
        second=Path(self.studio.render_chapter_command(**req,_progress=lambda p,c,t:second_phases.append(p)))
        self.assertEqual(len([p for p in second_phases if p.startswith('Reusing encoded scene')]),2)
        for output in (first,second):
            raw=subprocess.check_output(['ffprobe','-v','error','-count_frames',
                '-show_entries','stream=codec_type,codec_name,nb_read_frames',
                '-of','json',str(output)])
            import json
            streams={x.get('codec_type'):x for x in json.loads(raw)['streams']}
            self.assertEqual(int(streams['video']['nb_read_frames']),60)
            self.assertEqual(streams['audio']['codec_name'],'aac')

if __name__=='__main__':unittest.main()
