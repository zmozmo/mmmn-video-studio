"""Cinematic visual regression: portrait fit, pan/zoom and scene dissolves.

Real package portraits are used, no synthetic blue/red frame pretending to be a story scene.
"""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('studio_cinematic',ROOT/'portable'/'studio_server.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class CinematicRenderTests(unittest.TestCase):
    def test_ui_connects_motion_transitions_and_local_reference_prep(self):
        app=(ROOT/'web'/'app.js').read_text()
        plan=(ROOT/'web'/'native-render-preflight.mjs').read_text()
        self.assertIn('case \'prepare-references\'',app)
        self.assertIn('request.transitionMode',app)
        self.assertIn('motion:[\'pan\',\'zoom\',\'still\']',plan)

    def test_cinematic_preset_validated_before_render(self):
        with tempfile.TemporaryDirectory() as temp:
            studio=mod.Studio(Path(temp),'token')
            with self.assertRaisesRegex(ValueError,'Unsupported transition'):
                studio.render_chapter_command(chapterNumber=1,sourceVideoId='source-123456',sourceVideoExt='mp4',scenes=[{'assetId':'image-123456','ext':'png','duration':2}],preset='youtube',recordedSeconds=2,transitionMode='wipe')

    @unittest.skipUnless(shutil.which('ffmpeg'),'FFmpeg required for pause auto timing')
    def test_one_click_pause_detection_is_review_only_and_preserves_manual_locks(self):
        with tempfile.TemporaryDirectory() as temp:
            studio=mod.Studio(Path(temp),'token')
            narrator=studio.media('narrator-pause','mp4')
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=black:s=160x90:r=15',
                '-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=44100','-t','4',
                '-c:v','libx264','-c:a','aac',str(narrator)],check=True)
            scenes=[{'id':'scene-a','text':'ဦးသက်ထွန်း အိမ်မှာ ရှိနေသည်။','start':0},
                    {'id':'scene-b','text':'ပျိုမေခင် လာသည်။','start':2,'alignment':'manual-locked'}]
            plan=studio.analyze_narration_pauses(chapterNumber=1,chapterId='ch-01',
                sourceVideoId='narrator-pause',sourceVideoExt='mp4',scenes=scenes,recordedSeconds=4)
            self.assertEqual(plan['schema'],'mmmn.pause-timing.v1')
            self.assertTrue(plan['humanReviewRequired'])
            self.assertEqual(len(plan['scenes']),2)
            self.assertEqual(plan['scenes'][1]['start'],2)
            self.assertEqual(plan['scenes'][1]['status'],'manual-locked')

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg tools needed')
    def test_character_portraits_crossfade_and_keep_full_faces(self):
        with tempfile.TemporaryDirectory() as temp:
            studio=mod.Studio(Path(temp),'token')
            studio.RENDER_DIMENSIONS={'youtube':(480,270)}
            media=ROOT/'web'/'resources'/'images'
            for filename,id in [('05_U_Thet_Tun.png','ref-thettun'),('04_Pyo_May_Khin.png','ref-pyomay'),('01_Htut_Khaung.png','ref-htut')]:
                shutil.copyfile(media/filename,studio.media(id,'png'))
            narration=studio.media('narrator-sample','mp4')
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=black:s=160x90:r=30',
                            '-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=44100',
                            '-t','6','-c:v','libx264','-c:a','aac',str(narration)],check=True)
            out=studio.render_chapter_command(chapterNumber=1,sourceVideoId='narrator-sample',sourceVideoExt='mp4',
                scenes=[{'assetId':'ref-thettun','ext':'png','duration':2,'motion':'pan'},
                        {'assetId':'ref-pyomay','ext':'png','duration':2,'motion':'zoom'},
                        {'assetId':'ref-htut','ext':'png','duration':2,'motion':'still'}],
                preset='youtube',recordedSeconds=6,transitionMode='dissolve')
            details=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames',
                     '-show_entries','stream=codec_name,codec_type,nb_read_frames:format=duration','-of','json',out]))
            streams={s['codec_type']:s for s in details['streams']}
            self.assertEqual(streams['video']['codec_name'],'h264')
            self.assertEqual(streams['audio']['codec_name'],'aac')
            self.assertEqual(int(streams['video']['nb_read_frames']),180)
            self.assertAlmostEqual(float(details['format']['duration']),6.0,delta=.12)
            def sample(t):
                return subprocess.check_output(['ffmpeg','-loglevel','error','-ss',str(t),'-i',out,
                   '-frames:v','1','-vf','scale=32:18,format=rgb24','-f','rawvideo','-'])
            # Three genuinely different visual compositions, plus a mixed dissolve frame.
            a,b,blend,c=sample(.5),sample(1.95),sample(2.12),sample(4.7)
            self.assertNotEqual(a,c)
            self.assertNotEqual(b,blend)
            self.assertFalse(list((studio.root/'exports').glob('render-pending-*')))

if __name__=='__main__':unittest.main()
