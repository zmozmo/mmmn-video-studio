"""Offline-only speech path and HTTP routing regression tests (no AI accuracy claims)."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
from http.server import ThreadingHTTPServer
from unittest import TestCase, skipUnless
from unittest.mock import patch
from urllib.request import Request, urlopen

source = Path(__file__).resolve().parents[1] / 'portable' / 'studio_server.py'
spec=importlib.util.spec_from_file_location('mmmn_studio_server_speech',source)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class OfflineSpeechTrialTests(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.studio=mod.Studio(self.root,'test-token')
    def tearDown(self):self.tmp.cleanup()

    def test_missing_model_and_tool_warn_before_running(self):
        status=self.studio.offline_speech_status()
        self.assertFalse(status['ready'])
        self.assertTrue(any('multilingual' in p for p in status['problems']))
        self.assertTrue(any('whisper-cli' in p for p in status['problems']))
        self.assertTrue((self.root/'models').is_dir())
        self.assertTrue((self.root/'tools').is_dir())

    def test_english_only_model_is_refused(self):
        (self.root/'models'/'ggml-base.en.bin').write_bytes(b'a'*2048)
        self.assertFalse(self.studio.offline_speech_status()['ready'])
        (self.root/'models'/'ggml-base.bin').write_bytes(b'a'*2048)
        self.assertEqual(self.studio.offline_speech_status()['modelName'],'ggml-base.bin')

    def test_invalid_media_cannot_launch_transcriber(self):
        with self.assertRaisesRegex(ValueError,'Unsupported'):
            self.studio.transcribe_narration(1,'video-example','png')
        with self.assertRaisesRegex(ValueError,'Narration video missing'):
            self.studio.transcribe_narration(1,'video-example','mp4')

    def test_http_pause_dispatch_calls_pause_analysis_not_video_renderer(self):
        called=[]
        def fake_pause(**args):
            called.append(args)
            return {'schema':'mmmn.pause-timing.v1','pauseCount':2,'scenes':[]}
        self.studio.analyze_narration_pauses=fake_pause
        self.studio.render_chapter_command=lambda **args: (_ for _ in ()).throw(AssertionError('WRONG RENDER ROUTE'))
        server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            base=f'http://127.0.0.1:{server.server_address[1]}'
            params={'chapterId':'first','chapterNumber':1}
            req=Request(base+'/__api/analyze_narration_pauses',json.dumps(params).encode(),
                {'X-MM-Token':'test-token','Content-Type':'application/json'},'POST')
            resp=json.load(urlopen(req,timeout=5))
            self.assertEqual(resp['result']['pauseCount'],2)
            self.assertEqual(called,[params])
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)

    @skipUnless(shutil.which('ffmpeg'),'FFmpeg required to test local WAV extraction')
    def test_local_transcript_srt_is_preserved_without_overwriting(self):
        # A stub whisper executable validates video -> WAV conversion and SRT plumbing.
        # It DOES NOT perform real recognition; real multilingual quality is untested.
        (self.root/'models'/'ggml-base.bin').write_bytes(b'fake model sample'*160)
        stub=self.root/'tools'/'whisper-cli'
        stub.write_text('#!/usr/bin/env python3\nimport pathlib,sys\na=sys.argv\nout=a[a.index("-of")+1]+".srt"\npathlib.Path(out).write_text("1\\n00:00:00,000 --> 00:00:01,000\\nမြန်မာစာ စမ်းသပ်ချက်\\n",encoding="utf-8")\n',encoding='utf-8')
        stub.chmod(0o700)
        video=self.studio.media('narrator-123456','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=black:s=160x90:r=10',
            '-f','lavfi','-i','sine=frequency=440:sample_rate=16000',
            '-t','1','-c:v','libx264','-c:a','aac',str(video)],check=True)
        original_hash=hashlib.sha256(video.read_bytes()).hexdigest()
        self.assertTrue(self.studio.offline_speech_status()['ready'])
        # Windows cannot execute a shebang-only fake CLI (WinError 193).
        # Execute only this synthetic test stub with sys.executable; actual
        # production whisper-cli.exe discovery/execution is unchanged.
        native_run=subprocess.run
        def run_stub(command,*args,**kwargs):
            if command and Path(command[0]).is_file() and Path(command[0]).samefile(stub):
                command=[sys.executable,str(stub),*command[1:]]
            return native_run(command,*args,**kwargs)
        with patch.object(mod.subprocess,'run',side_effect=run_stub):
            first=self.studio.transcribe_narration(1,'narrator-123456','mp4')
            second=self.studio.transcribe_narration(1,'narrator-123456','mp4')
        self.assertIn('မြန်မာစာ',first['srt'])
        self.assertTrue(first['humanReviewRequired'])
        self.assertNotEqual(first['file'],second['file'])
        self.assertEqual(hashlib.sha256(video.read_bytes()).hexdigest(),original_hash)
        self.assertEqual(len(list((self.root/'transcripts').glob('*.srt'))),2)

if __name__=='__main__':
    import unittest;unittest.main()
