import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const script=path.resolve('scripts/audit-public-source.mjs');
function audit(files){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'mmmn-public-audit-'));
 try{
  for(const [name,contents] of Object.entries(files)){
   const file=path.join(root,name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,contents);
  }
  return spawnSync(process.execPath,[script],{encoding:'utf8',env:{...process.env,MMMN_AUDIT_ROOT:root}});
 }finally{fs.rmSync(root,{recursive:true,force:true});}
}
test('public audit rejects non-demo novel text',()=>{
 const r=audit({'web/resources/novel.txt':'Private first chapter'});
 assert.notEqual(r.status,0);assert.match(r.stderr,/manuscript/);
});
test('public audit rejects private Drive links',()=>{
 const r=audit({'notes.md':['https:', '//drive.google.com/drive/folders/abcdefg'].join('')});
 assert.notEqual(r.status,0);assert.match(r.stderr,/sensitive data pattern/);
});
test('public audit rejects credentials and private database',()=>{
 const r=audit({'secrets.env':'A=B','data/app.sqlite':'secret'});
 assert.notEqual(r.status,0);assert.match(r.stderr,/secret\/data extension/);
});
test('public audit accepts harmless code and demo manuscript',()=>{
 const r=audit({'web/resources/novel.txt':'Demo placeholder.\n','readme.md':'Open source application'});
 assert.equal(r.status,0,r.stderr);
});
test('public audit fails when an image is added instead of vetted demo asset',()=>{
 const r=audit({'web/resources/images/private.png':Buffer.from([137,80,78,71])});
 assert.notEqual(r.status,0);assert.match(r.stderr,/binary image is not an approved/);
});
