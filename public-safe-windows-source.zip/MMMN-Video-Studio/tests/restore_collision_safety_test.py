"""Regression tests: version upgrade/restore must never overwrite previous media."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'portable'))
from studio_server import Studio


class RestoreMediaSafetyTests(unittest.TestCase):
    def test_two_restores_same_millisecond_are_unique_and_preserve_first(self):
        with tempfile.TemporaryDirectory() as tmp:
            studio=Studio(Path(tmp),'test')
            original_id='original-photo-01'
            data=b'Story photo must survive version upgrades'
            studio.media(original_id,'png').write_bytes(data)
            project={'chapters':[{'number':1,'scenes':[{'assetId':original_id}]}],
                     'assets':[{'id':original_id,'name':'scene.png','nativeStored':True}]}
            studio.save_project_state(json=json.dumps(project))
            snap=studio.create_full_local_backup()
            with patch('studio_server.time.time',return_value=123456.789):
                a=studio.restore_local_backup(id=snap['id'])
                first=json.loads(a['project'])['assets'][0]['id']
                first_path=studio.media(first,'png')
                first_hash=hashlib.sha256(first_path.read_bytes()).digest()
                b=studio.restore_local_backup(id=snap['id'])
                second=json.loads(b['project'])['assets'][0]['id']
            self.assertNotEqual(first,second,'Two quick restores must never share media IDs')
            self.assertEqual(hashlib.sha256(first_path.read_bytes()).digest(),first_hash)
            self.assertEqual(studio.media(second,'png').read_bytes(),data)
            self.assertNotEqual(first_path,studio.media(second,'png'))

    def test_restoring_invalid_snapshot_leaves_project_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            studio=Studio(Path(tmp),'test')
            data=b'original'
            studio.media('original-photo-01','png').write_bytes(data)
            project={'chapters':[],'assets':[{'id':'original-photo-01',
                    'name':'sample.png','nativeStored':True}]}
            studio.save_project_state(json=json.dumps(project))
            snap=studio.create_full_local_backup()
            old_project=(studio.root/'project-state.json').read_bytes()
            snap_media=studio.root/'snapshots'/snap['id']/'media'/'original-photo-01.png'
            snap_media.write_bytes(b'corrupted')
            with self.assertRaisesRegex(ValueError,'checksum'):
                studio.restore_local_backup(id=snap['id'])
            self.assertEqual((studio.root/'project-state.json').read_bytes(),old_project)
            self.assertEqual(studio.media('original-photo-01','png').read_bytes(),data)

if __name__=='__main__':unittest.main()

# Direct module-level additional regression case: snapshot metadata must not
# be readable through a link to arbitrary external files.
class SnapshotMetadataSafetyTests(unittest.TestCase):
    def test_reject_snapshot_metadata_symlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            studio=Studio(Path(tmp)/'studio','test')
            project={'chapters':[],'assets':[]}
            studio.save_project_state(json=json.dumps(project))
            snap=studio.create_full_local_backup()
            folder=studio.root/'snapshots'/snap['id']
            manifest=folder/'manifest.json'
            external=Path(tmp)/'other.json'
            external.write_bytes(manifest.read_bytes())
            manifest.unlink()
            try:
                manifest.symlink_to(external)
            except (OSError, NotImplementedError):
                self.skipTest('This test filesystem disallows symlinks')
            with self.assertRaisesRegex(ValueError,'symlink'):
                studio.verify_local_backup(id=snap['id'])
