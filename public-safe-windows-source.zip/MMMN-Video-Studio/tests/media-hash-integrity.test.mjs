import test from 'node:test';
import assert from 'node:assert/strict';
import {chunkSha256,makeNativeMedia} from '../web/native-media.mjs';

test('WebCrypto hashes original bytes without whole-video buffering',async()=>{
 assert.equal(await chunkSha256(new TextEncoder().encode('abc')),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
});
test('chunk checksum mismatch blocks the entire import, then invokes abort',async()=>{
 const calls=[];
 const tauri={core:{convertFileSrc:()=>'',invoke:async(cmd,payload,opts)=>{
   calls.push(cmd);
   if(cmd==='import_media_chunk'){
      assert.match(opts.headers['x-media-sha256'],/^[a-f0-9]{64}$/);
      throw Error('Media chunk checksum mismatch');
   }
   return null;
 }}};
 const file=new Blob([new Uint8Array([1,2,3,4])],{type:'video/mp4'});
 await assert.rejects(()=>makeNativeMedia(tauri).store('vid-123456',file,'recording.mp4'),/checksum mismatch/);
 assert.deepEqual(calls,['begin_media_import','import_media_chunk','abort_media_import']);
});
