import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {makeNativeMedia,extensionFor} from '../web/native-media.mjs';
const SHA='a'.repeat(64);
function fake(nativeCallbacks={}) {
 const calls=[],received=[];let partial=false;
 const tauri={core:{convertFileSrc:path=>`asset:${path}`,async invoke(command,payload,opts){
   calls.push(command);
   if(command==='begin_media_import'){partial=true;return null;}
   if(command==='import_media_chunk'){
     assert.equal(partial,true);
     assert.ok(payload.byteLength<=512*1024);
     assert.equal(Number(opts.headers['x-media-offset']),received.reduce((n,a)=>n+a.length,0));
     const expected=createHash('sha256').update(payload).digest('hex');
     assert.equal(opts.headers['x-media-sha256'],expected);
     received.push(payload);
     if(nativeCallbacks.failChunk)throw Error('simulated disk full');
     return received.reduce((n,a)=>n+a.length,0);
   }
   if(command==='finalize_media_import')return nativeCallbacks.wrongReceipt||{id:payload.id,ext:'mp4',size:received.reduce((n,a)=>n+a.length,0),sha256:SHA};
   if(command==='abort_media_import'){partial=false;return null;}
   return null;
 }}};
 return {bridge:makeNativeMedia(tauri),calls,received};
}
test('large synthetic narration is imported in fixed-size chunks with integrity receipt',async()=>{
 const {bridge,calls,received}=fake();
 const bytes=new Uint8Array(1300001);bytes.fill(2);
 const file=new Blob([bytes],{type:'video/mp4'});
 const progress=[];
 const result=await bridge.store('video-123456',file,'narration.mp4',(n,total)=>progress.push([n,total]));
 assert.equal(result.size,bytes.length);
 assert.equal(received.length,3);
 assert.deepEqual(progress.at(-1),[bytes.length,bytes.length]);
 assert.equal(calls.at(-1),'finalize_media_import');
});
test('native media failures issue abort instead of claiming stored',async()=>{
 const {bridge,calls}=fake({failChunk:true});
 await assert.rejects(bridge.store('video-123456',new Blob([new Uint8Array(10)]),'narration.mp4'),/disk full/);
 assert.equal(calls.at(-1),'abort_media_import');
});
test('invalid native receipt aborts import',async()=>{
 const {bridge,calls}=fake({wrongReceipt:{id:'wrong',ext:'mp4',size:10,sha256:SHA}});
 await assert.rejects(bridge.store('video-123456',new Blob([new Uint8Array(10)]),'narration.mp4'),/integrity acknowledgement/);
 assert.equal(calls.at(-1),'abort_media_import');
});
test('refuses executable and unsupported media types',()=>{
 assert.throws(()=>extensionFor('evil.exe','application/octet-stream'),/Unsupported media/);
 assert.equal(extensionFor('narration.MOV','video/quicktime'),'mov');
});
