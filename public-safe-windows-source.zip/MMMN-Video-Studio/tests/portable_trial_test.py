import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import importlib.util
import threading
from http.server import ThreadingHTTPServer

source=Path(__file__).resolve().parents[1]/'portable'/'studio_server.py'
spec=importlib.util.spec_from_file_location('studio_server',source)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class PortableStudioTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.studio=mod.Studio(Path(self.tmp.name),'test-token')
        self.project={'title':'ငှက်အော်ကျွန်း','chapters':[{'text':'မြန်မာစာ'}],'assets':[]}

    def tearDown(self):self.tmp.cleanup()

    def test_project_survives_reopen_and_recovery(self):
        self.studio.save_project_state(json=json.dumps(self.project,ensure_ascii=False))
        self.assertEqual(json.loads(self.studio.load_project_state())['title'],'ငှက်အော်ကျွန်း')
        self.project['chapters'].append({'text':'chapter 2'})
        self.studio.save_project_state(json=json.dumps(self.project,ensure_ascii=False))
        (self.studio.root/'project-state.json').write_text('{broken','utf-8')
        recovered=json.loads(mod.Studio(self.studio.root,'test-token').load_project_state())
        self.assertEqual(len(recovered['chapters']),1)
        self.studio.save_project_state(json=json.dumps(self.project,ensure_ascii=False))
        self.assertEqual(len(json.loads(self.studio.load_project_state())['chapters']),2)
        self.assertTrue(list(self.studio.root.glob('project-state.corrupt-*.json')))

    def test_chunked_media_import_and_bad_checksum(self):
        blob=b'MMMN video bytes'+bytes(50_000)
        mid='video-123456'
        self.studio.begin_media_import(id=mid,ext='mp4',total=len(blob))
        with self.assertRaisesRegex(ValueError,'checksum'):
            self.studio.import_media_chunk(mid,0,'0'*64,blob)
        self.assertEqual((self.studio.root/'imports'/f'{mid}.partial').stat().st_size,0)
        sha=hashlib.sha256(blob).hexdigest()
        self.studio.import_media_chunk(mid,0,sha,blob)
        receipt=self.studio.finalize_media_import(id=mid)
        self.assertEqual(receipt['sha256'],sha)
        self.assertEqual(self.studio.get_media_info(id=mid,ext='mp4')['size'],len(blob))
        self.assertTrue(self.studio.verify_native_media(id=mid,ext='mp4',expectedSha256=sha)['verified'])
        with self.assertRaisesRegex(ValueError,'SHA-256'):
            self.studio.verify_native_media(id=mid,ext='mp4',expectedSha256='f'*64)

    def test_full_backup_restore_integrity_and_myanmar_text(self):
        mid='image-test123';data=b'PNG fake backup sample'
        self.studio.media(mid,'png').write_bytes(data)
        p={'chapters':[{'text':'ငှက်အော်ကျွန်း','scenes':[{'assetId':mid}]}],
           'assets':[{'id':mid,'name':'a.png','nativeStored':True}]}
        self.studio.save_project_state(json=json.dumps(p,ensure_ascii=False))
        snap=self.studio.create_full_local_backup()
        self.assertTrue(self.studio.verify_local_backup(id=snap['id'])['verified'])
        (self.studio.root/'snapshots'/snap['id']/'media'/f'{mid}.png').write_bytes(b'bad')
        with self.assertRaisesRegex(ValueError,'checksum'):
            self.studio.verify_local_backup(id=snap['id'])
        with self.assertRaisesRegex(ValueError,'checksum'):
            self.studio.restore_local_backup(id=snap['id'])
        self.assertEqual(json.loads(self.studio.load_project_state())['chapters'][0]['text'],'ငှက်အော်ကျွန်း')
        (self.studio.root/'snapshots'/snap['id']/'media'/f'{mid}.png').write_bytes(data)
        result=self.studio.restore_local_backup(id=snap['id'])
        restored=json.loads(result['project'])
        self.assertEqual(restored['chapters'][0]['text'],'ငှက်အော်ကျွန်း')
        new_id=restored['assets'][0]['id']
        self.assertNotEqual(mid,new_id)
        self.assertEqual(restored['chapters'][0]['scenes'][0]['assetId'],new_id)
        self.assertEqual(self.studio.media(new_id,'png').read_bytes(),data)
        self.assertTrue(result['beforeSnapshot'].startswith('snapshot-'))

    def test_http_bridge_auth_and_range(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_address[1]}'
        try:
            html=urlopen(base+'/').read().decode()
            self.assertIn('/__bridge.js',html)
            bridge=urlopen(base+'/__bridge.js').read().decode()
            self.assertIn('window.__TAURI__',bridge)
            self.assertIn('test-token',bridge)
            body=json.dumps({'json':json.dumps(self.project,ensure_ascii=False)}).encode()
            with self.assertRaises(HTTPError) as ex:
                urlopen(Request(base+'/__api/save_project_state',body,{'Content-Type':'application/json'},'POST'))
            self.assertEqual(ex.exception.code,403)
            with self.assertRaises(HTTPError) as ex:
                urlopen(Request(base+'/__api/save_project_state',body,{'X-MM-Token':'test-token','Origin':'https://untrusted.example'},'POST'))
            self.assertEqual(ex.exception.code,403)
            with self.assertRaises(HTTPError) as ex:
                urlopen(Request(base+'/__bridge.js',headers={'Sec-Fetch-Site':'cross-site'}))
            self.assertEqual(ex.exception.code,403)
            req=Request(base+'/__api/save_project_state',body,{'X-MM-Token':'test-token','Content-Type':'application/json'},'POST')
            self.assertEqual(json.loads(urlopen(req).read())['result'],None)
            result=json.loads(urlopen(Request(base+'/__api/load_project_state',b'{}',{'X-MM-Token':'test-token'},'POST')).read())
            self.assertEqual(json.loads(result['result'])['title'],'ငှက်အော်ကျွန်း')
            self.studio.media('image-sample','png').write_bytes(b'0123456789')
            url=base+self.studio.url('image-sample','png')
            req=Request(url,headers={'Range':'bytes=2-5'})
            with urlopen(req) as response:
                self.assertEqual(response.status,206)
                self.assertEqual(response.read(),b'2345')
                self.assertEqual(response.headers['Content-Range'],'bytes 2-5/10')
        finally:server.shutdown();server.server_close();thread.join(timeout=5)

    @unittest.skipUnless(__import__('shutil').which('ffmpeg'),'FFmpeg is not installed in test environment')
    def test_ffmpeg_real_mp4_render(self):
        with tempfile.TemporaryDirectory() as d:
            image=Path(d)/'pic.png';video=Path(d)/'narration.mp4'
            subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi','-i','color=c=blue:s=320x180:r=30',
               '-frames:v','1',str(image)],check=True)
            subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi','-i','testsrc2=s=160x90:r=15',
                '-f','lavfi','-i','sine=frequency=300:sample_rate=44100','-t','2','-c:v','libx264',
                '-c:a','aac','-shortest',str(video)],check=True)
            self.studio.media('image-sample','png').write_bytes(image.read_bytes())
            self.studio.media('video-sample','mp4').write_bytes(video.read_bytes())
            output=self.studio.render_chapter_command(chapterNumber=1,sourceVideoId='video-sample',sourceVideoExt='mp4',
                scenes=[{'assetId':'image-sample','ext':'png','duration':2.0}],preset='square',recordedSeconds=2.0)
            self.assertGreater(Path(output).stat().st_size,1000)
            info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',output]))
            self.assertEqual({x['codec_type'] for x in info['streams']},{'audio','video'})
            self.assertEqual({x['codec_name'] for x in info['streams']},{'aac','h264'})

    @unittest.skipUnless(__import__('shutil').which('ffmpeg') and __import__('shutil').which('ffprobe'),
                         'FFmpeg and FFprobe required for frame-accurate regression fixture')
    def test_mixed_png_jpeg_sizes_render_all_120_frames_and_both_scenes(self):
        # Regression: old still-image concat made an apparently playable MP4
        # with 4 s of AUDIO but only one VIDEO frame for mixed PNG/JPEG sizes.
        import shutil
        with tempfile.TemporaryDirectory() as d:
            self.studio.RENDER_DIMENSIONS={'square':(320,320)}
            blue=self.studio.media('blue-image','png')
            red=self.studio.media('red-image','jpg')
            source=self.studio.media('source-vid','mp4')
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                'color=c=blue:s=320x240:r=1','-frames:v','1',str(blue)],check=True)
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                'color=c=red:s=640x360:r=1','-frames:v','1',str(red)],check=True)
            subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                'color=c=black:s=160x90:r=15','-f','lavfi','-i',
                'sine=frequency=440:sample_rate=44100','-t','4',
                '-c:v','libx264','-c:a','aac',str(source)],check=True)
            output=self.studio.render_chapter_command(chapterNumber=1,
                sourceVideoId='source-vid',sourceVideoExt='mp4',
                scenes=[{'assetId':'blue-image','ext':'png','duration':2},
                        {'assetId':'red-image','ext':'jpg','duration':2}],
                preset='square',recordedSeconds=4)
            details=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames',
                '-show_entries','format=duration:stream=codec_name,codec_type,nb_read_frames',
                '-of','json',output]))
            streams={x['codec_type']:x for x in details['streams']}
            self.assertEqual(streams['video']['codec_name'],'h264')
            self.assertEqual(streams['audio']['codec_name'],'aac')
            self.assertEqual(int(streams['video']['nb_read_frames']),120)
            self.assertAlmostEqual(float(details['format']['duration']),4.0,delta=.12)
            def color(t):
                result=subprocess.run(['ffmpeg','-v','error','-ss',str(t),'-i',output,
                    '-frames:v','1','-vf','scale=2:2,format=rgb24',
                    '-f','rawvideo','-'],capture_output=True,check=True).stdout
                self.assertEqual(len(result),12)
                return tuple(result[:3])
            early,late=color(.5),color(2.5)
            self.assertGreater(early[2],early[0]+100)
            self.assertGreater(late[0],late[2]+100)
            self.assertFalse(list((self.studio.root/'exports').glob('render-pending-*')))

    @unittest.skipUnless(__import__('shutil').which('ffmpeg'), 'FFmpeg required')
    def test_failed_render_preserves_original_and_cleans_staging(self):
        self.studio.RENDER_DIMENSIONS={'square':(160,160)}
        png=self.studio.media('blue-image','png')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=blue:s=160x160:r=1','-frames:v','1',str(png)],check=True)
        # A video without an audio stream must fail: never silently export mute.
        mute=self.studio.media('muted-vid','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=black:s=160x90:r=15','-t','1','-c:v','libx264',str(mute)],check=True)
        with self.assertRaisesRegex(ValueError,'audio|mux'):
            self.studio.render_chapter_command(chapterNumber=1,
                sourceVideoId='muted-vid',sourceVideoExt='mp4',
                scenes=[{'assetId':'blue-image','ext':'png','duration':1}],
                preset='square',recordedSeconds=1)
        self.assertFalse(list((self.studio.root/'exports').glob('render-pending-*')))
        self.assertFalse(list((self.studio.root/'exports').glob('chapter-*.mp4')))

    def test_rust_native_uses_frame_accurate_segments_not_still_concat(self):
        native=(source.parents[1]/'src-tauri'/'src'/'lib.rs').read_text()
        renderer=native.split('fn render_chapter_inner(',1)[1].split('#[tauri::command]',1)[0]
        self.assertIn('frames:v',renderer)
        self.assertIn('segment_name',renderer)
        self.assertIn('previous_frames',renderer)
        self.assertIn('0:v:0',renderer)
        self.assertIn('1:a:0',renderer)
        self.assertNotIn('final_image',renderer)

    @unittest.skipUnless(__import__('shutil').which('ffmpeg') and __import__('shutil').which('ffprobe'),
                         'FFmpeg+ffprobe required for integrated media test')
    def test_local_http_import_save_render_backup_restore_roundtrip(self):
        self.studio.RENDER_DIMENSIONS={'square':(160,160)}
        server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_address[1]}'
        def cmd(command,params):
            body=json.dumps(params).encode('utf-8')
            request=Request(base+'/__api/'+command,body,
                {'X-MM-Token':'test-token','Content-Type':'application/json'},'POST')
            return json.loads(urlopen(request).read())['result']
        def add_file(mid,ext,data):
            self.assertIsNone(cmd('begin_media_import',{'id':mid,'ext':ext,'total':len(data)}))
            digest=hashlib.sha256(data).hexdigest()
            request=Request(base+'/__api/import_media_chunk',data,
                {'X-MM-Token':'test-token','x-media-id':mid,'x-media-offset':'0',
                 'x-media-sha256':digest},'POST')
            result=json.loads(urlopen(request).read())['result']
            self.assertEqual(result,len(data))
            return cmd('finalize_media_import',{'id':mid})
        try:
            with tempfile.TemporaryDirectory() as folder:
                root=Path(folder)
                image=root/'blue.png'
                video=root/'narrator.mp4'
                subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                    'color=c=blue:s=80x60:r=1','-frames:v','1',str(image)],check=True)
                subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                    'color=c=black:s=80x60:r=15','-f','lavfi','-i',
                    'sine=frequency=220:sample_rate=44100','-t','1',
                    '-c:v','libx264','-c:a','aac',str(video)],check=True)
                photo_receipt=add_file('http-image','png',image.read_bytes())
                video_receipt=add_file('http-video','mp4',video.read_bytes())
                self.assertEqual(photo_receipt['sha256'],hashlib.sha256(image.read_bytes()).hexdigest())
                self.assertEqual(video_receipt['size'],video.stat().st_size)
                data={'chapters':[{'number':1,'text':'ဖတ်ပြထားတဲ့ မြန်မာစာ',
                    'scenes':[{'assetId':'http-image','duration':1}],
                    'videoAssetId':'http-video','recordedSeconds':1}],
                    'assets':[{'id':'http-image','name':'blue.png','nativeStored':True},
                              {'id':'http-video','name':'narrator.mp4','nativeStored':True}]}
                self.assertIsNone(cmd('save_project_state',{'json':json.dumps(data,ensure_ascii=False)}))
                output=Path(cmd('render_chapter_command',{'chapterNumber':1,
                    'sourceVideoId':'http-video','sourceVideoExt':'mp4',
                    'scenes':[{'assetId':'http-image','ext':'png','duration':1}],
                    'preset':'square','recordedSeconds':1}))
                self.assertTrue(output.is_file())
                exports=cmd('list_local_exports',{})
                self.assertEqual(len(exports),1)
                self.assertEqual(exports[0]['name'],output.name)
                self.assertEqual(urlopen(base+exports[0]['url']).read(),output.read_bytes())
                with self.assertRaises(HTTPError) as denied:
                    urlopen(base+'/__exports/'+output.name)
                self.assertEqual(denied.exception.code,403)
                info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames',
                    '-show_entries','stream=codec_type,nb_read_frames','-of','json',str(output)]))
                self.assertEqual(int(next(x['nb_read_frames'] for x in info['streams'] if x['codec_type']=='video')),30)
                backup=cmd('create_full_local_backup',{})
                self.assertTrue(cmd('verify_local_backup',{'id':backup['id']})['verified'])
                restored=cmd('restore_local_backup',{'id':backup['id']})
                self.assertTrue(restored['restored'])
                project=json.loads(cmd('load_project_state',{}))
                self.assertEqual(project['chapters'][0]['text'],'ဖတ်ပြထားတဲ့ မြန်မာစာ')
                self.assertNotEqual(project['assets'][0]['id'],'http-image')
                self.assertEqual(project['chapters'][0]['scenes'][0]['assetId'],project['assets'][0]['id'])
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)

if __name__=='__main__':unittest.main()
