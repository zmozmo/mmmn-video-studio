"""Executable local tests for media preflight, requiring only ffmpeg/ffprobe."""
import importlib.util
import subprocess
import tempfile
import unittest
from pathlib import Path

FILE=Path(__file__).resolve().parents[1]/'renderer/render.py'
spec=importlib.util.spec_from_file_location('renderer_module',FILE)
render=importlib.util.module_from_spec(spec)
spec.loader.exec_module(render)

class TestPreflight(unittest.TestCase):
  @classmethod
  def setUpClass(cls):
    cls.tmp=tempfile.TemporaryDirectory(prefix='mmmn_preflight_')
    base=Path(cls.tmp.name)
    cls.voice=base/'voice.wav'
    cls.silent_video=base/'silent.mp4'
    cls.photo=base/'photo.png'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','sine=frequency=420:sample_rate=16000:duration=3',str(cls.voice)],check=True)
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=blue:s=160x90:r=12:d=3','-an',str(cls.silent_video)],check=True)
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=red:s=128x64','-frames:v','1','-update','1',str(cls.photo)],check=True)
    cls.base=base
  @classmethod
  def tearDownClass(cls):cls.tmp.cleanup()
  def test_exact_narration_duration_allowed(self):
    render.validate_narration(self.voice,3.0)
  def test_long_voice_no_longer_silently_cut(self):
    with self.assertRaisesRegex(ValueError,'difference >1 second'):
      render.validate_narration(self.voice,1.5)
  def test_missing_audio_track_rejected(self):
    with self.assertRaisesRegex(ValueError,'no audio track'):
      render.validate_narration(self.silent_video,3.0)
  def test_missing_image_blocks_final_before_rendering(self):
    chapter={'scenes':[{'id':'s1','duration':3,'assetId':'nope'}]}
    with self.assertRaisesRegex(ValueError,'background'):
      render.validate_chapter(chapter,{},self.base,draft=False)
  def test_audio_without_video_not_allowed_as_presenter(self):
    with self.assertRaisesRegex(ValueError,'needs a video'):
      render.validate_narration(self.voice,3,presenter='pip')
  def test_complete_audio_only_story_can_pass(self):
    ch={'audioAssetId':'v','scenes':[{'id':'s1','duration':3,'assetId':'i','motion':'still'}]}
    assets={'v':{'exportPath':'voice.wav'},'i':{'exportPath':'photo.png'}}
    scenes,dur,video,audio=render.validate_chapter(ch,assets,self.base,draft=False)
    self.assertEqual(len(scenes),1)
    self.assertEqual(dur,3)
    self.assertIsNone(video)
    self.assertEqual(audio,self.voice)

if __name__=='__main__':unittest.main()
