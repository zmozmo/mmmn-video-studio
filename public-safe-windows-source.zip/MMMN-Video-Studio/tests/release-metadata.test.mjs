import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = (p) => fs.readFileSync(new URL(`../${p}`, import.meta.url), 'utf8');

test('native, npm and version.txt release versions must match exactly', () => {
  const pkg = JSON.parse(read('package.json'));
  const tauri = JSON.parse(read('src-tauri/tauri.conf.json'));
  const cargoVersion = read('src-tauri/Cargo.toml').match(/\[package\][\s\S]*?\bversion\s*=\s*"([^"]+)"/)?.[1];
  const versionFile = read('version.txt').trim();
  assert.match(versionFile, /^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)?$/,
    'version.txt must contain the version only, not trial release notes');
  assert.equal(versionFile, pkg.version);
  assert.equal(versionFile, tauri.version);
  assert.equal(versionFile, cargoVersion);
});

test('portable trial revision stays separate from native release version', () => {
  const revision = read('TRIAL-REVISION.txt').trim();
  assert.ok(revision.length > 0);
  assert.notEqual(revision, read('version.txt').trim());
});

test('installer release gate remains fail closed until real Windows acceptance', () => {
  const build = read('build-windows.cmd');
  const audit = read('scripts/preinstall-status.mjs');
  assert.match(build, /verify:installer-ready/);
  assert.match(audit, /Windows installer setup\.exe built \+ hash verified/);
  assert.match(audit, /Install → in-place upgrade → restored data verified on Windows/);
  assert.match(audit, /process\.exitCode\s*=\s*1/);
});
