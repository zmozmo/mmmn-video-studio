import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('setup.exe cannot be accidentally built from preinstall source',()=>{
 const cmd=fs.readFileSync('build-windows.cmd','utf8');
 assert.match(cmd,/verify:installer-ready/);
 const readiness=fs.readFileSync('scripts/preinstall-status.mjs','utf8');
 assert.ok(readiness.includes('Windows installer setup.exe built + hash verified')); 
 assert.match(readiness,/if\(process\.argv\.includes\('--require-ready'\)/);
});
test('native video importer verifies SHA-256 of stored files without reading whole file',()=>{
 const rust=fs.readFileSync('src-tauri/src/lib.rs','utf8');
 assert.match(rust,/let mut block=\[0u8; 1024 \* 1024\]/);
 assert.match(rust,/hasher\.update\(&block\[\.\.n\]\)/);
 assert.match(rust,/"sha256":checksum/);
 const js=fs.readFileSync('web/native-media.mjs','utf8');
 assert.match(js,/result\?\.size!==file\.size/);
 assert.match(js,/result\?\.id!==id/);
 assert.match(js,/\^\[a-f0-9\]\{64\}\$/);
});
test('version identity and user storage folder remain stable',()=>{
 const cfg=JSON.parse(fs.readFileSync('src-tauri/tauri.conf.json','utf8'));
 assert.equal(cfg.version,'0.14.0');
 assert.equal(cfg.identifier,'com.mmmn.videostudio');
 assert.equal(cfg.bundle.windows.nsis.installMode,'currentUser');
 assert.match(fs.readFileSync('src-tauri/src/lib.rs','utf8'),/app_local_data_dir/);
});
