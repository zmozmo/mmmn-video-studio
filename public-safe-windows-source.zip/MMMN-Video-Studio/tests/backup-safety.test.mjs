import test from 'node:test';
import assert from 'node:assert/strict';
import {makeZip,readZip} from '../web/zip.mjs';
import {assertProjectShape,auditMediaMetadata,verifyBackupIndex,describeMissingMedia,remapBackupForSafeRestore} from '../web/backup-safety.mjs';
const project=()=>({title:'ငှက်အော်ကျွန်း',chapters:[{audioAssetId:'v',scenes:[{assetId:'i'}]}],assets:[{id:'v',name:'narration.mp4',exportPath:'assets/v.mp4'},{id:'i',name:'BI-001.png',exportPath:'assets/i.png'}]});
const packageFiles=async(items)=>readZip(await makeZip(items));
test('complete local ZIP restores project and both media files',async()=>{
 const f=await packageFiles([{name:'project.json',data:JSON.stringify(project())},{name:'assets/v.mp4',data:new Uint8Array([1,2,3])},{name:'assets/i.png',data:new Uint8Array([4,5,6])}]);
 const result=verifyBackupIndex(f);assert.equal(result.mediaCount,2);assert.equal(result.project.title,'ငှက်အော်ကျွန်း');
});
test('incomplete backup fails BEFORE replacing user project',async()=>{
 const f=await packageFiles([{name:'project.json',data:JSON.stringify(project())},{name:'assets/i.png',data:new Uint8Array([4])}]);
 assert.throws(()=>verifyBackupIndex(f),/Incomplete ZIP backup.*narration.mp4/);
});
test('broken media reference in scene blocks restore',async()=>{
 const p=project();p.chapters[0].scenes[0].assetId='nonexistent';
 const f=await packageFiles([{name:'project.json',data:JSON.stringify(p)},{name:'assets/v.mp4',data:new Uint8Array([1])},{name:'assets/i.png',data:new Uint8Array([2])}]);
 assert.throws(()=>verifyBackupIndex(f),/unknown media ID/);
});
test('duplicate and invalid asset IDs are rejected',()=>{
 const p=project();p.assets.push({...p.assets[0]});assert.throws(()=>assertProjectShape(p),/Duplicate/);
 p.assets[2].id='../escape';assert.throws(()=>assertProjectShape(p),/Invalid asset identifier/);
});
test('media diagnostics detect assets referenced but absent in library',()=>{
 const p=project();p.chapters[0].videoAssetId='lost-video';const x=auditMediaMetadata(p);assert.deepEqual(x.brokenReferences,['lost-video']);
});
test('missing media failure is explicit, not silent',()=>assert.match(describeMissingMedia([{id:'v',name:'recording.mp4'}]),/NOT created.*recording.mp4/));
test('bad ZIP CRC is detected before backup import',async()=>{
 const z=await makeZip([{name:'project.json',data:JSON.stringify(project())}]);const bytes=new Uint8Array(await z.arrayBuffer());
 const i=bytes.indexOf(0x7b,30);bytes[i]^=1;
 await assert.rejects(()=>readZip(new Blob([bytes])),/Corrupted ZIP content/);
});

test('backup restore is copy-on-write: current media IDs are never overwritten',()=>{
  const original=project();let index=0;
  const restored=remapBackupForSafeRestore(original,()=>String(++index));
  assert.equal(restored.assets[0].id,'restored-1');
  assert.equal(restored.assets[1].id,'restored-2');
  assert.equal(restored.chapters[0].audioAssetId,'restored-1');
  assert.equal(restored.chapters[0].scenes[0].assetId,'restored-2');
  assert.equal(original.assets[0].id,'v');
  assert.equal(original.chapters[0].scenes[0].assetId,'i');
  assert.equal(restored.assets[0].exportPath,'assets/v.mp4');
});
