import fs from 'node:fs';import {makeScenes,projectStats} from '../web/core.mjs';
const path=new URL('../web/resources/starter-project.json',import.meta.url);
const project=JSON.parse(fs.readFileSync(path,'utf8'));
function match(text,i){const rules=[['ပျိုမေခင်','drive-4'],['မောင်ခိန်','drive-3'],['ဘိုးသိုက်မောင်း','drive-6'],['ဦးသက်ထွန်း','drive-5'],['ထွဋ်ခေါင်','drive-1'],['ကျွန်း','drive-8'],['ဂူ','drive-8'],['ပင်လယ်','drive-8'],['လှိုင်း','drive-8'],['ရေငန်','drive-8'],['ရန်ကုန်','drive-7']];for(const [word,id] of rules)if(text.includes(word))return id;return i%3===0?'drive-8':'drive-7';}
const sceneIndex=[];
for(const chapter of project.chapters){chapter.scenes=makeScenes(chapter,project.settings);chapter.scenes.forEach((s,i)=>{s.assetId=match(s.text,i);s.motion=i%4===0?'pan':'zoom';sceneIndex.push({chapter:chapter.number,sceneId:s.id,estimatedStart:s.start,estimatedDuration:s.duration,textExcerpt:s.text.slice(0,240),referenceAssetId:s.assetId,finalImageStatus:'needs-review',drivePhotoFolder:project.drive.photosFolder});});}
fs.writeFileSync(path,JSON.stringify(project,null,2));
fs.writeFileSync(new URL('../web/resources/scene-shotlist.json',import.meta.url),JSON.stringify({warning:'Timings inferred from text; not yet tied to real narration. Existing photos are reference placeholders, not final scene art.',createdFor:project.title,scenes:sceneIndex},null,2));
console.log(projectStats(project));console.log('Chapter 1:',project.chapters[0].scenes.length, 'Total shots:',sceneIndex.length);
