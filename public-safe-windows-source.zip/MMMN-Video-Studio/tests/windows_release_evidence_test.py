import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from scripts.verify_windows_release_evidence import verify

class WindowsReleaseEvidenceTest(unittest.TestCase):
    def fixture(self,root):
        p=Path(root)
        payload=b'MZ'+b'valid-test-not-a-real-executable'*90
        (p/'Setup-B.exe').write_bytes(payload)
        (p/'Setup-B.exe.sha256').write_text(hashlib.sha256(payload).hexdigest()+'  Setup-B.exe\n')
        (p/'VERIFIED-IN-PLACE-UPGRADE.txt').write_text('INSTALLER UPGRADE LAB PASS: synthetic test only\n')
        (p/'VERIFIED-UNINSTALL-DATA-PRESERVED.txt').write_text('UNINSTALL DATA PRESERVATION PASS: synthetic test only\n')
        (p/'FFMPEG-VERIFIED.txt').write_text('Media contract PASS H264/AAC; synthetic test only\n')
        for name in ['installed-base-self-test.json','installed-upgrade-self-test.json','installed-upgrade-e2e.json']:
            (p/name).write_text(json.dumps({'status':'PASS'}))
        (p/'python-tests.json').write_text(json.dumps({'passed':True,'completed':True,'full_coverage':True,'test_count':95}))
    def test_complete_artifact_passes(self):
        with tempfile.TemporaryDirectory() as t:
            self.fixture(t)
            r=verify(Path(t))
            self.assertEqual(r['status'],'PASS')
            self.assertEqual(r['python_test_count'],95)
    def test_tampered_setup_is_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            self.fixture(t)
            with (Path(t)/'Setup-B.exe').open('ab') as f:f.write(b'altered')
            with self.assertRaisesRegex(ValueError,'SHA-256'):
                verify(Path(t))
    def test_missing_install_witness_is_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            self.fixture(t)
            (Path(t)/'VERIFIED-UNINSTALL-DATA-PRESERVED.txt').unlink()
            with self.assertRaises(FileNotFoundError):verify(Path(t))
    def test_partial_python_suite_cannot_release(self):
        with tempfile.TemporaryDirectory() as t:
            self.fixture(t)
            (Path(t)/'python-tests.json').write_text(json.dumps({'passed':True,'completed':True,'full_coverage':False,'test_count':93}))
            with self.assertRaisesRegex(ValueError,'full suite'):
                verify(Path(t))

if __name__=='__main__':unittest.main()
