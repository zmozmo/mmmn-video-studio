import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=f=>fs.readFileSync(f,'utf8');
test('Windows installer CI auto-starts on safe main branch source push and on demand',()=>{
 const y=read('.github/workflows/windows-installer-upgrade-lab.yml');
 assert.match(y,/workflow_dispatch:/);
 assert.match(y,/push:\s*\n\s*branches:\s*\[main\]/);
 assert.match(y,/audit-public-source\.mjs/);
 assert.match(y,/cancel-in-progress: false/);
});
test('Windows CI release requires installed upgrade proof and hashes actual installer',()=>{
 const y=read('.github/workflows/windows-installer-upgrade-lab.yml');
 assert.match(y,/windows_installer_probe\.py before/);
 assert.match(y,/windows_installer_probe\.py after/);
 assert.match(y,/windows_portable_exe_smoke\.py/);
 assert.match(y,/windows_edge_ui_smoke\.py/);
 assert.match(y,/Get-FileHash build-lab\/Setup-B\.exe/);
 assert.match(y,/Setup-B\.exe\.sha256/);
 assert.match(y,/VERIFIED-IN-PLACE-UPGRADE\.txt/);
});
test('CI invokes local executable paths explicitly, not ambiguous PowerShell commands',()=>{
 const y=read('.github/workflows/windows-installer-upgrade-lab.yml');
 assert.doesNotMatch(y,/& portable\/bin\//);
 assert.doesNotMatch(y,/& 'dist-(?:base|upgrade)\//);
 assert.match(y,/Resolve-Path 'dist-base\/MMMN-Video-Studio\/MMMN-Video-Studio\.exe'/);
 assert.match(y,/Resolve-Path 'dist-upgrade\/MMMN-Video-Studio\/MMMN-Video-Studio\.exe'/);
});
