"""Source tests for fail-closed Windows installer promotion (NOT Windows execution)."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from scripts.promote_windows_release_candidate import promote, pe_header


def synthetic_pe() -> bytes:
    # Synthetic PE-shaped dummy. This is NOT executable software and these
    # tests DO NOT establish that a real Windows installer was built.
    data = bytearray(1024 * 1024 + 16384)
    data[:2] = b'MZ'
    data[0x3c:0x40] = (0x80).to_bytes(4, 'little')
    data[0x80:0x84] = b'PE\x00\x00'
    data[0x84:0x86] = (0x14c).to_bytes(2, 'little')
    return bytes(data)


def evidence(directory: Path):
    payload = synthetic_pe()
    (directory / 'Setup-B.exe').write_bytes(payload)
    digest = hashlib.sha256(payload).hexdigest()
    (directory / 'Setup-B.exe.sha256').write_text(f'{digest}  Setup-B.exe\n', encoding='ascii')
    for file, message in {
        'VERIFIED-IN-PLACE-UPGRADE.txt':'INSTALLER UPGRADE LAB PASS: synthetic fixture',
        'VERIFIED-UNINSTALL-DATA-PRESERVED.txt':'UNINSTALL DATA PRESERVATION PASS: synthetic fixture',
        'FFMPEG-VERIFIED.txt':'Media contract PASS H264/AAC; synthetic fixture',
    }.items():
        (directory / file).write_text(message)
    for file in ('installed-base-self-test.json','installed-upgrade-self-test.json','installed-upgrade-e2e.json'):
        (directory / file).write_text(json.dumps({'status':'PASS'}))
    (directory / 'python-tests.json').write_text(json.dumps({'passed':True,'completed':True,'full_coverage':True,'test_count':95}))
    return digest


class CandidatePromotionTest(unittest.TestCase):
    def test_synthetic_evidence_pipeline_names_exact_tested_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            digest = evidence(root)
            result = promote(root,'0.14.0')
            final = root / 'MMMN-Video-Studio-Setup-0.14.0.exe'
            self.assertEqual(result['sha256'], digest)
            self.assertEqual(final.read_bytes(), (root/'Setup-B.exe').read_bytes())
            self.assertEqual(result['signed'],False)
            self.assertEqual(result['exact_tested_bytes_reused'],True)
            self.assertTrue((root/'WINDOWS-RELEASE-CANDIDATE.json').is_file())
    def test_promotion_rejects_missing_native_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            evidence(root)
            (root/'VERIFIED-IN-PLACE-UPGRADE.txt').unlink()
            with self.assertRaises(FileNotFoundError): promote(root,'0.14.0')
            self.assertFalse((root/'MMMN-Video-Studio-Setup-0.14.0.exe').exists())
    def test_promotion_rejects_tampered_installer(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            evidence(root)
            with (root/'Setup-B.exe').open('ab') as file:file.write(b'tamper')
            with self.assertRaisesRegex(ValueError,'SHA-256'): promote(root,'0.14.0')
    def test_promotion_rejects_lab_version(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            evidence(root)
            with self.assertRaisesRegex(ValueError,'major.minor.patch'):promote(root,'0.14.0-lab-b')
    def test_promotion_rejects_non_windows_payload(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            evidence(root)
            fake=b'not a windows executable' * 60000
            (root/'Setup-B.exe').write_bytes(fake)
            (root/'Setup-B.exe.sha256').write_text(hashlib.sha256(fake).hexdigest()+'  Setup-B.exe\n')
            with self.assertRaisesRegex(ValueError,'MZ'):promote(root,'0.14.0')
    def test_rejects_undersize_payload(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            evidence(root)
            short=synthetic_pe()[:100_000]
            (root/'Setup-B.exe').write_bytes(short)
            (root/'Setup-B.exe.sha256').write_text(hashlib.sha256(short).hexdigest()+'  Setup-B.exe\n')
            with self.assertRaisesRegex(ValueError,'too small'):promote(root,'0.14.0')
    def test_pe_header_rejects_invalid_offset(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.exe'
            data=bytearray(synthetic_pe());data[0x3c:0x40]=(0xFFFF).to_bytes(4,'little')
            p.write_bytes(data)
            with self.assertRaisesRegex(ValueError,'PE header'):pe_header(p)

if __name__=='__main__':unittest.main()
