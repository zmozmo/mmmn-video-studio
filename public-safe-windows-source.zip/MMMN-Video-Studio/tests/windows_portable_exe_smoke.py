"""Real offline end-to-end smoke test for the Windows portable EXE.

Runs the actual packaged executable (or Python launcher for development) in an
isolated temporary data directory. It never touches a user's existing data.
Checks UI, local authenticated API, native large-file path, backup, restore,
scene motion, narrator audio, MP4 frame count, and chapter export.

Usage: python tests/windows_portable_exe_smoke.py --exe <full-path-to-executable>
       python tests/windows_portable_exe_smoke.py --python-source
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import Request, urlopen
from urllib.error import URLError

ROOT = Path(__file__).resolve().parent.parent


def free_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def launch_and_test(exe=None, source=False, ffmpeg=None, ffprobe=None):
    if not source and not exe:
        raise ValueError('Select either --exe or --python-source')
    exe = Path(exe).resolve() if exe else None
    if exe and not exe.is_file():
        raise ValueError(f'EXE does not exist: {exe}')
    if source:
        cmd = [sys.executable, str(ROOT/'portable/launcher.py')]
    else:
        cmd = [str(exe)]
    with tempfile.TemporaryDirectory(prefix='mmmn-e2e-smoke-') as directory:
        folder = Path(directory)
        data = folder/'data'
        port = free_port()
        env = os.environ.copy()
        env.update(MMMN_TRIAL_DATA_DIR=str(data), MMMN_TRIAL_PORT=str(port), MMMN_NO_BROWSER='1')
        if ffmpeg:
            env['MMMN_FFMPEG'] = ffmpeg
        server = subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        base = f'http://127.0.0.1:{port}'
        def request(path, obj=None, token=None, binary=False, headers=None):
            head = {'Host':f'127.0.0.1:{port}'}
            if token:
                head['X-MM-Token'] = token
            if headers:
                head.update(headers)
            if binary:
                body = obj
            elif obj is not None:
                body = json.dumps(obj,ensure_ascii=False).encode('utf-8')
                head['Content-Type']='application/json'
            else:
                body = None
            with urlopen(Request(base+path, data=body, headers=head,
                                 method='POST' if obj is not None else 'GET'), timeout=180) as r:
                raw=r.read()
            return raw if binary or obj is None else json.loads(raw)['result']
        try:
            token = None
            for i in range(120):
                if server.poll() is not None:
                    raise RuntimeError(f'Executable failed to launch (exit {server.returncode})')
                try:
                    script=request('/__bridge.js').decode('utf-8')
                    match=re.search(r'^const token=(".*?");',script,re.M)
                    if match:
                        token=json.loads(match.group(1))
                        break
                except (OSError, ValueError, URLError):
                    pass
                time.sleep(.25)
            if not token:
                raise RuntimeError('Local Windows Studio server did not start')
            assert b'MMMN Video Studio' in request('/'), 'Offline HTML UI not served'
            assert b'Auto' in request('/app.js'), 'Offline editor JS not served'
            assert request('/resources/starter-project.json'), 'Novel starter resources missing'
            binroot = exe.parent/'_internal'/'portable'/'bin' if exe else ROOT/'portable'/'bin'
            ff = ffmpeg or (str(binroot/'ffmpeg.exe') if (binroot/'ffmpeg.exe').is_file() else shutil.which('ffmpeg'))
            fp = ffprobe or (str(binroot/'ffprobe.exe') if (binroot/'ffprobe.exe').is_file() else shutil.which('ffprobe'))
            assert ff and fp, 'Bundled FFmpeg or FFprobe missing'
            # Real novel character art: verify actual visual changes, not a color-only placeholder.
            def reduce_photo(source, name):
                # Test thumbnail keeps actual character content but avoids
                # decoding multi-megapixel portraits for every zoom frame.
                thumb = folder/name
                subprocess.run([ff,'-v','error','-y','-i',str(ROOT/'web/resources/images'/source),
                    '-vf','scale=320:-2','-frames:v','1',str(thumb)],check=True,
                    capture_output=True,timeout=40)
                return thumb.read_bytes()
            photo = reduce_photo('01_Htut_Khaung.png','first.png')
            second_photo = reduce_photo('04_Pyo_May_Khin.png','second.png')
            recorded=folder/'narrator.mp4'
            encoding=subprocess.run([ff,'-nostdin','-v','error','-y',
                '-f','lavfi','-i','color=c=black:s=160x90:r=30',
                '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
                '-t','2','-c:v','libx264','-c:a','aac',str(recorded)],capture_output=True,text=True,timeout=120)
            if encoding.returncode:
                raise RuntimeError('Sample narration encode failed: '+encoding.stderr[-500:])
            def upload(mid, ext, contents):
                request('/__api/begin_media_import',{'id':mid,'ext':ext,'total':len(contents)},token)
                for offset in range(0,len(contents),512*1024):
                    part=contents[offset:offset+512*1024]
                    request('/__api/import_media_chunk',part,token,binary=True,
                            headers={'x-media-id':mid,'x-media-offset':str(offset),
                                     'x-media-sha256':hashlib.sha256(part).hexdigest()})
                result=request('/__api/finalize_media_import',{'id':mid},token)
                assert result['sha256']==hashlib.sha256(contents).hexdigest(), 'Chunked import corruption'
            upload('smoke-photo-01','png',photo)
            upload('smoke-photo-02','png',second_photo)
            upload('smoke-video-01','mp4',recorded.read_bytes())
            project={'title':'Windows Offline Smoke မြန်မာ',
                     'chapters':[{'number':1,'title':'အခန်း ၁',
                       'scenes':[{'assetId':'smoke-photo-01','duration':1,'motion':'still'},
                                 {'assetId':'smoke-photo-02','duration':1,'motion':'zoom'}],
                       'audioAssetId':'smoke-video-01'}],
                     'assets':[{'id':a,'name':a+'.'+ext,'nativeStored':True} for a,ext in
                               [('smoke-photo-01','png'),('smoke-photo-02','png'),('smoke-video-01','mp4')]]}
            request('/__api/save_project_state',{'json':json.dumps(project,ensure_ascii=False)},token)
            loaded=json.loads(request('/__api/load_project_state',{},token))
            assert loaded==project, 'Project save and load mismatch'
            snapshot=request('/__api/create_full_local_backup',{},token)
            assert snapshot['files']==3 and snapshot['verified'], 'Full media backup incomplete'
            verified=request('/__api/verify_local_backup',{'id':snapshot['id']},token)
            assert verified['files']==3 and verified['verified'], 'Snapshot SHA-256 verification failed'
            result=request('/__api/render_chapter_command',{
                'chapterNumber':1, 'sourceVideoId':'smoke-video-01','sourceVideoExt':'mp4',
                'scenes':[{'assetId':'smoke-photo-01','ext':'png','duration':1,'motion':'still'},
                          {'assetId':'smoke-photo-02','ext':'png','duration':1,'motion':'zoom'}],
                'preset':'square','recordedSeconds':2.0,'quality':'preview'},token)
            video=Path(result)
            assert video.is_file() and video.stat().st_size>1500, 'No exported video'
            probe = subprocess.check_output([fp,'-v','error','-count_frames',
                '-show_entries','stream=codec_type,codec_name,nb_read_frames:format=duration',
                '-of','json',str(video)],timeout=60)
            info=json.loads(probe)
            streams={s['codec_type']:s for s in info['streams']}
            assert streams['video']['codec_name']=='h264' and streams['audio']['codec_name']=='aac', 'Wrong MP4 codecs'
            assert int(streams['video'].get('nb_read_frames') or 0)==60, 'MP4 frames missing'
            assert abs(float(info['format']['duration'])-2)<.35, 'Export duration incorrect'
            # Two visually different character images must NOT accidentally collapse
            # to an H.264 stream containing identical/blank frames.
            def sample_rgb(when):
                return subprocess.check_output([ff,'-v','error','-ss',str(when),
                    '-i',str(video),'-frames:v','1','-vf','scale=16:16',
                    '-pix_fmt','rgb24','-f','rawvideo','-'],timeout=30)
            first,second=sample_rgb(.25),sample_rgb(1.75)
            assert len(first)==16*16*3 and len(second)==16*16*3, 'Cannot inspect video frames'
            average_difference=sum(abs(a-b) for a,b in zip(first,second))/len(first)
            assert average_difference>3.0, f'Scene picture did not visibly change (difference={average_difference:.2f})'
            # The installed Windows EXE must ALSO work without camera/video input.
            # Users may narrate novels into an audio-only WAV (or MP3) file.
            audio_only=folder/'narrator-only.wav'
            audio_encode=subprocess.run([ff,'-nostdin','-v','error','-y','-f','lavfi',
                '-i','sine=frequency=610:sample_rate=44100','-t','2',
                '-c:a','pcm_s16le',str(audio_only)],capture_output=True,text=True,timeout=80)
            if audio_encode.returncode:
                raise RuntimeError('Sample audio-only WAV encode failed: '+audio_encode.stderr[-500:])
            original_audio_bytes=audio_only.read_bytes()
            upload('smoke-audio-01','wav',original_audio_bytes)
            audio_result=request('/__api/render_chapter_command',{
                'chapterNumber':2,'sourceVideoId':'smoke-audio-01','sourceVideoExt':'wav',
                'scenes':[{'assetId':'smoke-photo-01','ext':'png','duration':1,'motion':'still'},
                          {'assetId':'smoke-photo-02','ext':'png','duration':1,'motion':'still'}],
                'preset':'square','recordedSeconds':2.0,'quality':'preview',
                'transitionMode':'dissolve'},token)
            audio_mp4=Path(audio_result)
            assert audio_mp4.is_file() and audio_mp4.stat().st_size>1500, 'Audio-only narration MP4 missing'
            audio_probe=subprocess.check_output([fp,'-v','error','-count_frames',
                '-show_entries','stream=codec_type,codec_name,nb_read_frames:format=duration',
                '-of','json',str(audio_mp4)],timeout=60)
            audio_info=json.loads(audio_probe)
            audio_tracks={s['codec_type']:s for s in audio_info['streams']}
            assert audio_tracks['video']['codec_name']=='h264', 'Audio-only narration has no H.264 video'
            assert audio_tracks['audio']['codec_name']=='aac', 'Audio-only narration has no AAC soundtrack'
            assert int(audio_tracks['video']['nb_read_frames'])==60, 'Audio-only timeline frames missing'
            actual_audio=data/'media'/'smoke-audio-01.wav'
            assert hashlib.sha256(actual_audio.read_bytes()).digest()==hashlib.sha256(original_audio_bytes).digest(), 'Original narration audio modified by export'
            recover=request('/__api/restore_local_backup',{'id':snapshot['id']},token)
            assert recover['project'], 'Restored project missing'
            restored=json.loads(request('/__api/load_project_state',{},token))
            assert restored['title']==project['title'], 'Restored project corrupted'
            assert request('/__api/list_local_backups',{},token), 'Snapshot disappeared'
            assert video.is_file(), 'Restore removed an earlier video export'
            assert audio_mp4.is_file(), 'Restore removed an audio-only narration export'
            return {'status':'PASS','package':'Windows executable' if exe else 'Python source',
                    'checks':['local UI','authenticated offline API','chunked media import','project save/reload',
                              'SHA256 full-media backup','verified restore','real 60-frame H.264/AAC MP4 with verified character-scene change',
                              'audio-only narration WAV renders true 60-frame H.264/AAC MP4',
                              'export survives restore'], 'bytes':video.stat().st_size}
        finally:
            server.terminate()
            try:
                server.wait(timeout=8)
            except subprocess.TimeoutExpired:
                server.kill();server.wait(timeout=8)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--exe')
    g.add_argument('--python-source',action='store_true')
    p.add_argument('--ffmpeg')
    p.add_argument('--ffprobe')
    a=p.parse_args()
    try:
        result=launch_and_test(exe=a.exe,source=a.python_source,ffmpeg=a.ffmpeg,ffprobe=a.ffprobe)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except Exception as err:
        print('MMMN OFFLINE E2E FAIL:',str(err),file=sys.stderr)
        raise SystemExit(1)
