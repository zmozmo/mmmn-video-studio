"""No cloud or real Windows installer needed: test executable package safeguards.

This file also runs in Windows CI, where PyInstaller output is tested again.
"""
from pathlib import Path
import os
import socket
import re
import time
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'portable'))
from studio_server import one_running_studio


class WindowsReleaseSafetyTest(unittest.TestCase):
    def test_single_instance_lock_protects_same_data_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            code = '''import sys,time
sys.path.insert(0,sys.argv[2])
from pathlib import Path
from studio_server import one_running_studio
with one_running_studio(Path(sys.argv[1])):
 print('LOCK_HELD',flush=True)
 time.sleep(60)
'''
            child = subprocess.Popen([sys.executable, '-c', code, tmp, str(ROOT/'portable')],
                                     stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                self.assertEqual(child.stdout.readline().strip(), 'LOCK_HELD')
                with self.assertRaisesRegex(RuntimeError, 'already running'):
                    with one_running_studio(Path(tmp)):
                        pass
            finally:
                child.terminate()
                try:child.communicate(timeout=6)
                except subprocess.TimeoutExpired:
                    child.kill();child.communicate(timeout=6)
            with one_running_studio(Path(tmp)):
                self.assertTrue((Path(tmp)/'.studio-instance.lock').is_file())

    def test_occupied_default_port_uses_different_loopback_port(self):
        with tempfile.TemporaryDirectory() as tmp, socket.socket() as occupied:
            try:
                occupied.bind(('127.0.0.1',8765))
                occupied.listen(1)
            except OSError:
                self.skipTest('Default port is already in use by an unrelated process')
            env=dict(os.environ,MMMN_TRIAL_DATA_DIR=tmp,MMMN_NO_BROWSER='1')
            env.pop('MMMN_TRIAL_PORT',None)
            proc=subprocess.Popen([sys.executable,str(ROOT/'portable/studio_server.py'),'--no-browser'],
                                  env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            try:
                first=proc.stdout.readline()
                self.assertIn('MMMN Windows portable trial:',first)
                port=re.search(r':(\d+)',first)
                self.assertIsNotNone(port)
                self.assertNotEqual(int(port.group(1)),8765)
                self.assertIsNone(proc.poll())
            finally:
                proc.terminate()
                try:proc.communicate(timeout=6)
                except subprocess.TimeoutExpired:
                    proc.kill();proc.communicate(timeout=6)

    def test_self_test_does_not_modify_existing_user_project(self):
        with tempfile.TemporaryDirectory() as tmp:
            home=Path(tmp)
            project=home/'project-state.json'
            project.write_bytes(b'EXISTING USER PROJECT NOT TOUCHED')
            env=dict(os.environ,MMMN_TRIAL_DATA_DIR=str(home))
            process=subprocess.run([sys.executable,str(ROOT/'portable/launcher.py'),'--self-test'],
                                   cwd=ROOT,capture_output=True,text=True,timeout=60,env=env)
            self.assertEqual(process.returncode,0,process.stderr+'\n'+process.stdout)
            self.assertIn('"status": "PASS"',process.stdout)
            self.assertEqual(project.read_bytes(),b'EXISTING USER PROJECT NOT TOUCHED')
            self.assertEqual(sorted(p.name for p in home.iterdir()), ['project-state.json'])

    def test_windows_installer_workflow_guards_both_builds_and_both_installations(self):
        pipeline=(ROOT/'.github/workflows/windows-installer-upgrade-lab.yml').read_text(encoding='utf-8')
        for name in ('base-binary-self-test','upgrade-binary-self-test',
                     'installed-base-self-test','installed-upgrade-self-test'):
            self.assertIn(name+'.json',pipeline)
        self.assertGreaterEqual(pipeline.count('--self-test'),4)
        self.assertLess(pipeline.index('installed-upgrade-self-test'),pipeline.index('windows_installer_probe.py after'))
        self.assertLess(pipeline.index('windows_installer_probe.py after'),pipeline.index('actions/upload-artifact@v4'))

if __name__=='__main__':unittest.main()
