import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('Windows FFmpeg must be explicitly bundled, not silently downloaded',()=>{
 const cfg=JSON.parse(fs.readFileSync('src-tauri/installer.conf.json','utf8'));
 assert.equal(cfg.bundle.resources['resources/bin/ffmpeg.exe'],'bin/ffmpeg.exe');
 assert.equal(cfg.bundle.resources['resources/bin/FFMPEG-BUILD-INFO.txt'],'bin/FFMPEG-BUILD-INFO.txt');
 assert.match(fs.readFileSync('src-tauri/src/lib.rs','utf8'),/root\.join\("bin"\)\.join\(binary\)/);
 const script=fs.readFileSync('build-windows.cmd','utf8');
 assert.match(script,/resources\\bin\\ffmpeg\.exe/);
 assert.match(script,/installer\.conf\.json/);
 assert.match(fs.readFileSync('scripts/prepare-ffmpeg-windows.ps1','utf8'),/No automatic download/);
});
test('fixed Windows installation identity, data outside install folder',()=>{
 const cfg=JSON.parse(fs.readFileSync('src-tauri/tauri.conf.json','utf8'));
 assert.equal(cfg.identifier,'com.mmmn.videostudio');
 assert.equal(cfg.bundle.windows.nsis.installMode,'currentUser');
 assert.equal(cfg.bundle.windows.webviewInstallMode.type,'offlineInstaller');
 assert.equal(cfg.bundle.active,true);
});
