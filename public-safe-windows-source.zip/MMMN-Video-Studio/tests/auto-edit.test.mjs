import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {makeOfflineDraft} from '../web/auto-edit.mjs';

const chapter=()=>({number:1,recordedSeconds:9,scenes:[
 {id:'s1',start:0,duration:3,text:'ရန်ကုန်မြို့ရဲ့ နံနက်ခင်း လမ်းမကြီးမှာ ဆိုက်ကားများ',assetId:null},
 {id:'s2',start:3,duration:3,text:'လက်ဖက်ရည်ဆိုင်လေးမှာ လူနှစ်ဦး ဆုံမိကြသည်',assetId:null},
 {id:'s3',start:6,duration:3,text:'ညအချိန် မြစ်ကမ်းဘေးသို့ လျှောက်သွားကြသည်',assetId:null},
 ],subtitleCues:[
 {start:.1,end:1.2,text:'ရန်ကုန်မြို့ရဲ့ နံနက်ခင်း လမ်းမကြီးမှာ ဆိုက်ကားများ'},
 {start:3.25,end:4.5,text:'လက်ဖက်ရည်ဆိုင်လေးမှာ လူနှစ်ဦး ဆုံမိကြသည်'},
 {start:6.4,end:8.1,text:'ညအချိန် မြစ်ကမ်းဘေးသို့ လျှောက်သွားကြသည်'}
 ]});
const requirements=[
 {chapter:1,id:'BI-001',description:'ရန်ကုန်မြို့ရဲ့ နံနက်ခင်း လမ်းမကြီးမှာ ဆိုက်ကားများ',order:1},
 {chapter:1,id:'BI-002',description:'လက်ဖက်ရည်ဆိုင်လေးမှာ လူနှစ်ဦး ဆုံမိကြသည်',order:2},
 {chapter:1,id:'BI-003',description:'ညအချိန် မြစ်ကမ်းဘေးသို့ လျှောက်သွားကြသည်',order:3},
];
const assets=[{id:'photo-one',name:'BI-001.png',type:'image/png'},
 {id:'photo-two',name:'BI-002.png',type:'image/png'}];

test('one offline draft aligns SRT evidence and assigns only truly imported scene photos',()=>{
 const input=chapter(), original=structuredClone(input);
 const result=makeOfflineDraft(input,requirements,assets);
 assert.equal(result.report.subtitleCues,3);
 assert.equal(result.report.matchedCues,3);
 assert.equal(result.report.automaticApproval,false);
 assert.equal(result.scenes[0].assetId,'photo-one');
 assert.equal(result.scenes[1].assetId,'photo-two');
 assert.equal(result.scenes[2].assetId,null);
 assert.equal(result.scenes[0].imageMatchStatus,'suggested-review');
 assert.ok(result.report.proposedBoundaries>=1);
 assert.ok(Math.abs(result.scenes.reduce((n,s)=>n+s.duration,0)-9)<.01);
 assert.deepEqual(input,original,'the original in-memory project is not modified until user approves');
});

test('manually confirmed picture and manually locked timestamp are immutable',()=>{
 const input=chapter();input.scenes[1].assetId='photo-human';
 input.scenes[1].imageMatchStatus='manual-confirmed';input.scenes[1].visualLocked=true;
 input.scenes[1].alignment='manual-locked';input.scenes[1].start=3;
 const result=makeOfflineDraft(input,requirements,assets);
 assert.equal(result.scenes[1].assetId,'photo-human');
 assert.equal(result.scenes[1].start,3);
 assert.equal(result.report.confirmedPreserved,1);
});

test('unsafe overlapping SRT timestamps are rejected before any changes',()=>{
 const input=chapter();input.subtitleCues[1].start=.6;
 assert.throws(()=>makeOfflineDraft(input,requirements,assets),/require review/);
});

test('without speech cues, no artificial confidence is claimed',()=>{
 const input=chapter();input.subtitleCues=[];
 const result=makeOfflineDraft(input,requirements,assets);
 assert.equal(result.report.matchedCues,0);
 assert.equal(result.report.proposedBoundaries,0);
 assert.match(result.report.timingMode,/estimated/);
});

test('real 22 chapter novel starter can be used without inventing missing background images',()=>{
 const p=JSON.parse(readFileSync(new URL('../web/resources/starter-project.json',import.meta.url)));
 const chapter=p.chapters[0];
 const result=makeOfflineDraft(chapter,p.visualRequirements,p.assets);
 assert.equal(p.chapters.length,22);
 assert.equal(result.scenes.length,chapter.scenes.length);
 assert.equal(result.report.imageAssignments,0,'eight existing reference photos are not BI scene art');
 assert.equal(result.report.reviewRequired,true);
});
