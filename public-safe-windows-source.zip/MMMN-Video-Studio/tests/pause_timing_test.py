import importlib.util
import unittest
from pathlib import Path

path=Path(__file__).resolve().parents[1]/'renderer'/'align_pauses.py'
spec=importlib.util.spec_from_file_location('mmmn_pauses',path)
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class OfflinePauseTests(unittest.TestCase):
    def setUp(self):
        self.scenes=[{'id':'s1','text':'ရန်ကုန်မြို့ လမ်းမ', 'start':0},
                     {'id':'s2','text':'လက်ဖက်ရည်ဆိုင်ထိုင်ကြသည်', 'start':5},
                     {'id':'s3','text':'လှေစီးပြီး ဂူကိုသွားကြသည်','start':10}]
        self.project={'chapters':[{'id':'ch1','scenes':self.scenes}]}
    def test_silence_log_extract(self):
        log='[silencedetect] silence_start: 4.2\n[silencedetect] silence_end: 4.8 | silence_duration: 0.6\n'
        self.assertEqual(mod.parse_silences(log,15),[{'time':4.5,'seconds':0.6}])
    def test_empty_silence_still_returns_safe_proposals(self):
        plan=mod.make_plan(self.project,1,15,[])
        self.assertEqual(len(plan['scenes']),3)
        self.assertEqual(plan['scenes'][-1]['end'],15)
        self.assertTrue(plan['humanReviewRequired'])
        self.assertEqual(plan['scenes'][1]['status'],'length-estimated')
    def test_snap_to_pause_and_no_overlap(self):
        p=mod.make_plan(self.project,1,15,[{'time':5,'seconds':.7},{'time':10,'seconds':.6}])
        self.assertEqual(p['scenes'][1]['start'],5)
        self.assertTrue(all(x['end']>=x['start']+.35-1e-6 for x in p['scenes']))
        self.assertEqual(p['scenes'][1]['status'],'pause-proposed')
    def test_manual_anchor_preserved(self):
        self.scenes[1]['alignment']='manual-locked';self.scenes[1]['start']=7
        p=mod.make_plan(self.project,1,15,[{'time':5,'seconds':.5},{'time':10,'seconds':.5}])
        self.assertEqual(p['scenes'][1]['start'],7)
        self.assertEqual(p['scenes'][1]['status'],'manual-locked')
    def test_bad_manual_anchor_rejected(self):
        self.scenes[1]['alignment']='manual-locked';self.scenes[1]['start']=15
        with self.assertRaisesRegex(ValueError,'Manual timing conflicts'):
            mod.make_plan(self.project,1,15,[])
    def test_invalid_chapter_and_short_audio(self):
        with self.assertRaises(ValueError):mod.make_plan(self.project,2,15,[])
        with self.assertRaises(ValueError):mod.make_plan(self.project,1,.4,[])

if __name__=='__main__':unittest.main()
