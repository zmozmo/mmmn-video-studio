import test from 'node:test';
import assert from 'node:assert/strict';
import {checkpoint,undoSceneEdit,redoSceneEdit} from '../web/edit-history.mjs';
const ch=()=>({number:1,scenes:[{id:'a',start:0,duration:3,assetId:'ref-original',alignment:'manual-locked'}],subtitleCues:[{start:0,end:1,text:'ငှက်အော်ကျွန်း'}],alignmentSummary:'Before',timingNeedsReview:false});

test('scene changes are undoable and redoable without changing original media IDs',()=>{
  const x=ch();checkpoint(x,'Auto Draft');
  x.scenes[0].assetId='ref-new';x.scenes[0].start=1;
  x.alignmentSummary='Draft';x.subtitleCues[0].text='edited';x.timingNeedsReview=true;
  const result=undoSceneEdit(x);
  assert.equal(result.reason,'Auto Draft');
  assert.equal(x.scenes[0].assetId,'ref-original');
  assert.equal(x.scenes[0].start,0);
  assert.equal(x.subtitleCues[0].text,'ငှက်အော်ကျွန်း');
  assert.equal(x.alignmentSummary,'Before');
  assert.equal(x.timingNeedsReview,false);
  redoSceneEdit(x);
  assert.equal(x.scenes[0].assetId,'ref-new');
  assert.equal(x.subtitleCues[0].text,'edited');
});

test('recovery history survives JSON save/reopen and is bounded',()=>{
 const x=ch();for(let i=0;i<9;i++){checkpoint(x,'Edit '+i);x.scenes[0].duration+=1;}
 assert.equal(x.undoHistory.length,6);
 const afterRestart=JSON.parse(JSON.stringify(x));
 assert.equal(undoSceneEdit(afterRestart).reason,'Edit 8');
 assert.equal(afterRestart.scenes[0].duration,11);
});

test('a new edit invalidates redo and does not recursively snapshot history',()=>{
 const x=ch();checkpoint(x,'first');x.scenes[0].duration=5;
 undoSceneEdit(x);assert.equal(x.redoHistory.length,1);
 checkpoint(x,'new');assert.equal(x.redoHistory.length,0);
 assert.equal(x.undoHistory[0].undoHistory,undefined);
});

test('invalid checkpoint refuses to modify current timeline',()=>{
 const x=ch();x.undoHistory=[{reason:'damaged',scenes:null}];const prior=structuredClone(x.scenes);
 assert.throws(()=>undoSceneEdit(x),/damaged/);
 assert.deepEqual(x.scenes,prior);
});
