import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const witness=fs.readFileSync('tests/windows_installer_probe.py','utf8');
const ci=fs.readFileSync('.github/workflows/windows-installer-upgrade-lab.yml','utf8');
test('upgrade witness checks exact disk hashes of project and both media',()=>{
  for(const text of ['project_file_sha256','image_file_sha256','video_file_sha256','disk_path.read_bytes()'])
    assert.ok(witness.includes(text),`Missing upgrade evidence: ${text}`);
});
test('server acknowledgement cannot silently fake native media verification',()=>{
  assert.match(witness,/result\.get\('verified'\) is not True/);
  assert.match(witness,/result\.get\('sha256'\)!=expected\[key\]/);
});
test('Windows CI uploads installer only after installed upgrade render and SHA verification',()=>{
  const upgrade=ci.indexOf('PROVE recovery, unchanged project/media hashes');
  const upload=ci.indexOf('Upload DEBUG setup only if EVERY real Windows upgrade step passed');
  assert.ok(upgrade>0&&upload>upgrade);
  assert.match(ci,/if-no-files-found: error/);
});
