import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
const root=resolve(import.meta.dirname,'..');
test('dependency-free UI test bundle builds and is valid JavaScript',()=>{
 const dir=mkdtempSync(join(tmpdir(),'mmmn-js-smoke-'));
 try{
  const out=join(dir,'bundle.js');
  execFileSync(process.execPath,[join(root,'scripts','bundle-ui-for-test.mjs'),out]);
  const source=readFileSync(out,'utf8');
  assert.ok(source.includes('__mods["core.mjs"]'));
  assert.ok(source.includes('render_cache_info'));
  assert.doesNotThrow(()=>new Function(source));
 }finally{rmSync(dir,{recursive:true,force:true});}
});
