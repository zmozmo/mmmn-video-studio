import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from importlib.machinery import SourceFileLoader

root=Path(__file__).resolve().parents[1]
mod=SourceFileLoader('snapshot_recovery',str(root/'tools'/'snapshot_recovery.py')).load_module()


class SnapshotRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.snap=self.root/'snapshot-1770000000000-123'
        (self.snap/'media').mkdir(parents=True)
        self.body=b'hello offline\x00 media'
        (self.snap/'media'/'video-12345.mp4').write_bytes(self.body)
        self.project={'title':'ငှက်အော်ကျွန်း','chapters':[], 'assets':[{'id':'video-12345','name':'test.mp4','nativeStored':True}]}
        raw=json.dumps(self.project,ensure_ascii=False,separators=(',',':')).encode()
        (self.snap/'project-state.json').write_bytes(raw)
        manifest={'format':'mmmn-local-snapshot-v1','appVersion':'0.11.0','stateSha256':hashlib.sha256(raw).hexdigest(),
          'media':[{'id':'video-12345','ext':'mp4','bytes':len(self.body),'sha256':hashlib.sha256(self.body).hexdigest()}]}
        (self.snap/'manifest.json').write_text(json.dumps(manifest))
    def tearDown(self):self.tmp.cleanup()
    def test_valid_snapshot(self):
        self.assertEqual(mod.verify(self.snap)['media'],1)
    def test_detect_corrupt_media(self):
        (self.snap/'media'/'video-12345.mp4').write_bytes(b'corrupted file')
        with self.assertRaisesRegex(ValueError,'Corrupt media'):mod.verify(self.snap)
    def test_detect_missing_media(self):
        (self.snap/'media'/'video-12345.mp4').unlink()
        with self.assertRaisesRegex(ValueError,'Media missing'):mod.verify(self.snap)
    def test_detect_project_modification(self):
        (self.snap/'project-state.json').write_text('{}')
        with self.assertRaisesRegex(ValueError,'Project checksum'):mod.verify(self.snap)
    def test_recover_into_new_folder_without_changing_source(self):
        out=self.root/'recovered'
        self.assertEqual(mod.recover(self.snap,out)['media'],1)
        self.assertEqual((out/'media'/'video-12345.mp4').read_bytes(),self.body)
        self.assertEqual((self.snap/'media'/'video-12345.mp4').read_bytes(),self.body)
        with self.assertRaises(FileExistsError):mod.recover(self.snap,out)
    def test_prevent_recovery_inside_source(self):
        with self.assertRaisesRegex(ValueError,'inside'):mod.recover(self.snap,self.snap/'subfolder')


if __name__=='__main__':unittest.main()
