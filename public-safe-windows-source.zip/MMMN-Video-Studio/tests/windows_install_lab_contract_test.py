"""Ensure CI never reports a Windows installer safe without real upgrade testing."""
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parent.parent
class WindowsInstallerLabContractTest(unittest.TestCase):
    def test_stable_per_user_install_and_no_data_folder_deletion(self):
        nsis=(ROOT/'windows-installer/MMMN-Video-Studio.nsi').read_text()
        self.assertIn('InstallDir "$LOCALAPPDATA\\Programs\\MMMN Video Studio"',nsis)
        self.assertIn('RequestExecutionLevel user',nsis)
        self.assertIn('DisplayVersion',nsis)
        self.assertIn('WriteUninstaller',nsis)
        self.assertNotIn('MUI_PAGE_DIRECTORY',nsis)
        self.assertNotIn('RMDir /r "$LOCALAPPDATA',nsis)
        self.assertNotIn('RMDir /r "$INSTDIR"',nsis)
        self.assertIn('RMDir /r "$INSTDIR\\_internal"',nsis)
        self.assertIn('Delete "$INSTDIR\\${APP_EXE}"',nsis)

    def test_windows_workflow_always_runs_real_in_place_upgrade_probe(self):
        workflow=(ROOT/'.github/workflows/windows-installer-upgrade-lab.yml').read_text()
        self.assertIn('workflow_dispatch:',workflow)
        self.assertIn('\n  push:',workflow)
        self.assertIn('branches: [main]',workflow)
        self.assertIn('audit-public-source.mjs',workflow)
        self.assertIn('windows_installer_probe.py before',workflow)
        self.assertIn('windows_installer_probe.py after',workflow)
        self.assertIn('Setup-A.exe',workflow)
        self.assertIn('Setup-B.exe',workflow)
        self.assertIn('IN-PLACE UPGRADE FAILED',workflow)
        self.assertIn('actions/upload-artifact@v4',workflow)
        self.assertLess(workflow.index('windows_installer_probe.py after'),workflow.index('actions/upload-artifact@v4'))

    def test_python_trial_keeps_data_outside_program_files(self):
        source=(ROOT/'portable/studio_server.py').read_text()
        self.assertIn("'MMMN-Video-Studio-Trial'",source)
        self.assertIn("'preupgrade-metadata'",source)

if __name__=='__main__':unittest.main()
