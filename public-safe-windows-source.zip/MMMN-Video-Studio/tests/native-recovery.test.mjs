import {test} from 'node:test';
import assert from 'node:assert/strict';
import {makeNativeRecovery} from '../web/native-recovery.mjs';

test('browser preview correctly hides native backup controls',()=>{
  assert.equal(makeNativeRecovery(undefined).available,false);
});

test('backup, list, verification and recovery do not use any network client', async()=>{
  const calls=[];
  const api=makeNativeRecovery({core:{invoke:async(name,args)=>{calls.push({name,args});return name;}}});
  await api.create();await api.list();await api.verify('snapshot-1700000000000-42');await api.restore('snapshot-1700000000000-42');
  assert.deepEqual(calls.map(c=>c.name),[
    'create_full_local_backup','list_local_backups','verify_local_backup','restore_local_backup'
  ]);
  assert.deepEqual(calls[2].args,{id:'snapshot-1700000000000-42'});
});

test('backup path traversal and fabricated snapshot IDs are blocked before invoking Rust',()=>{
  let called=false;
  const api=makeNativeRecovery({core:{invoke:()=>{called=true;}}});
  for(const id of ['../secret','snapshot-../','snapshot-abc','snapshot-1-2/../../../','snapshot-1-2\\other','snapshot-1-2.partial']){
    assert.throws(()=>api.verify(id),/Invalid backup identifier/);
    assert.throws(()=>api.restore(id),/Invalid backup identifier/);
  }
  assert.equal(called,false);
});
