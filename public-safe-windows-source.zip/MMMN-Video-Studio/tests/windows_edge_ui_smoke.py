"""Windows-only: launch the ACTUAL packaged MMMN EXE and render its real UI in Edge.

This is an isolated browser smoke test, not a substitute for full human editor QA.
No project under %LOCALAPPDATA% is touched; both server and browser profiles are temporary.
"""
from __future__ import annotations
import argparse
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import urlopen


def edge_executable(explicit: str | None):
    if explicit:
        p = Path(explicit)
        if p.is_file(): return p
        raise FileNotFoundError(f'Edge not found at {p}')
    import shutil
    candidate = shutil.which('msedge.exe')
    if candidate: return Path(candidate)
    for variable in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
        root = os.environ.get(variable)
        if root:
            p = Path(root) / 'Microsoft' / 'Edge' / 'Application' / 'msedge.exe'
            if p.is_file(): return p
    raise FileNotFoundError('Microsoft Edge is required for Windows GUI smoke test')


def unused_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def run(exe: Path, edge: Path):
    if not exe.is_file(): raise FileNotFoundError(f'Windows EXE is missing: {exe}')
    with tempfile.TemporaryDirectory(prefix='mmmn-win-gui-') as temp:
        p = Path(temp)
        port = unused_port()
        env = dict(os.environ,
                   MMMN_TRIAL_DATA_DIR=str(p / 'data'),
                   MMMN_TRIAL_PORT=str(port), MMMN_NO_BROWSER='1')
        server_log = p / 'server.log'
        with server_log.open('wb') as log:
            server = subprocess.Popen([str(exe)], env=env, stdout=log, stderr=subprocess.STDOUT)
            try:
                url = f'http://127.0.0.1:{port}/'
                for _ in range(100):
                    if server.poll() is not None:
                        raise RuntimeError(f'Windows EXE closed unexpectedly ({server.returncode})')
                    try:
                        with urlopen(url, timeout=1) as response:
                            if response.status == 200: break
                    except OSError:
                        pass
                    time.sleep(.2)
                else:
                    raise RuntimeError('EXE did not serve the offline editor UI')
                # Use a unique browser profile so it never reads personal Edge data.
                result = subprocess.run([str(edge), '--headless=new', '--disable-gpu',
                    '--no-first-run', '--no-default-browser-check',
                    '--disable-extensions', '--disable-background-networking',
                    f'--user-data-dir={p / "edge-profile"}',
                    '--virtual-time-budget=12000', '--dump-dom', url],
                    capture_output=True, text=True, errors='replace', timeout=65)
                html = result.stdout
                if result.returncode != 0:
                    raise RuntimeError('Edge headless failed: ' + result.stderr[-1200:])
                if 'class="shell"' not in html or 'class="main"' not in html:
                    raise RuntimeError('Editor did not render (blank/error/loading UI): ' + html[-900:])
                if 'MMMN Studio' not in html or 'Project Dashboard' not in html or 'Video Timeline' not in html:
                    raise RuntimeError('Real Windows browser UI missing expected editor controls')
                if 'Error:' in html and 'Error:' in html.split('id="app"')[-1][:200]:
                    raise RuntimeError('Editor entered error state')
                print('WINDOWS EDGE UI SMOKE PASS: actual packaged EXE, rendered editor, isolated data')
            except Exception:
                log.flush()
                print('Windows EXE server log:\n' + server_log.read_text(errors='replace')[-2000:], file=sys.stderr)
                raise
            finally:
                server.terminate()
                try: server.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    server.kill(); server.wait(timeout=8)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--exe', required=True, type=Path)
    parser.add_argument('--edge', default=None)
    args = parser.parse_args()
    try:
        run(args.exe.resolve(), edge_executable(args.edge))
    except Exception as error:
        print('WINDOWS EDGE UI SMOKE FAIL:', error, file=sys.stderr)
        raise SystemExit(1)
