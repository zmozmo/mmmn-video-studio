import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('Windows in-place upgrade evidence compares original project and imported media SHA256',()=>{
 const src=fs.readFileSync('tools/check-windows-upgrade-data.ps1','utf8');
 assert.match(src,/Get-FileHash/);
 assert.match(src,/project-state\.json/);
 assert.match(src,/media\//);
 assert.match(src,/before-upgrade\.json/);
 assert.match(src,/ContainsKey/);
 assert.match(src,/UPGRADE DATA AUDIT PASS/);
 assert.doesNotMatch(src,/Remove-Item|Uninstall-Package|Set-Content -LiteralPath \$root/);
});
