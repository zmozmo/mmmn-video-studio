import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const web=path.resolve('web');
const local=(ref)=>path.resolve(web,ref);
test('the offline Tauri app shell has no remote script or stylesheet dependency',()=>{
  const html=fs.readFileSync(path.join(web,'index.html'),'utf8');
  const refs=[...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(x=>x[1]);
  assert.ok(refs.includes('app.js') && refs.includes('style.css'));
  for(const ref of refs){
    assert.ok(!/^(?:https?:)?\/\//.test(ref),`Remote dependency: ${ref}`);
    assert.ok(fs.statSync(local(ref)).isFile(),`Missing static asset: ${ref}`);
  }
});
test('all packaged 1970s story reference images exist on disk for offline preview',()=>{
  const starter=JSON.parse(fs.readFileSync(path.join(web,'resources/starter-project.json'),'utf8'));
  assert.equal(starter.chapters.length,22);
  assert.ok(starter.assets.length>=8);
  for(const asset of starter.assets){
    if(asset.bundledUrl){
      const full=local(asset.bundledUrl);
      assert.ok(full.startsWith(web+path.sep),'Invalid packaged asset path');
      assert.ok(fs.statSync(full).size>0,`Empty image ${asset.name}`);
    }
  }
});
test('all main JS modules are included for offline deployment',()=>{
  const script=fs.readFileSync(path.join(web,'app.js'),'utf8');
  for(const [,ref] of script.matchAll(/from\s+['"](\.\/[^'"]+)['"]/g)){
    assert.ok(fs.existsSync(path.join(web,ref)),`Missing JS import ${ref}`);
  }
});
