"""R7: Job progress, safe cancellation, and quick preview render regression."""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('studio_jobs',ROOT/'portable'/'studio_server.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class RenderJobTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.studio=mod.Studio(Path(self.temp.name),'secret')
        self.req={'chapterNumber':1,'sourceVideoId':'source-vid','sourceVideoExt':'mp4',
                  'scenes':[{'assetId':'image-sample','ext':'png','duration':1}],
                  'preset':'square','quality':'preview','recordedSeconds':1}
    def tearDown(self):self.temp.cleanup()
    def wait_for_status(self,id,terminal,seconds=60):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            st=self.studio.get_render_job_status(id=id)
            if st['status'] in terminal:return st
            time.sleep(.1)
        self.fail('Render job did not finish: '+str(st))

    def test_local_http_render_job_api_is_token_protected(self):
        from http.server import ThreadingHTTPServer
        from urllib.request import Request,urlopen
        from urllib.error import HTTPError
        server=ThreadingHTTPServer(('127.0.0.1',0),mod.handler_factory(self.studio))
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        base=f'http://127.0.0.1:{server.server_address[1]}'
        try:
            request=Request(base+'/__api/current_render_job',b'{}',
                {'Content-Type':'application/json'},'POST')
            with self.assertRaises(HTTPError) as denied:
                urlopen(request)
            self.assertEqual(denied.exception.code,403)
            request=Request(base+'/__api/current_render_job',b'{}',
                {'X-MM-Token':'secret','Content-Type':'application/json'},'POST')
            self.assertIsNone(json.loads(urlopen(request).read())['result'])
            request=Request(base+'/__api/start_render_job',json.dumps(self.req).encode(),
                {'X-MM-Token':'secret','Content-Type':'application/json'},'POST')
            result=json.loads(urlopen(request).read())['result']
            done=self.wait_for_status(result['id'],{'failed'})
            self.assertEqual(done['status'],'failed')
            req=Request(base+'/__api/get_render_job_status',json.dumps({'id':result['id']}).encode(),
                {'X-MM-Token':'secret','Content-Type':'application/json'},'POST')
            self.assertEqual(json.loads(urlopen(req).read())['result']['status'],'failed')
        finally:
            server.shutdown();server.server_close();thread.join(timeout=4)

    def test_reject_unknown_job_and_illegal_quality(self):
        with self.assertRaisesRegex(ValueError,'Unknown render job'):
            self.studio.get_render_job_status(id='render-'+'a'*24)
        with self.assertRaisesRegex(ValueError,'Invalid quality'):
            self.studio.render_chapter_command(**{**self.req,'quality':'unsafe'})

    def test_concurrent_job_blocked_then_cancel_safe(self):
        started=threading.Event()
        def waiting_job(**kw):
            started.set()
            while not kw['_cancel'].is_set():time.sleep(.01)
            raise mod.RenderCancelled('Stop')
        self.studio.render_chapter_command=waiting_job
        first=self.studio.start_render_job(**self.req)
        self.assertTrue(started.wait(5))
        with self.assertRaisesRegex(ValueError,'already running'):
            self.studio.start_render_job(**self.req)
        self.studio.cancel_render_job(id=first['id'])
        finished=self.wait_for_status(first['id'],{'cancelled'})
        self.assertEqual(finished['status'],'cancelled')
        self.assertIsNone(self.studio.current_render_job())
        self.assertFalse(list((self.studio.root/'exports').glob('chapter-*.mp4')))

    def test_failed_job_does_not_claim_success(self):
        first=self.studio.start_render_job(**self.req)
        result=self.wait_for_status(first['id'],{'failed'})
        self.assertEqual(result['status'],'failed')
        self.assertIsNotNone(result['error'])
        self.assertFalse(list((self.studio.root/'exports').glob('chapter-*.mp4')))

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg / ffprobe required')
    def test_preview_job_progress_saves_verified_video(self):
        self.studio.RENDER_DIMENSIONS={'square':(320,320)}
        image=self.studio.media('image-sample','png')
        video=self.studio.media('source-vid','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=blue:s=300x200:r=1','-frames:v','1',str(image)],check=True)
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=black:s=120x80:r=15','-f','lavfi','-i',
            'sine=frequency=440:sample_rate=44100','-t','1',
            '-c:v','libx264','-c:a','aac',str(video)],check=True)
        first=self.studio.start_render_job(**self.req)
        self.assertRegex(first['id'],r'^render-[a-f0-9]{24}$')
        result=self.wait_for_status(first['id'],{'complete','failed'},seconds=90)
        self.assertEqual(result['status'],'complete',result['error'])
        self.assertEqual(result['percent'],100)
        export=Path(result['output'])
        self.assertTrue(export.is_file())
        raw=subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries',
            'stream=codec_type,codec_name,width,height,nb_read_frames','-of','json',str(export)])
        streams={x['codec_type']:x for x in json.loads(raw)['streams']}
        self.assertEqual(streams['video']['codec_name'],'h264')
        self.assertEqual(streams['audio']['codec_name'],'aac')
        self.assertEqual((streams['video']['width'],streams['video']['height']),(160,160))
        self.assertEqual(int(streams['video']['nb_read_frames']),30)
        self.assertEqual(len(self.studio.list_local_exports()),1)
        self.assertEqual(self.studio.media('image-sample','png').read_bytes(),image.read_bytes())
        self.assertFalse(list((self.studio.root/'exports').glob('render-pending-*')))

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg / ffprobe required')
    def test_cancel_real_encoding_never_commits_partial_output(self):
        self.studio.RENDER_DIMENSIONS={'square':(320,320)}
        image=self.studio.media('image-sample','png')
        video=self.studio.media('source-vid','mp4')
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=red:s=320x240:r=1','-frames:v','1',str(image)],check=True)
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
            'color=c=black:s=120x80:r=15','-f','lavfi','-i',
            'anullsrc=r=44100:cl=mono','-t','12','-c:v','libx264','-c:a','aac',str(video)],check=True)
        req={**self.req,'recordedSeconds':12,'scenes':[{'assetId':'image-sample','ext':'png','duration':12,'motion':'zoom'}]}
        started=self.studio.start_render_job(**req)
        self.studio.cancel_render_job(id=started['id'])
        result=self.wait_for_status(started['id'],{'cancelled','complete','failed'},seconds=30)
        self.assertEqual(result['status'],'cancelled',result)
        self.assertEqual(list((self.studio.root/'exports').glob('chapter-*.mp4')),[])
        self.assertEqual(list((self.studio.root/'exports').glob('render-pending-*')),[])

if __name__=='__main__':unittest.main()
