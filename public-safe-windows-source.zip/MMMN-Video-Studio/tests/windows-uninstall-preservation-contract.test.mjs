import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const ci = readFileSync(new URL('../.github/workflows/windows-installer-upgrade-lab.yml', import.meta.url), 'utf8');
test('Windows release requires install then upgrade then render then uninstall preservation', () => {
  const labels = [
    'Actually install A, start installed EXE, write test project and media',
    'Compile second release and update IN PLACE without uninstall',
    'PROVE recovery, unchanged project/media hashes and packaged MP4 after upgrade',
    'Uninstall upgraded app and prove every synthetic project/media byte survives',
    'Upload DEBUG setup only if EVERY real Windows upgrade step passed'
  ];
  const positions = labels.map(label => ci.indexOf('- name: ' + label));
  assert.ok(positions.every(index => index > -1), `Missing required gate: ${positions}`);
  assert.ok(positions.every((index, i) => !i || index > positions[i - 1]));
});
test('uninstall gate verifies disk hashes, removes program and preserves recovery evidence', () => {
  assert.match(ci, /Get-FileHash \$path -Algorithm SHA256/);
  assert.match(ci, /Join-Path \$env:MMMN_LAB_DATA 'MMMN-Video-Studio-Trial'/);
  assert.match(ci, /UNINSTALL ALTERED USER DATA/);
  assert.match(ci, /Uninstall\.exe/);
  assert.match(ci, /VERIFIED-UNINSTALL-DATA-PRESERVED\.txt/);
  assert.match(ci, /HKCU:\\Software\\Microsoft/);
});
