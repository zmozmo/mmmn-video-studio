import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
test('blocking multi-gigabyte disk IO is spawned on worker threads',()=>{
 const code=fs.readFileSync('src-tauri/src/snapshots.rs','utf8');
 for(const name of ['create_full_local_backup','list_local_backups','verify_local_backup','restore_local_backup']){
   assert.match(code,new RegExp(`pub async fn ${name}\\(`));
 }
 assert.equal((code.match(/spawn_blocking\(move\|\|/g)||[]).length,4);
 assert.match(code,/const CHUNK: usize = 1024 \* 1024;/);
 assert.match(code,/sha256_file/);
});
test('restore is copy-on-write and preserves copied media if metadata commit might have occurred',()=>{
 const code=fs.readFileSync('src-tauri/src/snapshots.rs','utf8');
 assert.match(code,/let before=create_full_local_backup_inner\(app\.clone\(\)\)/);
 assert.match(code,/let mut committing=false/);
 assert.match(code,/if !committing \{for file in new_files/);
 assert.match(code,/rewrite_ids\(&mut state,&mapping\)/);
});
