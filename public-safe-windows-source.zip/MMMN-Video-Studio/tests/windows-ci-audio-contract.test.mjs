import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const flow = readFileSync(new URL('../.github/workflows/windows-installer-upgrade-lab.yml', import.meta.url), 'utf8');
test('Windows installer runner encodes and verifies H264 plus AAC audio together', () => {
  assert.match(flow, /-c:v libx264[^\n]*-c:a aac/);
  assert.match(flow, /\$_ -eq 'h264'/);
  assert.match(flow, /\$_ -eq 'aac'/);
  assert.match(flow, /FFMPEG-VERIFIED\.txt/);
});
