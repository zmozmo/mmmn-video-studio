"""A 33+ scene chapter must retain every frame AND all crossfades, not silently cut.

Tiny synthetic video inputs are test fixtures, not final novel visuals.
"""
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('mmmn_long_test',ROOT/'portable'/'studio_server.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg with ffprobe required')
class LongChapterTests(unittest.TestCase):
    def test_more_than_32_dissolves_bounded_and_frame_exact(self):
        with tempfile.TemporaryDirectory() as tmp:
            studio=mod.Studio(Path(tmp),'token')
            studio.RENDER_DIMENSIONS={'youtube':(96,64)}
            studio.RENDER_FPS=30
            source=studio.media('narrator-long123','mp4')
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                '-i','color=c=black:s=96x64:r=30','-f','lavfi','-i','sine=frequency=500:sample_rate=16000',
                '-t','17','-c:v','libx264','-c:a','aac',str(source)],check=True)
            for i,color in enumerate(('black','white','red')):
                img=studio.media(f'image-{i}-long','png')
                subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi',
                    '-i',f'color=c={color}:s=48x48:r=1','-frames:v','1',str(img)],check=True)
            count=34; duration=.5
            scenes=[{'assetId':f'image-{i%3}-long','ext':'png','duration':duration,'motion':'still'}
                    for i in range(count)]
            output=studio.render_chapter_command(chapterNumber=1,sourceVideoId='narrator-long123',
                sourceVideoExt='mp4',scenes=scenes,preset='youtube',recordedSeconds=count*duration,
                transitionMode='dissolve')
            result=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries',
                'stream=codec_type,nb_read_frames,codec_name:format=duration','-of','json',output]))
            by={x['codec_type']:x for x in result['streams']}
            self.assertEqual(int(by['video']['nb_read_frames']),510)
            self.assertEqual(by['audio']['codec_name'],'aac')
            self.assertAlmostEqual(float(result['format']['duration']),17,delta=.25)
            # At least 3 distinct compositions appear across the long timeline.
            def sample(t):
                return subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',output,
                    '-frames:v','1','-vf','scale=8:8,format=gray','-f','rawvideo','-'])
            self.assertNotEqual(sample(.10),sample(.65))
            self.assertNotEqual(sample(.65),sample(1.10))

if __name__=='__main__':unittest.main()
