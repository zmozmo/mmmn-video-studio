"""Windows CI only: prove a real packaged EXE retains real project and media across NSIS upgrade.

The workflow invokes this twice, with no uninstall between calls. All data is in an
isolated test directory, not in the source tree / installation directory.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

BASE='http://127.0.0.1:8765'


def fetch(route, *, post=None, token=None, raw=False, extra=None):
    headers={'Host':BASE.rsplit('/',1)[-1]}
    if token:headers['X-MM-Token']=token
    if extra:headers.update(extra)
    if post is not None and not raw:
        post=json.dumps(post,ensure_ascii=False).encode('utf-8')
        headers['Content-Type']='application/json'
    req=urllib.request.Request(BASE+route,post,headers,method='POST' if post is not None else 'GET')
    with urllib.request.urlopen(req,timeout=150) as response:
        result=response.read()
    return result if raw or post is None else json.loads(result)['result']


def wait_for_server(proc):
    for _ in range(80):
        if proc.poll() is not None:
            raise RuntimeError(f'Packaged EXE quit early with code {proc.returncode}')
        try:
            js=fetch('/__bridge.js').decode('utf-8')
            token=re.search(r'^const token=(".*?");',js,re.M)
            if token:return json.loads(token.group(1))
        except (OSError,ValueError):pass
        time.sleep(.25)
    raise RuntimeError('Packaged EXE failed loopback server startup')


def import_file(token, filename, ext, contents):
    fetch('/__api/begin_media_import',post={'id':filename,'ext':ext,'total':len(contents)},token=token)
    for offset in range(0,len(contents),512*1024):
        chunk=contents[offset:offset+512*1024]
        meta={'x-media-id':filename,'x-media-offset':str(offset),
              'x-media-sha256':hashlib.sha256(chunk).hexdigest()}
        fetch('/__api/import_media_chunk',post=chunk,token=token,raw=True,extra=meta)
    return fetch('/__api/finalize_media_import',post={'id':filename},token=token)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['before','after'])
    parser.add_argument('--exe',type=Path,required=True)
    parser.add_argument('--data-dir',type=Path,required=True)
    args=parser.parse_args()
    # Every phase uses an isolated local port; a stale previous trial must
    # NEVER masquerade as a newly installed executable.
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0))
        port=listener.getsockname()[1]
    global BASE
    BASE=f'http://127.0.0.1:{port}'
    args.data_dir.mkdir(parents=True,exist_ok=True)
    # Exercise the REAL default Windows LOCALAPPDATA folder convention, not
    # MMMN_TRIAL_DATA_DIR (which could bypass a regression in root_dir()).
    # Redirect LOCALAPPDATA only for the child process so the CI runner's own
    # personal folders and source state are never written to by this test.
    data_root=args.data_dir/'MMMN-Video-Studio-Trial'
    env=dict(os.environ,LOCALAPPDATA=str(args.data_dir.resolve()),
             MMMN_TRIAL_PORT=str(port),MMMN_NO_BROWSER='1')
    env.pop('MMMN_TRIAL_DATA_DIR',None)
    proc=subprocess.Popen([str(args.exe.resolve())],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        token=wait_for_server(proc)
        state_file=args.data_dir/'installer-evidence.json'
        if args.phase=='before':
            picture=(Path(__file__).resolve().parent.parent/'src-tauri/icons/32x32.png').read_bytes()
            image=import_file(token,'upgrade-test-photo','png',picture)
            if not image['sha256']==hashlib.sha256(picture).hexdigest():
                raise AssertionError('Image media upload checksum mismatch')
            ffmpeg=args.exe.resolve().parent/'_internal/portable/bin/ffmpeg.exe'
            if not ffmpeg.is_file():raise AssertionError('Windows packaged FFmpeg missing')
            with tempfile.TemporaryDirectory() as t:
                video=Path(t)/'narration.mp4'
                subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','error','-y',
                    '-f','lavfi','-i','color=c=black:s=160x90:r=15',
                    '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
                    '-t','2','-c:v','libx264','-c:a','aac',str(video)],check=True,timeout=90)
                recording=import_file(token,'upgrade-test-video','mp4',video.read_bytes())
            project={'title':'Offline မူရင်းစာမူ စမ်းသပ်ချက်','chapters':[{'number':1,
               'title':'အခန်း (၁)','text':'စာမူကို မဖျက်ရ',
               'audioAssetId':'upgrade-test-video',
               'scenes':[{'assetId':'upgrade-test-photo','duration':2.0,'motion':'still'}]}],
               'assets':[{'id':'upgrade-test-photo','name':'upgrade-test-photo.png','type':'image/png'},
                         {'id':'upgrade-test-video','name':'upgrade-test-video.mp4','type':'video/mp4'}],
               'sentinel':'PROJECT_MUST_SURVIVE_UPGRADE'}
            fetch('/__api/save_project_state',post={'json':json.dumps(project,ensure_ascii=False)},token=token)
            if not (data_root/'project-state.json').is_file() or not (data_root/'media'/'upgrade-test-video.mp4').is_file():
                raise AssertionError('Installed EXE did not use the default Windows LOCALAPPDATA data folder')
            state_file.write_text(json.dumps({'project_sha256':hashlib.sha256(json.dumps(project,ensure_ascii=False).encode()).hexdigest(),
                'image_sha256':image['sha256'],'video_sha256':recording['sha256'],
                'project_file_sha256':hashlib.sha256((data_root/'project-state.json').read_bytes()).hexdigest(),
                'image_file_sha256':hashlib.sha256((data_root/'media'/'upgrade-test-photo.png').read_bytes()).hexdigest(),
                'video_file_sha256':hashlib.sha256((data_root/'media'/'upgrade-test-video.mp4').read_bytes()).hexdigest()},indent=2))
            print('BASE INSTALL TEST PASS: saved project and media to isolated LOCALAPPDATA-style directory')
        else:
            expected=json.loads(state_file.read_text())
            if not (data_root/'project-state.json').is_file():
                raise AssertionError('Default LOCALAPPDATA project folder not found after upgrade')
            loaded=json.loads(fetch('/__api/load_project_state',post={},token=token))
            if loaded['sentinel']!='PROJECT_MUST_SURVIVE_UPGRADE':raise AssertionError('Project lost on update')
            if hashlib.sha256(json.dumps(loaded,ensure_ascii=False).encode()).hexdigest()!=expected['project_sha256']:
                raise AssertionError('Project changed during installer upgrade')
            # Compare the original bytes on disk, not only the server's response.
            # This catches accidental rewrites that are semantically equivalent JSON.
            if hashlib.sha256((data_root/'project-state.json').read_bytes()).hexdigest()!=expected['project_file_sha256']:
                raise AssertionError('Project bytes changed during installer upgrade')
            for filename,ext,key,file_key in [('upgrade-test-photo','png','image_sha256','image_file_sha256'),
                                               ('upgrade-test-video','mp4','video_sha256','video_file_sha256')]:
                disk_path=data_root/'media'/f'{filename}.{ext}'
                if not disk_path.is_file():
                    raise AssertionError(f'Media file disappeared during upgrade: {filename}')
                if hashlib.sha256(disk_path.read_bytes()).hexdigest()!=expected[file_key]:
                    raise AssertionError(f'Media bytes changed during installer upgrade: {filename}')
                result=fetch('/__api/verify_native_media',post={'id':filename,'ext':ext,
                           'expectedSha256':expected[key]},token=token)
                if not isinstance(result,dict) or result.get('verified') is not True or result.get('sha256')!=expected[key]:
                    raise AssertionError(f'Native media verification not acknowledged: {filename}')
            backups=list((data_root/'preupgrade-metadata').glob('preupgrade-*.json'))
            if not backups:raise AssertionError('No upgrade metadata recovery checkpoint')
            revision=json.loads((data_root/'trial-revision.json').read_text())
            if revision.get('previousRevision')!='installer-lab-base' or revision.get('revision')!='installer-lab-upgrade':
                raise AssertionError(f'Wrong upgrade revision history: {revision}')
            output=fetch('/__api/render_chapter_command',token=token,post={
                'chapterNumber':1,'sourceVideoId':'upgrade-test-video','sourceVideoExt':'mp4',
                'scenes':[{'assetId':'upgrade-test-photo','ext':'png','duration':2.0,'motion':'still'}],
                'preset':'square','recordedSeconds':2.0,'quality':'preview'})
            path=Path(output)
            if not path.is_file() or path.stat().st_size<1000:raise AssertionError('Updated EXE cannot render')
            probe=args.exe.resolve().parent/'_internal/portable/bin/ffprobe.exe'
            details=json.loads(subprocess.check_output([str(probe),'-v','error','-show_streams','-of','json',str(path)],timeout=30))
            codecs={s.get('codec_name') for s in details['streams']}
            if not {'h264','aac'}<=codecs:raise AssertionError(f'Incorrect video/audio codecs: {codecs}')
            print('IN-PLACE INSTALLER UPGRADE PASS: verified project, both media hashes, recovery and MP4 renderer')
    finally:
        proc.terminate()
        try:proc.wait(timeout=8)
        except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=8)

if __name__=='__main__':main()
