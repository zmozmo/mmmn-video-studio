import test from 'node:test';
import assert from 'node:assert/strict';
import {pickProject,parseProject,createNativeBridge,makeSaveQueue} from '../web/native-state.mjs';
const p=(id)=>({title:id,chapters:[],assets:[]});
test('Windows native state wins over stale browser state',()=>assert.equal(pickProject(JSON.stringify(p('native')),JSON.stringify(p('legacy')),p('starter')).source,'native'));
test('Existing pre-v0.9 browser timeline migrates when native file absent',()=>assert.equal(pickProject(null,JSON.stringify(p('legacy')),p('starter')).project.title,'legacy'));
test('New install uses only starter snapshot if no local state',()=>assert.equal(pickProject(null,null,p('starter')).source,'starter'));
test('Corrupt native project stops instead of overwriting with starter',()=>assert.throws(()=>pickProject('{bad json}',null,p('starter')),/Cannot parse native/));
test('Malformed project is rejected',()=>assert.throws(()=>parseProject('{"assets":[]}', 'test'),/not a valid/));
test('Native state saves coalesce rapid edits to the latest snapshot without races',async()=>{const found=[];const bridge=createNativeBridge({core:{invoke:async(cmd,args)=>{if(cmd==='save_project_state'){await new Promise(r=>setTimeout(r,5));found.push(args.json);}}}});const q=makeSaveQueue(bridge);q.save('v1');q.save('v2');q.save('v3');await q.flush();assert.deepEqual(found,['v3']);assert.equal(q.pending,0);});
test('Native save queue keeps last in-flight and last queued edits even with disk latency',async()=>{
 const found=[];let release;
 const begun=new Promise(resolve=>{release=resolve;});
 let firstStarted;const first=new Promise(resolve=>{firstStarted=resolve;});
 const q=makeSaveQueue({available:true,save:async(json)=>{found.push(json);if(json==='first'){firstStarted();await begun;}}});
 q.save('first');await first;q.save('second');q.save('newest');release();await q.flush();
 assert.deepEqual(found,['first','newest']);assert.equal(q.pending,0);
});
test('Preview mode avoids Tauri calls',async()=>{const b=createNativeBridge(undefined);assert.equal(b.available,false);assert.equal(await b.load(),null);await b.save('{}');});

test('Native save failures remain observable and later save can recover',async()=>{
  let calls=0,errors=[];
  const q=makeSaveQueue({available:true,save:async()=>{if(++calls===1)throw Error('disk full');}},e=>errors.push(e.message));
  await q.save('one');await assert.rejects(()=>q.flush(),/disk full/);
  assert.equal(q.pending,0);assert.deepEqual(errors,['disk full']);
  await q.save('two');await q.flush();assert.equal(q.lastError,null);
});
