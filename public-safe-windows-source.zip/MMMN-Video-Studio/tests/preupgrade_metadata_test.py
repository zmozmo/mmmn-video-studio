import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
spec=importlib.util.spec_from_file_location('mmmn_trial_preupgrade',Path(__file__).resolve().parent.parent/'portable/studio_server.py')
server=importlib.util.module_from_spec(spec)
spec.loader.exec_module(server)

class PreupgradeMetadataTests(unittest.TestCase):
 def test_first_reopen_and_second_revision_preserve_project_without_copying_large_video(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'trial';studio=server.Studio(root,'token')
   project={'chapters':[{'number':1,'text':'ငှက်အော်ကျွန်း'}],'assets':[]}
   studio.save_project_state(json=json.dumps(project,ensure_ascii=False))
   before=(root/'project-state.json').read_bytes()
   marker=root/'trial-revision.json'
   self.assertTrue(marker.is_file())
   marker.write_text(json.dumps({'revision':'old-portable-release'}),encoding='utf-8')
   newer=server.Studio(root,'token')
   snapshots=list((root/'preupgrade-metadata').glob('preupgrade-*.json'))
   self.assertEqual(len(snapshots),1)
   self.assertEqual(snapshots[0].read_bytes(),before)
   self.assertEqual((root/'project-state.json').read_bytes(),before)
   self.assertTrue(newer.load_project_state())
   server.Studio(root,'token')
   self.assertEqual(len(list((root/'preupgrade-metadata').glob('preupgrade-*.json'))),1)

 def test_corrupt_project_refuses_new_revision_without_discarding_bytes(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'trial';studio=server.Studio(root,'token')
   marker=root/'trial-revision.json'
   marker.write_text(json.dumps({'revision':'older'}),encoding='utf-8')
   project=root/'project-state.json';project.write_bytes(b'broken {')
   with self.assertRaisesRegex(ValueError,'damaged'):
    server.Studio(root,'token')
   self.assertEqual(project.read_bytes(),b'broken {')
   self.assertEqual(json.loads(marker.read_text())['revision'],'older')

 def test_valid_previous_copy_allows_upgrade_without_erasing_corrupt_current(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)/'trial';studio=server.Studio(root,'token')
   project={'chapters':[{'text':'ဇာတ်ဝင်ခန်း'}],'assets':[]}
   studio.save_project_state(json=json.dumps(project,ensure_ascii=False))
   studio.save_project_state(json=json.dumps(project,ensure_ascii=False))
   marker=root/'trial-revision.json'
   marker.write_text(json.dumps({'revision':'older'}),encoding='utf-8')
   current=root/'project-state.json';current.write_bytes(b'{corrupt')
   recovered=server.Studio(root,'token')
   self.assertEqual(current.read_bytes(),b'{corrupt')
   self.assertEqual(json.loads(recovered.load_project_state())['chapters'][0]['text'],'ဇာတ်ဝင်ခန်း')
   self.assertEqual(len(list((root/'preupgrade-metadata').glob('preupgrade-*.json'))),1)
