# MMMN Video Studio — Public-safe source candidate

This tree contains generic demo materials in place of the owner's original
novel manuscript, character images, Google Drive references and story exports.
The full original assets remain only in the separate PRIVATE FULL SOURCE archive.

**This is not a verified Windows build or a published GitHub repository.**
CI Windows installer tests must pass before any installer is called a release.
Do not copy private originals into a public repository.
