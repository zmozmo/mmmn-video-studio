@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 scripts\run-python-tests.py --quick --timeout 35 --report python-quick-report.json
) else (
  python scripts\run-python-tests.py --quick --timeout 35 --report python-quick-report.json
)
set "RESULT=%ERRORLEVEL%"
echo.
echo Quick tests are NOT full Windows release evidence. See PYTHON-TEST-MODES-MM.md
exit /b %RESULT%
