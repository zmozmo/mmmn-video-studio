# MMMN Video Studio — Windows CI handoff (2026-11-05)

Current release: v0.14.0 SOURCE CANDIDATE. NOT A VERIFIED Windows Installer.

The public-safe package contains demo-only manuscript and demo media. Do not put private MMMN manuscript, illustrations, narration, original recordings, project state, backups, or Google Drive folder links into the PUBLIC GitHub repository.

GitHub: https://github.com/zmozmo/mmmn-video-studio
Status when checked: repository existed, size 0, visibility public; connector's write endpoint returned HTTP 403 Resource not accessible by integration. No commit, GitHub Action, setup.exe, native Windows install/upgrade, or Windows Edge UI validation was completed by this session.

After actual authorized source upload to main, the Windows Installer In-place Upgrade Laboratory workflow is designed to trigger on push (or manual dispatch). It runs JavaScript/Python tests, finds real Windows FFmpeg/ffprobe, validates H.264+AAC MP4, builds two PyInstaller/NSIS versions, installs A, upgrades in-place to B, verifies saved project/media SHA-256, exports H.264/AAC MP4 from the installed updated EXE, checks real Edge UI, and only then uploads the UNSIGNED TEST installer plus hash and proof. No success is assumed from source-level tests.

Source-level checks here: JavaScript 133/133 pass; 22 of 23 Python modules passed in a parallel run (95 test cases total), with one outdated manual-only CI assertion failing after auto-trigger was intentionally added; that assertion was updated and independently rerun, passing all 3 tests in that module. Source Python video-to-MP4/backup/restore smoke passed. The full Python suite was NOT rerun as one completed invocation after all modifications.

This is an UNSIGNED Windows lab build route, not a Microsoft-certified/store-signed installer. Do not use it as a personal project data upgrade until the actual Windows runner's install→upgrade→render proof is PASS.

Source package variants: the large Private Full Source archive includes personal story/media and MUST NOT be pushed to PUBLIC GitHub; the smaller Public-safe package includes demo assets suitable for privacy review and CI source upload. The privacy audit is heuristic, not a complete guarantee; review before publishing.

The remaining blocker is authorization to upload the source to GitHub (403). Source preparation cannot bypass this platform permission.
